"""Which ratings this particular build's UI lets a pilot pick -- see
README's "Editions" note. All task/syllabus code for every rating always
ships inside the package regardless of edition: splitting that out per
edition would mean either duplicating sequence.py's/practice.py's
top-level imports per edition or teaching them to import conditionally,
for no real benefit here -- the source isn't hidden from a curious user
either way (see license.py's own known limitation about that). Only which
ratings are *selectable in the UI* is restricted.

SHIPPED_RATINGS = None means "all of them" -- the default, full-line
build. package.sh overwrites this file (same pattern as _version.py) when
building a restricted single-rating edition, via its --ratings option.
"""
from typing import Optional, Tuple

SHIPPED_RATINGS: Optional[Tuple[str, ...]] = ('ppl_asel',)


def visible_ratings(all_ratings: dict) -> dict:
    """`all_ratings` filtered down to SHIPPED_RATINGS, preserving order.
    Reads the module-level SHIPPED_RATINGS directly (not a parameter) so
    every call site in overlay.py stays in sync with a single source of
    truth -- tests exercise both branches by monkeypatching this module's
    attribute directly (see tests/test_edition.py), which is simpler than
    a second parameter that would need its own "unset" sentinel distinct
    from SHIPPED_RATINGS' own None-means-everything meaning."""
    if SHIPPED_RATINGS is None:
        return dict(all_ratings)
    return {k: v for k, v in all_ratings.items() if k in SHIPPED_RATINGS}
