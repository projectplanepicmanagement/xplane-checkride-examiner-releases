"""Offline serial-key activation.

The plugin has to work with no network access -- X-Plane add-ons are
expected to run fully offline -- so there's no server to call out to for
activation. Instead a key is just a random payload plus a keyed checksum
(HMAC-SHA256, truncated) computed against a secret embedded in this file;
`is_valid_key()` recomputes the checksum and compares it, so any key this
module didn't mint (typos, guesses, keys for a different product) fails.

Honest limitation: this file ships as plain, readable Python source inside
the distributed plugin (see INSTALL.txt) -- there's no compiled binary to
hide the secret behind, unlike a compiled desktop app's license scheme.
Anyone willing to open license.py can read `_SECRET` and mint their own
valid-looking keys with `generate_key()`. This stops casual sharing of a
single key/typos/guessing, not a determined person reading the source. A
stronger scheme would need server-side validation, which conflicts with
the plugin's fully-offline design -- see README's Known Limitations.

`generate_key()` is for `tools/generate_license_key.py`, a developer-only
script that mints keys to hand out to customers; that script (unlike this
module) is deliberately excluded from the customer-facing dist zip by
package.sh, so customers never receive a copy of the generator itself.
"""
import hashlib
import hmac
import json
import os
import secrets
from typing import Optional

# Not a real secret (see module docstring) -- just enough that a random or
# hand-typed string fails validation instead of accidentally passing.
_SECRET = b"CheckrideExaminer-License-Secret-v1-8f3c1a9d2e6b47f0a5d1"

_PAYLOAD_BYTES = 6
_CHECKSUM_BYTES = 4
_TOTAL_BYTES = _PAYLOAD_BYTES + _CHECKSUM_BYTES  # 10 bytes = 80 bits = 16 base32 chars, exactly
_KEY_CHARS = (_TOTAL_BYTES * 8) // 5
GROUP_SIZE = 4

# Crockford-style base32: drops I, L, O, U so a misread/mistyped character
# can't silently turn one valid-looking key into another.
_ALPHABET = "0123456789ABCDEFGHJKMNPQRSTVWXYZ"
_ALPHABET_INDEX = {c: i for i, c in enumerate(_ALPHABET)}


def _checksum(payload: bytes) -> bytes:
    return hmac.new(_SECRET, payload, hashlib.sha256).digest()[:_CHECKSUM_BYTES]


def _bytes_to_base32(data: bytes) -> str:
    bits = "".join(f"{b:08b}" for b in data)
    pad = (-len(bits)) % 5
    bits += "0" * pad
    return "".join(_ALPHABET[int(bits[i:i + 5], 2)] for i in range(0, len(bits), 5))


def _base32_to_bytes(chars: str, expected_bytes: int) -> Optional[bytes]:
    try:
        bits = "".join(f"{_ALPHABET_INDEX[c]:05b}" for c in chars)
    except KeyError:
        return None
    total_bits = expected_bytes * 8
    if len(bits) < total_bits:
        return None
    data = bytearray()
    for i in range(0, total_bits, 8):
        data.append(int(bits[i:i + 8], 2))
    return bytes(data)


def normalize_key(raw: str) -> str:
    """Strip formatting the pilot might type -- dashes, spaces, lowercase --
    back to the bare character stream format_key() produces."""
    return "".join(ch for ch in raw.upper() if ch in _ALPHABET_INDEX)


def format_key(chars: str) -> str:
    return "-".join(chars[i:i + GROUP_SIZE] for i in range(0, len(chars), GROUP_SIZE))


def generate_key() -> str:
    """Mint a new, valid serial key. Developer-only -- see module docstring."""
    payload = secrets.token_bytes(_PAYLOAD_BYTES)
    chars = _bytes_to_base32(payload + _checksum(payload))
    return format_key(chars)


def is_valid_key(raw: str) -> bool:
    chars = normalize_key(raw or "")
    if len(chars) != _KEY_CHARS:
        return False
    data = _base32_to_bytes(chars, _TOTAL_BYTES)
    if data is None:
        return False
    payload, checksum = data[:_PAYLOAD_BYTES], data[_PAYLOAD_BYTES:]
    return hmac.compare_digest(_checksum(payload), checksum)


class LicenseStore:
    """Persists the activated serial key to a small JSON file (same
    atomic-write, corrupt-tolerant pattern as
    aircraft_settings.AircraftSettingsStore) so the pilot only enters it
    once. `is_activated` re-validates the stored key against
    `is_valid_key()` on every check rather than trusting a saved flag --
    cheap, and means a hand-edited or corrupted file can never get stuck
    claiming a bad key is fine.

    `path=None` runs fully in-memory (tests, and a harmless fallback if
    resolving a real path ever fails) -- activation just doesn't persist.
    """

    def __init__(self, path: Optional[str]):
        self._path = path
        self._key = ""
        self._load()

    def _load(self) -> None:
        if not self._path or not os.path.exists(self._path):
            return
        try:
            with open(self._path, "r", encoding="utf-8") as f:
                raw = json.load(f)
            if isinstance(raw, dict):
                self._key = str(raw.get("key") or "")
        except (OSError, ValueError, TypeError):
            self._key = ""

    def _save(self) -> None:
        if not self._path:
            return
        directory = os.path.dirname(self._path)
        if directory:
            os.makedirs(directory, exist_ok=True)
        tmp_path = self._path + ".tmp"
        with open(tmp_path, "w", encoding="utf-8") as f:
            json.dump({"key": self._key}, f, indent=2)
        os.replace(tmp_path, self._path)

    @property
    def is_activated(self) -> bool:
        return is_valid_key(self._key)

    @property
    def formatted_key(self) -> str:
        return format_key(self._key) if self._key else ""

    def activate(self, raw_key: str) -> bool:
        normalized = normalize_key(raw_key)
        if not is_valid_key(normalized):
            return False
        self._key = normalized
        self._save()
        return True
