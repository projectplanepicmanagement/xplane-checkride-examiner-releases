"""Generated/overwritten by package.sh on every run -- do not hand-edit,
your change will be lost on the next package. This is the installed
plugin's own version number: updater.py compares it against the
distribution manifest's "version" field, and overlay.py's Update screen
displays it. Kept as its own tiny file (rather than reading the repo's
top-level VERSION at runtime) because this one ships inside
checkride_examiner/ -- VERSION itself is a build-time-only file package.sh
never copies into the distributable zip.
"""
PLUGIN_VERSION = 28
