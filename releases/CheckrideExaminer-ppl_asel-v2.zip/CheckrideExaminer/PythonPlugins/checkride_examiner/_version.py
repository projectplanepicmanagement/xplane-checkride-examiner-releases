"""Generated/overwritten by package.sh on every run -- do not hand-edit,
your change will be lost on the next package. PLUGIN_VERSION is the
installed plugin's real, monotonically-increasing build number:
updater.py's UpdateChecker compares it (raw, unmodified) against the
distribution manifest's "version" field, so update detection keeps working
correctly across every install regardless of when it was issued. Kept as
its own tiny file (rather than reading the repo's top-level VERSION at
runtime) because this one ships inside checkride_examiner/ -- VERSION
itself is a build-time-only file package.sh never copies into the
distributable zip.

PUBLIC_VERSION is the customer-facing number -- what overlay.py's Update
screen actually displays -- computed by subtracting PUBLIC_VERSION_BASE
(see package.sh) from PLUGIN_VERSION, so customers see a clean "v1, v2,
v3..." sequence starting from this project's first real customer-visible
release instead of the much larger, confusing internal build count. Never
compare on PUBLIC_VERSION; it exists for display only.
"""
PLUGIN_VERSION = 34
PUBLIC_VERSION_BASE = 31
PUBLIC_VERSION = PLUGIN_VERSION - PUBLIC_VERSION_BASE
