"""PA.VI.B Turns Around a Point.

ACS: altitude +/-100ft, airspeed +/-10kt, maintains coordinated flight;
entered 600-1000ft AGL downwind of the point, radius approximately 1/2 mile
(AirTrekNorth Cessna 172 ACS settings summary).

The ground-track radius here is estimated from GPS position around an
assumed center point (offset a nominal 1/2 mile from the aircraft, 90° into
the turn, at the moment the turn is established) -- not measured from a real
visual reference point the pilot chose. So the radius-consistency check is
reported as an advisory estimate, not a hard bust; altitude and airspeed are
graded normally.

Completion requires one full circle (360deg of net heading change), not the
two-or-more the Airplane Flying Handbook describes for the training
maneuver -- per real-world DPE/flight-school feedback, a single circle is
what's actually checked on the practical test, so this app grades that
instead. (An earlier version required two full circles/720deg; besides not
matching what's actually checked, it also carried a since-fixed TIMEOUT_S
bug that made two circles mathematically impossible to complete in the time
given.)

One circle at NOMINAL_RADIUS_FT is 2*pi*r ~= 19,088ft (3.14nm) of ground
track -- at a normal training speed for this maneuver (80-100kt) that alone
takes 113-141s, before accounting for the wind-correction turns the
maneuver requires. TURN_TIMEOUT_S=240s gives comfortable margin over that;
ARM_TIMEOUT_S is unchanged since establishing the turn is quick regardless
of circle count.
"""
import math

from ..grading import ToleranceSpec, ToleranceTracker
from ..util import heading_diff, local_xy_ft
from .base import Task

NOMINAL_RADIUS_FT = 3038.0  # ~1/2 nm, the ACS's suggested default radius
MIN_AGL_FT = 600.0
MAX_AGL_FT = 1300.0  # a bit of slack above the ACS's 1000ft entry ceiling
ARM_BANK_DEG = 15.0
ARM_TIMEOUT_S = 150.0
TURN_TIMEOUT_S = 240.0
COMPLETION_TURN_DEG = 360.0


class TurnsAroundAPointTask(Task):
    task_id = "ground_ref_turns_around_point"
    title = "Turns Around a Point"
    acs_ref = "PA.VI.B"

    def __init__(self):
        super().__init__()
        self._phase = "armed"
        self._armed_at = None
        self._started_at = None
        self._ref_lat = None
        self._ref_lon = None
        self._center_x = None
        self._center_y = None
        self._cumulative_turn = 0.0
        self._last_heading = None
        self._radius_devs = []

    def instructions(self):
        return (
            "Choose a ground reference point and enter turns around it 600-1,000 ft "
            "AGL, downwind, at a radius of about 1/2 mile. Complete one circle."
        )

    def update(self, state, dt):
        if self._armed_at is None:
            self._armed_at = state.t

        if self._phase == "armed":
            if state.t - self._armed_at > ARM_TIMEOUT_S:
                return self._finish(False, ["never established a turn around a point"])
            if abs(state.bank_deg) > ARM_BANK_DEG and MIN_AGL_FT <= state.agl_ft <= MAX_AGL_FT:
                self._ref_lat, self._ref_lon = state.lat, state.lon
                turn_sign = 1.0 if state.bank_deg > 0 else -1.0
                offset_hdg = math.radians((state.heading_deg + 90.0 * turn_sign) % 360.0)
                self._center_x = NOMINAL_RADIUS_FT * math.sin(offset_hdg)
                self._center_y = NOMINAL_RADIUS_FT * math.cos(offset_hdg)
                self._last_heading = state.heading_deg
                self._cumulative_turn = 0.0
                self._started_at = state.t
                alt_t = ToleranceTracker(ToleranceSpec.symmetric("Altitude", "ft", state.indicated_alt_ft, 100.0))
                ias_t = ToleranceTracker(ToleranceSpec.symmetric("Airspeed", "kt", state.ias_kt, 10.0))
                self.trackers = [alt_t, ias_t]
                self._phase = "turning"
            return None

        self.trackers[0].update(state.indicated_alt_ft, dt)
        self.trackers[1].update(state.ias_kt, dt)
        d = heading_diff(state.heading_deg, self._last_heading)
        self._cumulative_turn += d
        self._last_heading = state.heading_deg

        x, y = local_xy_ft(state.lat, state.lon, self._ref_lat, self._ref_lon)
        radius_now = math.hypot(x - self._center_x, y - self._center_y)
        self._radius_devs.append(radius_now - NOMINAL_RADIUS_FT)

        if state.t - self._started_at > TURN_TIMEOUT_S:
            return self._finish(False, ["did not complete the circle in time"])

        if abs(self._cumulative_turn) >= COMPLETION_TURN_DEG:
            max_dev = max((abs(d) for d in self._radius_devs), default=0.0)
            notes = [f"max ground-track radius deviation from the assumed 1/2-mile circle: {max_dev:.0f} ft (estimate only)"]
            return self._finish(True, notes)
        return None
