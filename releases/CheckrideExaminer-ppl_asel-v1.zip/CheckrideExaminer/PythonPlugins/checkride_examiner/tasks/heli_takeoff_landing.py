"""PH.V.A/B/D Takeoffs, Landings, and Go-Arounds (Normal Takeoff and Climb,
Normal and Crosswind Approach, Steep Approach) in a helicopter.

ACS numbers (FAA-S-ACS-15): after clearing obstacles, transition to normal
climb attitude/airspeed +/-10kt (PH.V.A.S8); arrive at the termination
point, on the surface or at a stabilized hover, +/-4 feet (PH.V.B.S9,
PH.V.D.S8); steep approach angle 15 degrees maximum (PH.V.D.S5).

Both approach tasks grade "arrival within 4 feet" the same way Vertical
Takeoff and Landing's landing phase does (see heli_hovering.py): there's no
way to know which exact point on the ground the pilot picked as their
termination point, so this instead checks that the helicopter came to a
genuinely stable stop (not still drifting) within a small radius of the
position where it first slowed below the "stopped" threshold.
"""
import math

from ..grading import ToleranceSpec, ToleranceTracker
from ..util import heading_diff, local_xy_ft
from .base import HoldTask, Task

CLIMB_ARM_VS_FPM = 200.0
CLIMB_HOLD_S = 15.0
CLIMB_TIMEOUT_S = 60.0

APPROACH_STOP_GS_KT = 5.0
APPROACH_STOP_AGL_FT = 15.0
APPROACH_STOP_HOLD_S = 2.0
APPROACH_POSITION_TOL_FT = 4.0
APPROACH_TIMEOUT_S = 120.0

STEEP_APPROACH_MAX_ANGLE_DEG = 15.0
# ACS gives only the 15 deg ceiling -- this floor is a heuristic to confirm
# the approach was actually flown steep, not just a normal approach that
# happens to satisfy the "at most 15 deg" check trivially.
STEEP_APPROACH_MIN_ANGLE_DEG = 8.0
_FPM_TO_FPS = 1.0 / 60.0
_KT_TO_FPS = 1.68781


class NormalTakeoffClimbTask(HoldTask):
    task_id = "heli_normal_takeoff_climb"
    title = "Normal Takeoff and Climb"
    acs_ref = "PH.V.A"
    HOLD_SECONDS = CLIMB_HOLD_S
    ARM_TIMEOUT_S = CLIMB_TIMEOUT_S

    def instructions(self):
        return "After clearing obstacles, transition to a normal climb attitude, airspeed, and power setting."

    def _arm_condition(self, state):
        return not state.on_ground and state.vs_fpm > CLIMB_ARM_VS_FPM

    def _on_arm(self, state):
        ias_t = ToleranceTracker(ToleranceSpec.symmetric("Airspeed", "kt", state.ias_kt, 10.0))
        hdg_t = ToleranceTracker(ToleranceSpec.symmetric("Heading", "deg", state.heading_deg, 10.0), diff_fn=heading_diff)
        self.tracked = [
            (ias_t, lambda s: s.ias_kt),
            (hdg_t, lambda s: s.heading_deg),
        ]


class NormalApproachTask(Task):
    task_id = "heli_normal_approach"
    title = "Normal and Crosswind Approach"
    acs_ref = "PH.V.B"

    def __init__(self):
        super().__init__()
        self._started_at = None
        self._ref_lat = None
        self._ref_lon = None
        self._stop_streak = 0.0

    def instructions(self):
        return "Fly a normal approach to a stabilized hover or touchdown at your termination point."

    def update(self, state, dt):
        if self._started_at is None:
            self._started_at = state.t
        if state.t - self._started_at > APPROACH_TIMEOUT_S:
            return self._finish(False, ["did not complete the approach in time"])

        slow_and_low = state.agl_ft < APPROACH_STOP_AGL_FT and state.groundspeed_kt < APPROACH_STOP_GS_KT
        if slow_and_low:
            if self._ref_lat is None:
                self._ref_lat, self._ref_lon = state.lat, state.lon
            self._stop_streak += dt
        else:
            self._ref_lat = None
            self._stop_streak = 0.0

        if state.on_ground or self._stop_streak >= APPROACH_STOP_HOLD_S:
            x, y = local_xy_ft(state.lat, state.lon, self._ref_lat, self._ref_lon)
            radius = math.hypot(x, y)
            passed = radius <= APPROACH_POSITION_TOL_FT
            notes = [f"came to rest {radius:.0f} ft from the point where you first slowed to a stop (limit {APPROACH_POSITION_TOL_FT:.0f} ft)"]
            return self._finish(passed, notes)
        return None


class SteepApproachTask(Task):
    task_id = "heli_steep_approach"
    title = "Steep Approach"
    acs_ref = "PH.V.D"

    def __init__(self):
        super().__init__()
        self._started_at = None
        self._ref_lat = None
        self._ref_lon = None
        self._stop_streak = 0.0
        self._max_angle = 0.0

    def instructions(self):
        return f"Fly a steep approach (approach angle {STEEP_APPROACH_MAX_ANGLE_DEG:.0f}° maximum) to a stabilized hover or touchdown."

    def update(self, state, dt):
        if self._started_at is None:
            self._started_at = state.t
        if state.t - self._started_at > APPROACH_TIMEOUT_S:
            return self._finish(False, ["did not complete the approach in time"])

        if not state.on_ground and state.vs_fpm < 0.0 and state.groundspeed_kt > 1.0:
            descent_fps = -state.vs_fpm * _FPM_TO_FPS
            forward_fps = state.groundspeed_kt * _KT_TO_FPS
            angle = math.degrees(math.atan2(descent_fps, forward_fps))
            self._max_angle = max(self._max_angle, angle)

        slow_and_low = state.agl_ft < APPROACH_STOP_AGL_FT and state.groundspeed_kt < APPROACH_STOP_GS_KT
        if slow_and_low:
            if self._ref_lat is None:
                self._ref_lat, self._ref_lon = state.lat, state.lon
            self._stop_streak += dt
        else:
            self._ref_lat = None
            self._stop_streak = 0.0

        if state.on_ground or self._stop_streak >= APPROACH_STOP_HOLD_S:
            x, y = local_xy_ft(state.lat, state.lon, self._ref_lat, self._ref_lon)
            radius = math.hypot(x, y)
            notes = [
                f"came to rest {radius:.0f} ft from the point where you first slowed to a stop (limit {APPROACH_POSITION_TOL_FT:.0f} ft)",
                f"steepest approach angle flown: {self._max_angle:.0f}°",
            ]
            passed = radius <= APPROACH_POSITION_TOL_FT and self._max_angle <= STEEP_APPROACH_MAX_ANGLE_DEG
            if self._max_angle < STEEP_APPROACH_MIN_ANGLE_DEG:
                passed = False
                notes.append(f"approach wasn't steep enough (aim for at least ~{STEEP_APPROACH_MIN_ANGLE_DEG:.0f}°)")
            elif self._max_angle > STEEP_APPROACH_MAX_ANGLE_DEG:
                notes.append(f"exceeded the {STEEP_APPROACH_MAX_ANGLE_DEG:.0f}° maximum")
            return self._finish(passed, notes)
        return None
