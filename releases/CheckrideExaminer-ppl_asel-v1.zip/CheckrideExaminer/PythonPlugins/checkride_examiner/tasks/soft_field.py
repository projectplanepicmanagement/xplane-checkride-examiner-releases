"""PA.IV.C (Private) / CA.IV.C (Commercial) Soft-Field Takeoff and Climb,
and PA.IV.D / CA.IV.D Soft-Field Approach and Landing.

ACS numbers (fetched and confirmed directly from the FAA-S-ACS-6C skill
text via cfi.treklog.com's task-by-task summaries):
  PA.IV.C.S8: "establish and maintain a pitch attitude that will transfer
    the weight of the airplane from the wheels to the wings as rapidly as
    possible" -- i.e. sustained back-elevator pressure during the ground
    roll. X-Plane has no "weight on wheels" dataref, but it does report the
    pilot's own raw elevator control INPUT (not the resulting surface
    deflection, which trim/autopilot also affect):
    `sim/cockpit2/controls/yoke_pitch_ratio` (-1 full down .. +1 full up,
    see datarefs.py). A sustained positive (aft/up) input during the
    ground roll is a real, verifiable proxy for "holding the yoke back",
    unlike anything available for Vx/Vy -- and it's exactly the ACS skill
    an earlier version of this package's docstrings noted as *not*
    implemented ("holding the yoke/elevator full aft during the roll is a
    Soft-Field technique, not part of either short-field task's ACS
    skills" -- true for Short-Field, but it IS one of Soft-Field's own
    skills, which is why it lives here instead).
  PA.IV.C.S9/S10: lift off at the lowest possible airspeed, remain in
    ground effect while accelerating to Vx or Vy (not separately graded --
    "ground effect" isn't something a generic dataref reports), then climb
    at Vx or Vy, +10/-5kt (Private) / +/-5kt (Commercial). This build
    always targets Vy (reusing AircraftSettings.vy_kt, mandatory -- same
    reasoning as Normal/Short-Field Takeoff, tasks/normal_landing.py /
    tasks/short_field.py) since the ACS lets the examiner pick either and
    there's no way to script "which one is appropriate here".
  PA.IV.D.S6: same approach-speed formula as Short-Field/Normal landing
    (see util.resolve_approach_speed).
  PA.IV.D.S8/S9/S10: touch down at minimum sink rate, then (for tricycle
    gear) hold sufficient back-elevator pressure during rollout to keep
    the nosewheel light -- same yoke_pitch_ratio check as the takeoff
    roll, applied to rollout instead. No touchdown-point-distance standard
    exists for this task (unlike Normal's 400ft / Short-Field's 200ft) --
    confirmed absent from the ACS skill list, so this doesn't invent one.

**SoftFieldLandingTask does not track heading** (unlike SoftFieldTakeoffTask,
which legitimately does, same as Normal/Short-Field's takeoff tasks). An
earlier version armed on the start of descent -- routinely still on
downwind -- and held +/-10deg from that heading through the whole
approach, busting a normal downwind/base/final pattern turn every time
(user-reported; same copy-paste-from-takeoff bug as
tasks/short_field.py's and tasks/normal_landing.py's landing tasks -- see
short_field.py's docstring for the full writeup). PA.IV.D's landing skills
above have no equivalent heading requirement.

**SoftFieldLandingTask's and SoftFieldTakeoffTask's airspeed checks are
both capture-gated** (`ToleranceTracker(..., gate_until_captured=True)`,
grading.py), same fix as tasks/short_field.py's identical bug (see that
file's docstring). Landing: the tolerance clock used to start the instant
descent began, while still near cruise speed on downwind, well before a
pilot could realistically decelerate to approach speed within the
tracker's 3s grace period (user-reported: "Down windではまだクルーズスピ
ードに近いスピードも出ているだろうし"). Takeoff: the Vy tracker used to
start counting the instant of liftoff (user-reported: "Takeoff系もなん
だけど速度が乗るまで少し時間がかかる") -- this is arguably the task most
exposed to that bug, since S9/S10 above explicitly calls for a deliberate
ground-effect acceleration period *before* climbing at Vy, not an
immediate climb. Both now only count deviation time once airspeed has
actually entered the target band at least once.
"""
from ..grading import ToleranceSpec, ToleranceTracker
from ..util import heading_diff, resolve_approach_speed
from .base import Task

HDG_TOL_DEG = 10.0
CLIMB_HOLD_S = 15.0
TAKEOFF_TIMEOUT_S = 90.0
# sim/cockpit2/controls/yoke_pitch_ratio -- a meaningful sustained aft/up
# input, not just a brief tap or the natural centered/near-neutral range.
YOKE_AFT_THRESHOLD = 0.2
# Total time (not necessarily continuous) spent above the threshold
# somewhere during the roll/rollout -- real technique holds firmly at
# first, then gradually relaxes as speed builds/bleeds off, so this
# doesn't require one unbroken streak, just a real, sustained effort.
YOKE_HOLD_REQUIRED_S = 3.0

APPROACH_ARM_VS_FPM = -100.0
APPROACH_SPEED_FACTOR = 1.3
TOUCHDOWN_ADVISORY_TOL_KT = 5.0
LANDING_TIMEOUT_S = 120.0
ROLLOUT_GRACE_S = 5.0  # time after touchdown before grading whether the yoke was held back


class SoftFieldTakeoffTask(Task):
    task_id = "soft_field_takeoff"
    title = "Soft-Field Takeoff and Climb"

    def __init__(self, acs_ref: str = "PA.IV.C", tolerance_low: float = -5.0, tolerance_high: float = 10.0):
        super().__init__()
        self.acs_ref = acs_ref
        self._tol_low = tolerance_low
        self._tol_high = tolerance_high
        self._vy_kt = 0.0  # 0 = not registered for this aircraft
        self._phase = "ground"
        self._started_at = None
        self._yoke_aft_streak = 0.0
        self._held_yoke_aft = False
        self._hdg_t = None
        self._vy_t = None
        self._climb_started_at = None

    def configure_from_settings(self, settings) -> None:
        self._vy_kt = settings.vy_kt

    def blocking_reason(self):
        if self._vy_kt <= 0.0:
            return "This aircraft's Vy isn't set yet. Open Settings and enter it before starting Soft-Field Takeoff."
        return None

    def instructions(self):
        if self._phase == "ground":
            return "Hold the yoke/elevator full aft to keep weight off the nosewheel, apply takeoff power, and lift off at the lowest safe airspeed."
        return f"Remain low and accelerate in ground effect, then climb at Vy ({self._vy_kt:.0f}kt)."

    def update(self, state, dt):
        if self.blocking_reason() is not None:
            return None  # waiting on Settings -- no timer running

        if self._started_at is None:
            self._started_at = state.t
        if state.t - self._started_at > TAKEOFF_TIMEOUT_S:
            return self._finish(False, ["did not complete the takeoff and climb in time"])

        if self._phase == "ground":
            if state.on_ground and state.yoke_pitch_ratio > YOKE_AFT_THRESHOLD:
                self._yoke_aft_streak += dt
                if self._yoke_aft_streak >= YOKE_HOLD_REQUIRED_S:
                    self._held_yoke_aft = True
            if not state.on_ground and state.vs_fpm > 100.0:
                self._hdg_t = ToleranceTracker(ToleranceSpec.symmetric("Heading", "deg", state.heading_deg, HDG_TOL_DEG), diff_fn=heading_diff)
                self._vy_t = ToleranceTracker(
                    ToleranceSpec("Airspeed", "kt", self._vy_kt, self._tol_low, self._tol_high),
                    gate_until_captured=True,
                )
                self.trackers = [self._hdg_t, self._vy_t]
                self._phase = "climb"
                self._climb_started_at = state.t
            return None

        self._hdg_t.update(state.heading_deg, dt)
        self._vy_t.update(state.ias_kt, dt)
        if state.t - self._climb_started_at >= CLIMB_HOLD_S:
            notes = []
            passed = True
            if not self._held_yoke_aft:
                passed = False
                notes.append("never held sustained back-elevator pressure during the ground roll (soft-field technique)")
            if not self._vy_t.captured:
                notes.append(
                    f"airspeed was never within tolerance of Vy ({self._vy_kt:.0f}kt) during the climb "
                    "(advisory only -- never captured, so nothing to grade the sustained tolerance against)"
                )
            return self._finish(passed, notes)
        return None


class SoftFieldLandingTask(Task):
    task_id = "soft_field_landing"
    title = "Soft-Field Approach and Landing"

    def __init__(self, acs_ref: str = "PA.IV.D", tolerance_low: float = -5.0, tolerance_high: float = 10.0):
        super().__init__()
        self.acs_ref = acs_ref
        self._tol_low = tolerance_low
        self._tol_high = tolerance_high
        self._published_approach_kt = 0.0
        self._started_at = None
        self._armed = False
        self._touched_down_at = None
        self._ias_t = None
        self._ias_is_advisory_only = False
        self._max_ias_dev = 0.0
        self._ias_target = None
        self._yoke_aft_streak = 0.0
        self._held_yoke_aft = False

    def configure_from_settings(self, settings) -> None:
        self._published_approach_kt = settings.short_field_approach_kt

    def instructions(self):
        if self._touched_down_at is not None:
            return "Hold the yoke/elevator full aft to keep the nosewheel light during rollout."
        return "Fly a stabilized approach at the recommended approach speed to a soft, minimum-sink touchdown."

    def update(self, state, dt):
        if self._started_at is None:
            self._started_at = state.t
        if state.t - self._started_at > LANDING_TIMEOUT_S:
            return self._finish(False, ["did not complete the approach and landing in time"])

        if not self._armed:
            if not state.on_ground and state.vs_fpm < APPROACH_ARM_VS_FPM:
                self.trackers = []
                target = resolve_approach_speed(self._published_approach_kt, state.vso_kt, APPROACH_SPEED_FACTOR)
                if target is not None:
                    self._ias_target = target
                    self._ias_t = ToleranceTracker(
                        ToleranceSpec("Airspeed", "kt", target, self._tol_low, self._tol_high),
                        gate_until_captured=True,
                    )
                    self.trackers.append(self._ias_t)
                else:
                    self._ias_is_advisory_only = True
                    self._ias_target = state.ias_kt
                self._armed = True
            return None

        if self._touched_down_at is None:
            if self._ias_is_advisory_only:
                self._max_ias_dev = max(self._max_ias_dev, abs(state.ias_kt - self._ias_target))
            else:
                self._ias_t.update(state.ias_kt, dt)
            if state.on_ground:
                self._touched_down_at = state.t
            return None

        # rollout: watch for sustained back-elevator pressure to keep the nosewheel light
        if state.yoke_pitch_ratio > YOKE_AFT_THRESHOLD:
            self._yoke_aft_streak += dt
            if self._yoke_aft_streak >= YOKE_HOLD_REQUIRED_S:
                self._held_yoke_aft = True

        if state.t - self._touched_down_at >= ROLLOUT_GRACE_S:
            notes = []
            passed = True
            if not self._held_yoke_aft:
                passed = False
                notes.append("never held sustained back-elevator pressure during rollout (soft-field technique)")
            if self._ias_is_advisory_only and self._max_ias_dev > TOUCHDOWN_ADVISORY_TOL_KT:
                notes.append(
                    f"approach speed drifted up to {self._max_ias_dev:.0f}kt from where it was established "
                    "(advisory only -- this aircraft doesn't report a stall speed (Vso) and no published "
                    "approach speed is set in Settings, so nothing to grade against)"
                )
            elif not self._ias_is_advisory_only and not self._ias_t.captured:
                notes.append(
                    f"approach speed was never within tolerance of the target ({self._ias_target:.0f}kt) "
                    "before touchdown (advisory only -- never captured, so nothing to grade the sustained "
                    "tolerance against)"
                )
            return self._finish(passed, notes)
        return None
