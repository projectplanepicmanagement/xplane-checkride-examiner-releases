"""PA.X.A (Private) / CA.IX.A (Commercial) Emergency Descent.

ACS: configuration is throttle idle / flaps zero, pitched for the bottom of
the yellow arc; airspeed +0/-10kt of the speed established at entry (must
not be exceeded -- it's a structural-speed target); recovers at/near the
assigned altitude, +/-100ft. Private: OregonFlightSchool.com summary,
ACS-6B. Commercial (FAA-S-ACS-7B, CA.IX.A.S4/S5): identical numbers, and
explicitly requires bank between 30-45deg (Private treats that bank range
as the common technique, not a graded requirement) -- `bank_required` flips
that from an advisory note to a hard bust.

The entry-speed tolerance above is correctly self-referential (the ACS lets
the pilot pick their own descent speed at the bottom of the yellow arc and
just requires holding it) -- no real number needed there. What it doesn't
cover is whether that chosen speed is actually safe: X-Plane exposes the
aircraft's real max structural cruising speed as `acf_Vno` (`state.vno_kt`,
same as `vso_kt` -- see datarefs.py), so this hard-busts an actual
overspeed past it during the descent, on top of the existing entry-speed
hold check.
"""
from ..grading import ToleranceSpec, ToleranceTracker
from .base import Task

ARM_VS_FPM = -500.0
ARM_THROTTLE = 0.15
SUSTAINED_S = 2.0
RECOVERY_ALT_LOSS_FT = 500.0
TIMEOUT_S = 120.0


class EmergencyDescentTask(Task):
    task_id = "emergency_descent"
    title = "Emergency Descent"

    def __init__(self, acs_ref: str = "PA.X.A", bank_required: bool = False):
        super().__init__()
        self.acs_ref = acs_ref
        self._bank_required = bank_required
        self._phase = "setup"
        self._descent_streak = 0.0
        self._started_at = None
        self._target_alt = None
        self._max_bank_seen = 0.0
        self._max_overspeed_kt = 0.0  # how far past Vno, if ever (0 = never / Vno unavailable)

    def instructions(self):
        if self._target_alt is not None:
            return (
                f"Simulated engine failure: descend immediately. Recover no lower than "
                f"{self._target_alt:.0f} ft indicated. Idle power, appropriate configuration, "
                "pitch for max descent rate at a safe airspeed."
            )
        return "Simulated engine failure -- establish an emergency descent."

    def update(self, state, dt):
        if self._started_at is None:
            self._started_at = state.t
            self._target_alt = state.indicated_alt_ft - RECOVERY_ALT_LOSS_FT

        if state.t - self._started_at > TIMEOUT_S:
            return self._finish(False, ["did not establish/recover from the emergency descent in time"])

        if self._phase == "setup":
            if state.throttle_ratio < ARM_THROTTLE and state.vs_fpm < ARM_VS_FPM:
                self._descent_streak += dt
            else:
                self._descent_streak = 0.0
            if self._descent_streak >= SUSTAINED_S:
                ias_t = ToleranceTracker(ToleranceSpec("Airspeed", "kt", state.ias_kt, -10.0, 0.0))
                self.trackers = [ias_t]
                self._phase = "descending"
            return None

        self.trackers[0].update(state.ias_kt, dt)
        self._max_bank_seen = max(self._max_bank_seen, abs(state.bank_deg))
        if state.vno_kt > 0.0:
            self._max_overspeed_kt = max(self._max_overspeed_kt, state.ias_kt - state.vno_kt)

        if state.indicated_alt_ft <= self._target_alt + 100.0:
            alt_dev = state.indicated_alt_ft - self._target_alt
            notes = [f"leveled off {alt_dev:+.0f} ft from the assigned recovery altitude (limit ±100 ft)"]
            passed = abs(alt_dev) <= 100.0
            if self._bank_required:
                if self._max_bank_seen > 45.0 or self._max_bank_seen < 25.0:
                    passed = False
                    notes.append(f"max bank during the descent was {self._max_bank_seen:.0f}° (required 30-45°)")
            elif self._max_bank_seen > 45.0:
                notes.append(f"maximum bank during the descent was {self._max_bank_seen:.0f}° (typical technique is 30-45°)")
            if self._max_overspeed_kt > 0.0:
                passed = False
                notes.append(f"exceeded Vno (max structural cruising speed) by {self._max_overspeed_kt:.0f}kt during the descent")
            return self._finish(passed, notes)
        return None
