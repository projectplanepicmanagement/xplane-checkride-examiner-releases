"""PH.VI.A/B/C Performance Maneuvers: Rapid Deceleration/Quick Stop, and
Autorotations (straight-in and with turns) in a single-engine helicopter.

ACS numbers (FAA-S-ACS-15): Quick Stop maintains heading +/-10 deg
throughout (PH.VI.A.S5). Autorotation: power-off glide at the airspeed
established at entry, +/-10kt (PH.VI.B.S7 / PH.VI.C.S7); main rotor (Nr)
"within normal limits" -- the ACS gives no universal RPM number here, since
it's POH/type-specific (a Robinson R22's normal powered range is much
narrower than its autorotation range, and other types differ again), so
this tracks main rotor speed as a percentage of whatever it was reading
right before the simulated engine chop and busts on a generic +/-10% band
around that. That's a heuristic, not an FAA number -- if your aircraft's
actual autorotation RPM range is tighter or wider, treat it as advisory.
Autorotation with Turns additionally requires rolling out of the turn no
lower than 300 ft AGL (PH.VI.C.S10).

The ACS also wants the autorotation terminated within 200 ft of a
preselected landing point (S12/S13). That is NOT graded here -- there's no
way for the plugin to know which point on the ground the pilot picked, and
guessing one (the way ground_reference.py estimates a turn-around-a-point
center) would be misleading for a maneuver whose whole purpose is putting
the aircraft down in a specific spot. Instead this grades the two things
that do show up in flight data: energy management (airspeed/rotor RPM held
through the glide) and a controlled termination to a hover or touchdown.
Self-assess the 200 ft touchdown accuracy yourself.
"""
from ..grading import ToleranceSpec, ToleranceTracker
from ..util import heading_diff
from .base import Task

QUICK_STOP_ARM_IAS_KT = 20.0
QUICK_STOP_MAX_AGL_FT = 150.0
QUICK_STOP_STOP_GS_KT = 5.0
QUICK_STOP_STOP_HOLD_S = 2.0
QUICK_STOP_TIMEOUT_S = 60.0

AUTOROTATION_ARM_THROTTLE = 0.15
AUTOROTATION_ARM_MIN_AGL_FT = 300.0
AUTOROTATION_ARM_VS_FPM = -300.0
AUTOROTATION_ARM_SUSTAINED_S = 2.0
AUTOROTATION_MIN_GLIDE_S = 3.0
AUTOROTATION_TERM_AGL_FT = 15.0
AUTOROTATION_TERM_GS_KT = 5.0
AUTOROTATION_TERM_HOLD_S = 2.0
AUTOROTATION_ROLLOUT_MIN_AGL_FT = 300.0
AUTOROTATION_TURN_RATE_DEG_S = 3.0  # still "turning" if heading is changing faster than this
AUTOROTATION_MIN_TURN_DEG = 90.0
AUTOROTATION_TIMEOUT_S = 90.0


class RapidDecelerationTask(Task):
    task_id = "heli_rapid_deceleration"
    title = "Rapid Deceleration / Quick Stop"
    acs_ref = "PH.VI.A"

    def __init__(self):
        super().__init__()
        self._armed_at = None
        self._started_at = None
        self._stop_streak = 0.0
        self._min_agl_seen = None

    def instructions(self):
        return "From forward flight, execute a rapid deceleration to a stabilized hover, maintaining heading."

    def update(self, state, dt):
        if self._armed_at is None:
            self._armed_at = state.t

        if self._started_at is None:
            if state.t - self._armed_at > QUICK_STOP_TIMEOUT_S:
                return self._finish(False, ["never established forward flight to begin the maneuver"])
            if not state.on_ground and state.ias_kt > QUICK_STOP_ARM_IAS_KT and state.agl_ft < QUICK_STOP_MAX_AGL_FT:
                self._started_at = state.t
                hdg_t = ToleranceTracker(ToleranceSpec.symmetric("Heading", "deg", state.heading_deg, 10.0), diff_fn=heading_diff)
                self.trackers = [hdg_t]
                self._min_agl_seen = state.agl_ft
            return None

        self.trackers[0].update(state.heading_deg, dt)
        self._min_agl_seen = min(self._min_agl_seen, state.agl_ft)

        if state.t - self._started_at > QUICK_STOP_TIMEOUT_S:
            return self._finish(False, ["did not decelerate to a stabilized hover in time"])

        if state.groundspeed_kt < QUICK_STOP_STOP_GS_KT:
            self._stop_streak += dt
        else:
            self._stop_streak = 0.0

        if self._stop_streak >= QUICK_STOP_STOP_HOLD_S:
            notes = [f"lowest ground clearance during the maneuver: {self._min_agl_seen:.0f} ft AGL"]
            return self._finish(True, notes)
        return None


class AutorotationTask(Task):
    """Straight-in (require_turn=False, PH.VI.B) or with-turns
    (require_turn=True, PH.VI.C) autorotation in a single-engine
    helicopter -- same numeric standards, plus a turn + rollout-altitude
    check for the turning version (see module docstring)."""

    task_id = "heli_autorotation"
    title = "Straight-In Autorotation"

    def __init__(self, require_turn: bool = False, acs_ref: str = "PH.VI.B"):
        super().__init__()
        self.acs_ref = acs_ref
        self._require_turn = require_turn
        if require_turn:
            self.task_id = "heli_autorotation_turns"
            self.title = "Autorotation with Turns"
        self._phase = "setup"
        self._chop_streak = 0.0
        self._term_streak = 0.0
        self._started_at = None
        self._glide_started_at = None
        self._entry_rotor_rpm = None
        self._last_heading = None
        self._cumulative_turn = 0.0
        self._turning = False
        self._rollout_agl = None

    def instructions(self):
        if self._require_turn:
            return "Simulated engine failure: enter an autorotation including a turn, then recover to a hover or touchdown."
        return "Simulated engine failure: enter a straight-in autorotation, then recover to a hover or touchdown."

    def update(self, state, dt):
        if self._started_at is None:
            self._started_at = state.t
        if state.t - self._started_at > AUTOROTATION_TIMEOUT_S:
            return self._finish(False, ["did not complete the autorotation in time"])

        if self._phase == "setup":
            ready = (
                not state.on_ground
                and state.throttle_ratio < AUTOROTATION_ARM_THROTTLE
                and state.vs_fpm < AUTOROTATION_ARM_VS_FPM
                and state.agl_ft > AUTOROTATION_ARM_MIN_AGL_FT
            )
            self._chop_streak = self._chop_streak + dt if ready else 0.0
            if self._chop_streak >= AUTOROTATION_ARM_SUSTAINED_S:
                ias_t = ToleranceTracker(ToleranceSpec.symmetric("Airspeed", "kt", state.ias_kt, 10.0))
                rotor_t = ToleranceTracker(ToleranceSpec.symmetric("Rotor RPM", "%", 100.0, 10.0))
                self.trackers = [ias_t, rotor_t]
                self._entry_rotor_rpm = max(state.rotor_rpm, 1.0)
                self._glide_started_at = state.t
                self._last_heading = state.heading_deg
                self._phase = "glide"
            return None

        rotor_pct = 100.0 * state.rotor_rpm / self._entry_rotor_rpm
        self.trackers[0].update(state.ias_kt, dt)
        self.trackers[1].update(rotor_pct, dt)

        if self._require_turn:
            d = heading_diff(state.heading_deg, self._last_heading)
            self._last_heading = state.heading_deg
            turn_rate = abs(d) / dt if dt > 0 else 0.0
            self._cumulative_turn += abs(d)
            if turn_rate > AUTOROTATION_TURN_RATE_DEG_S:
                self._turning = True
                self._rollout_agl = state.agl_ft
            elif self._turning:
                self._turning = False  # heading just steadied -- this is roughly the rollout point

        glided_enough = (state.t - self._glide_started_at) >= AUTOROTATION_MIN_GLIDE_S
        terminating = state.on_ground or (state.agl_ft < AUTOROTATION_TERM_AGL_FT and state.groundspeed_kt < AUTOROTATION_TERM_GS_KT)
        self._term_streak = self._term_streak + dt if terminating else 0.0

        if glided_enough and (state.on_ground or self._term_streak >= AUTOROTATION_TERM_HOLD_S):
            notes = []
            passed = True
            if self._require_turn:
                if self._cumulative_turn < AUTOROTATION_MIN_TURN_DEG:
                    passed = False
                    notes.append(f"only turned {self._cumulative_turn:.0f}° total (need at least {AUTOROTATION_MIN_TURN_DEG:.0f}°)")
                elif self._rollout_agl is not None and self._rollout_agl < AUTOROTATION_ROLLOUT_MIN_AGL_FT:
                    passed = False
                    notes.append(f"rolled out of the turn at {self._rollout_agl:.0f} ft AGL (must be at or above {AUTOROTATION_ROLLOUT_MIN_AGL_FT:.0f} ft)")
            notes.append("recovered to a touchdown" if state.on_ground else "recovered to a stabilized hover")
            return self._finish(passed, notes)
        return None
