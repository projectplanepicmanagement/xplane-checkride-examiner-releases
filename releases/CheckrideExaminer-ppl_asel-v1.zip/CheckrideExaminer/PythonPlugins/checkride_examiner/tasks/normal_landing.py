"""PA.IV.A (Private) / CA.IV.A (Commercial) Normal Takeoff and Climb, and
PA.IV.B / CA.IV.B Normal Approach and Landing.

ACS numbers (fetched and confirmed directly from the FAA-S-ACS-6C skill
text via cfi.treklog.com's task-by-task summaries, and cross-checked
against the OregonFlightSchool.com / solarflyer.aero secondary-source
tables already cited elsewhere in this package):
  PA.IV.A.S9/S11: "establish pitch attitude to maintain ... VY +10/-5
    knots" / "maintain VY +10/-5 knots to a safe maneuvering altitude"
    (Commercial: +/-5 knots both). No obstacle to clear here, so there's
    only ever one climb speed (Vy), not a Vx-then-Vy sequence like
    Short-Field.
  PA.IV.A.S12: "maintain directional control and proper wind drift
    correction throughout takeoff and climb" -- no explicit numeric
    heading tolerance in the ACS text itself, same situation as
    Short-Field's heading check; this uses the same hard-graded +/-10deg
    convention already established there (tasks/short_field.py).
  PA.IV.B.S6: approach speed, manufacturer's published speed or in its
    absence not more than 1.3 x Vso, +10/-5kt (Private) / +/-5kt
    (Commercial) -- identical formula to Short-Field Approach and Landing
    (see util.resolve_approach_speed).
  PA.IV.B.S9: touchdown within 400ft beyond a specified point, aligned
    with the centerline -- like Short-Field's 200ft, not gradeable
    without knowing which point on the runway the pilot aimed for, so
    this is a self-assessed note, not a hard check. Unlike Short-Field,
    Normal Landing has no specific flap-configuration requirement in its
    ACS skill list ("establish the recommended... configuration" is
    generic), so this doesn't hard-grade flaps the way Short-Field does.

**NormalLandingTask does not track heading** (unlike NormalTakeoffTask,
which legitimately does -- see PA.IV.A.S12 above). An earlier version
copied the takeoff's heading-hold check onto the landing task too, armed
on the start of descent (routinely still on downwind), and held +/-10deg
from there through the whole approach -- busting a normal downwind/base/
final pattern turn every time (user-reported, same bug in
tasks/short_field.py's landing task -- see that file's docstring for the
full writeup). PA.IV.B's landing skills (S6-S9 above) have no equivalent
heading requirement, so this was removed rather than reworked to apply
only once established on final -- there's no reliable dataref-only way to
detect "now on final" (no runway-heading dataref).

**NormalLandingTask's and NormalTakeoffTask's airspeed checks are
capture-gated** (`ToleranceTracker(..., gate_until_captured=True)`,
grading.py) -- same fix as tasks/short_field.py's identical bugs (see that
file's docstring for the full writeup). Landing arms on the start of
descent, meaning the tolerance clock used to start while still near cruise
speed on downwind, well before a pilot could realistically decelerate to
approach speed within the tracker's 3s grace period (user-reported: "Down
windではまだクルーズスピードに近いスピードも出ているだろうし"). Takeoff
has the mirror-image problem: the Vy tracker used to start counting the
instant of liftoff, before the aircraft has had time to accelerate from
rotation speed to Vy (user-reported: "Takeoff系もなんだけど速度が乗るまで
少し時間がかかる"). Both now only count deviation time once airspeed has
actually entered the target band at least once.

Both tasks reuse AircraftSettings.vy_kt (Short-Field Takeoff's Vy field --
Normal Takeoff has no obstacle-clearance Vx segment, so it only ever needs
Vy) and short_field_approach_kt (the same "published approach speed"
applies to Normal/Soft-Field/Short-Field landings alike per the identical
ACS formula) rather than adding new Settings fields for numbers that are,
in reality, the same POH figures. Vy is still mandatory
(`Task.blocking_reason()`) for the same reason as Short-Field's -- X-Plane
has no Vy dataref (confirmed against DataRefs.txt: only Vso/Vs/Vfe/Vno/Vne
exist).
"""
from ..grading import ToleranceSpec, ToleranceTracker
from ..util import heading_diff, resolve_approach_speed
from .base import Task

HDG_TOL_DEG = 10.0
CLIMB_HOLD_S = 15.0
TAKEOFF_TIMEOUT_S = 90.0

APPROACH_ARM_VS_FPM = -100.0
APPROACH_SPEED_FACTOR = 1.3
TOUCHDOWN_ADVISORY_TOL_KT = 5.0
LANDING_TIMEOUT_S = 120.0


class NormalTakeoffTask(Task):
    task_id = "normal_takeoff"
    title = "Normal Takeoff and Climb"

    def __init__(self, acs_ref: str = "PA.IV.A", tolerance_low: float = -5.0, tolerance_high: float = 10.0):
        super().__init__()
        self.acs_ref = acs_ref
        self._tol_low = tolerance_low
        self._tol_high = tolerance_high
        self._vy_kt = 0.0  # 0 = not registered for this aircraft (see configure_from_settings)
        self._phase = "ground"
        self._started_at = None
        self._hdg_t = None
        self._vy_t = None
        self._climb_started_at = None

    def configure_from_settings(self, settings) -> None:
        self._vy_kt = settings.vy_kt

    def blocking_reason(self):
        if self._vy_kt <= 0.0:
            return "This aircraft's Vy isn't set yet. Open Settings and enter it before starting Normal Takeoff."
        return None

    def instructions(self):
        if self._phase == "ground":
            return f"Apply takeoff power, rotate at the recommended airspeed, and climb at Vy ({self._vy_kt:.0f}kt)."
        return f"Hold Vy ({self._vy_kt:.0f}kt) to a safe maneuvering altitude."

    def update(self, state, dt):
        if self.blocking_reason() is not None:
            return None  # waiting on Settings -- no timer running

        if self._started_at is None:
            self._started_at = state.t
        if state.t - self._started_at > TAKEOFF_TIMEOUT_S:
            return self._finish(False, ["did not complete the takeoff and climb in time"])

        if self._phase == "ground":
            if not state.on_ground and state.vs_fpm > 100.0:
                self._hdg_t = ToleranceTracker(ToleranceSpec.symmetric("Heading", "deg", state.heading_deg, HDG_TOL_DEG), diff_fn=heading_diff)
                self._vy_t = ToleranceTracker(
                    ToleranceSpec("Airspeed", "kt", self._vy_kt, self._tol_low, self._tol_high),
                    gate_until_captured=True,
                )
                self.trackers = [self._hdg_t, self._vy_t]
                self._phase = "climb"
                self._climb_started_at = state.t
            return None

        self._hdg_t.update(state.heading_deg, dt)
        self._vy_t.update(state.ias_kt, dt)
        if state.t - self._climb_started_at >= CLIMB_HOLD_S:
            notes = []
            if not self._vy_t.captured:
                notes.append(
                    f"airspeed was never within tolerance of Vy ({self._vy_kt:.0f}kt) during the climb "
                    "(advisory only -- never captured, so nothing to grade the sustained tolerance against)"
                )
            return self._finish(True, notes)
        return None


class NormalLandingTask(Task):
    task_id = "normal_landing"
    title = "Normal Approach and Landing"

    def __init__(self, acs_ref: str = "PA.IV.B", tolerance_low: float = -5.0, tolerance_high: float = 10.0,
                 touchdown_distance_ft: float = 400.0):
        super().__init__()
        self.acs_ref = acs_ref
        self._tol_low = tolerance_low
        self._tol_high = tolerance_high
        self._touchdown_distance_ft = touchdown_distance_ft
        self._published_approach_kt = 0.0  # 0 = not registered for this aircraft
        self._started_at = None
        self._armed = False
        self._ias_t = None
        self._ias_is_advisory_only = False
        self._max_ias_dev = 0.0
        self._ias_target = None

    def configure_from_settings(self, settings) -> None:
        self._published_approach_kt = settings.short_field_approach_kt

    def instructions(self):
        return "Fly a stabilized approach at the recommended approach speed to a smooth touchdown at your aiming point."

    def update(self, state, dt):
        if self._started_at is None:
            self._started_at = state.t
        if state.t - self._started_at > LANDING_TIMEOUT_S:
            return self._finish(False, ["did not complete the approach and landing in time"])

        if not self._armed:
            if not state.on_ground and state.vs_fpm < APPROACH_ARM_VS_FPM:
                self.trackers = []
                target = resolve_approach_speed(self._published_approach_kt, state.vso_kt, APPROACH_SPEED_FACTOR)
                if target is not None:
                    self._ias_target = target
                    self._ias_t = ToleranceTracker(
                        ToleranceSpec("Airspeed", "kt", target, self._tol_low, self._tol_high),
                        gate_until_captured=True,
                    )
                    self.trackers.append(self._ias_t)
                else:
                    # neither a published speed nor Vso is available -- fall
                    # back to a self-referential target, downgraded to
                    # advisory only (same reasoning as Short-Field's).
                    self._ias_is_advisory_only = True
                    self._ias_target = state.ias_kt
                self._armed = True
            return None

        if self._ias_is_advisory_only:
            self._max_ias_dev = max(self._max_ias_dev, abs(state.ias_kt - self._ias_target))
        else:
            self._ias_t.update(state.ias_kt, dt)

        if state.on_ground:
            notes = [
                f"distance to your intended touchdown point isn't tracked -- self-assess "
                f"(ACS: within {self._touchdown_distance_ft:.0f} ft beyond/on the point)"
            ]
            if self._ias_is_advisory_only and self._max_ias_dev > TOUCHDOWN_ADVISORY_TOL_KT:
                notes.append(
                    f"approach speed drifted up to {self._max_ias_dev:.0f}kt from where it was established "
                    "(advisory only -- this aircraft doesn't report a stall speed (Vso) and no published "
                    "approach speed is set in Settings, so nothing to grade against)"
                )
            elif not self._ias_is_advisory_only and not self._ias_t.captured:
                notes.append(
                    f"approach speed was never within tolerance of the target ({self._ias_target:.0f}kt) "
                    "before touchdown (advisory only -- never captured, so nothing to grade the sustained "
                    "tolerance against)"
                )
            return self._finish(True, notes)
        return None
