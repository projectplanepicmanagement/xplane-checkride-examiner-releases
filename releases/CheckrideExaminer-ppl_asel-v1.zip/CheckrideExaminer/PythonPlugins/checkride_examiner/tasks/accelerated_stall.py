"""CA.VII.D Accelerated Stalls.

ACS (FAA-S-ACS-7B): complete no lower than 3,000 ft AGL -- higher than the
1,500 ft floor for the wings-level power-off/power-on stalls, since this
one is flown in a 45deg bank turn (CA.VII.D.S2/S4/S5); coordinated 45deg
bank turn, increasing back pressure smoothly until an impending stall;
recover at the first indication of a stall (CA.VII.D.S6/S7). The ACS gives
no numeric bank tolerance for the 45deg turn itself, so -- like Chandelles
-- bank isn't tracked as a hard bust, only the AGL floor and a prompt
recovery once the stall warning sounds (same "sustained warning = stall"
approximation used by the other stall tasks).
"""
from .base import Task

MIN_AGL_FT = 3000.0
ARM_BANK_DEG = 35.0
SUSTAINED_WARNING_S = 1.0
RECOVERY_CLEAR_S = 2.0
ARM_TIMEOUT_S = 150.0


class AcceleratedStallTask(Task):
    task_id = "accelerated_stall"
    title = "Accelerated Stall"
    acs_ref = "CA.VII.D"

    def __init__(self, direction: str = "left"):
        super().__init__()
        assert direction in ("left", "right")
        self.direction = direction
        self._sign = -1.0 if direction == "left" else 1.0
        self._phase = "setup"  # setup -> recovering
        self._warning_streak = 0.0
        self._clear_streak = 0.0
        self._setup_started_at = None

    def instructions(self):
        return (
            f"Establish a coordinated {self.direction}, 45° bank turn and increase back "
            "pressure smoothly until the stall warning sounds, then recover promptly."
        )

    def update(self, state, dt):
        if self._setup_started_at is None:
            self._setup_started_at = state.t

        if state.agl_ft < MIN_AGL_FT:
            return self._finish(False, [f"descended below the 3,000 ft AGL floor ({state.agl_ft:.0f} ft AGL)"])

        if self._phase == "setup":
            if state.t - self._setup_started_at > ARM_TIMEOUT_S:
                return self._finish(False, ["did not reach a full stall in the required configuration"])
            in_turn = self._sign * state.bank_deg > ARM_BANK_DEG
            if state.stall_warning and in_turn:
                self._warning_streak += dt
            else:
                self._warning_streak = 0.0
            if self._warning_streak >= SUSTAINED_WARNING_S:
                self._phase = "recovering"
            return None

        if not state.stall_warning:
            self._clear_streak += dt
        else:
            self._clear_streak = 0.0

        recovered = self._clear_streak >= RECOVERY_CLEAR_S and state.vs_fpm > 0.0 and abs(state.bank_deg) < 15.0
        if recovered:
            return self._finish(True, [])
        return None
