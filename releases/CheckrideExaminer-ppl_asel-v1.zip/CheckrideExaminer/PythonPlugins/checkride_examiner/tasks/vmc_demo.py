"""PA.X.B / CA.X.B VMC Demonstration (AMEL, AMES).

ACS: configure for a simulated critical-engine failure (gear up, takeoff
flaps, high-RPM props, critical engine at idle/windmilling, operating
engine at max power); establish a single-engine climb attitude; bank no
more than 5deg toward the operating engine; slowly reduce airspeed while
recognizing the first indication of a loss of directional control, stall
warning, or buffet; recover promptly and roll out within 20deg of the
entry heading. Private (FAA-S-ACS-6, PA.X.B.S8) allows +10/-5kt on the
recovery airspeed; Commercial (FAA-S-ACS-7B, CA.X.B.S8) is tighter, +/-5kt
-- `recovery_low`/`recovery_high` are the only numbers that differ between
the two ratings' versions of this task.

Simplifications: "reduce airspeed at ~1kt/sec" isn't graded directly (no
reliable way to enforce a rate without also fighting normal instrument
noise); "first indication of loss of directional control/stall
warning/buffet" is approximated as the stall warning firing, same as the
other stall-adjacent tasks.

**Recovery airspeed is graded against a registered target (e.g. Vyse), not
a self-reference.** X-Plane has no dataref for a multiengine aircraft's
Vsse/Vyse (same gap as Vx/Vy -- see short_field.py), and the real number
can vary by flight school/aircraft manufacturer on top of that, so this
reads `configure_from_settings()` (aircraft_settings.py) and **refuses to
arm at all** (`blocking_reason()`) **until it's entered for the loaded
aircraft** -- an earlier version graded recovery against whatever airspeed
was captured the instant recovery began, which never actually verified
compliance with a real target, only that speed increased somewhat.

Which engine is "the operating one" is inferred from `throttle_ratio` /
`throttle2_ratio` (engine 1 = left, engine 2 = right -- see datarefs.py),
so the correct bank direction (toward whichever engine still has power) is
known without guessing.
"""
from ..util import heading_diff
from .base import Task

IDLE_THROTTLE = 0.15
OPERATING_THROTTLE = 0.7
BANK_TOL_DEG = 5.0
RECOVERY_HEADING_TOL_DEG = 20.0
ARM_TIMEOUT_S = 150.0
RECOVERY_TIMEOUT_S = 30.0
BANK_BUST_S = 3.0


class VmcDemonstrationTask(Task):
    task_id = "vmc_demonstration"
    title = "VMC Demonstration"

    def __init__(self, acs_ref: str = "PA.X.B", recovery_low: float = -5.0, recovery_high: float = 10.0):
        super().__init__()
        self.acs_ref = acs_ref
        self._recovery_low = recovery_low
        self._recovery_high = recovery_high
        self._recovery_target_kt = 0.0  # 0 = not registered for this aircraft
        self._phase = "armed"  # armed -> entry -> recovering
        self._armed_at = None
        self._entry_heading = None
        self._entry_started_at = None
        self._operating_sign = None  # +1 if right engine operating (bank right is correct), -1 if left
        self._bank_bad_streak = 0.0
        self._recovery_started_at = None
        self._recovery_entry_ias = None

    def configure_from_settings(self, settings) -> None:
        self._recovery_target_kt = settings.vmc_recovery_kt

    def blocking_reason(self):
        if self._recovery_target_kt <= 0.0:
            return (
                "This aircraft's VMC Demonstration recovery speed isn't set yet. "
                "Open Settings and enter it (e.g. Vyse) before starting."
            )
        return None

    def instructions(self):
        if self._phase == "recovering":
            return f"Recover: reduce power on the operating engine, lower the nose, roll out on entry heading and accelerate to {self._recovery_target_kt:.0f}kt."
        if self._phase == "entry":
            return (
                f"Hold bank within 5° toward the {'right' if self._operating_sign > 0 else 'left'} "
                "(operating) engine. Slowly reduce airspeed until the first sign of a stall or loss "
                "of control, then recover."
            )
        return "Simulate a critical-engine failure: idle one engine, max power on the other, gear up, takeoff flaps."

    def update(self, state, dt):
        if self.blocking_reason() is not None:
            return None  # waiting on Settings -- no timer running

        if self._armed_at is None:
            self._armed_at = state.t
        if state.t - self._armed_at > ARM_TIMEOUT_S:
            return self._finish(False, ["never established the VMC demonstration configuration"])

        if self._phase == "armed":
            if state.throttle_ratio < IDLE_THROTTLE and state.throttle2_ratio > OPERATING_THROTTLE:
                self._operating_sign = 1.0  # right engine operating -> bank right
            elif state.throttle2_ratio < IDLE_THROTTLE and state.throttle_ratio > OPERATING_THROTTLE:
                self._operating_sign = -1.0  # left engine operating -> bank left
            else:
                return None
            self._entry_heading = state.heading_deg
            self._entry_started_at = state.t
            self._phase = "entry"
            return None

        if self._phase == "entry":
            directed_bank = state.bank_deg * self._operating_sign  # >0 = banked toward the operating engine
            if directed_bank < 0.0 or directed_bank > BANK_TOL_DEG:
                self._bank_bad_streak += dt
            else:
                self._bank_bad_streak = 0.0

            if state.stall_warning:
                self._recovery_started_at = state.t
                self._recovery_entry_ias = state.ias_kt
                self._phase = "recovering"
            return None

        # phase == recovering
        if state.t - self._recovery_started_at > RECOVERY_TIMEOUT_S:
            return self._finish(False, ["did not recover from the VMC demonstration in time"])

        recovered = not state.stall_warning and abs(state.bank_deg) < 10.0 and state.ias_kt > self._recovery_entry_ias
        if recovered:
            hdg_dev = heading_diff(state.heading_deg, self._entry_heading)
            ias_dev = state.ias_kt - self._recovery_target_kt
            notes = []
            passed = True
            if self._bank_bad_streak > BANK_BUST_S:
                passed = False
                notes.append(f"bank exceeded 5° toward the operating engine (or banked the wrong way) for {self._bank_bad_streak:.1f}s during entry")
            if abs(hdg_dev) > RECOVERY_HEADING_TOL_DEG:
                passed = False
                notes.append(f"recovered {hdg_dev:+.0f}° from entry heading (limit ±20°)")
            if ias_dev < self._recovery_low or ias_dev > self._recovery_high:
                passed = False
                notes.append(f"recovery airspeed was {state.ias_kt:.0f}kt, {ias_dev:+.0f}kt from the registered target (limit {self._recovery_low:+.0f}/{self._recovery_high:+.0f}kt)")
            if not notes:
                notes.append("recovered within tolerance")
            return self._finish(passed, notes)
        return None
