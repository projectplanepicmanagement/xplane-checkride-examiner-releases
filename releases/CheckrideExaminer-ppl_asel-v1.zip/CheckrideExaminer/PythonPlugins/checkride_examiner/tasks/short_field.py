"""PA.IV.E/F (Private) and CA.IV.E/F (Commercial) Short-Field Takeoff and
Maximum Performance Climb, and Short-Field Approach and Landing.

ACS numbers: Private's speed tolerance is asymmetric, +10/-5kt
(PA.IV.E.S9/S10/S11/S13, PA.IV.F.S7); Commercial's is tighter and
symmetric, +/-5kt (CA.IV.E.S9/S10/S11/S13, CA.IV.F.S7). Touchdown must be
within 200ft beyond/on the specified point for Private (PA.IV.F.S10),
100ft for Commercial (CA.IV.F.S10) -- NOT graded here, same reasoning as
the helicopter approach tasks: there's no way for the plugin to know which
point on the runway the pilot aimed for, so it's left as a self-assessed
note instead of a fabricated distance check.

**Approach speed IS gradeable against a real number.** The ACS's own
standard is "manufacturer's published approach airspeed or in its absence
not more than 1.3 x Vso" (PA/CA.IV.F.S7). X-Plane exposes the aircraft's
actual Vso (`sim/aircraft/view/acf_Vso`) as `state.vso_kt`, so 1.3 x Vso is
used automatically. If the pilot has entered the aircraft's real published
short-field approach speed via aircraft_settings.py (ACS-preferred over the
Vso formula), that's used instead.

**Vx/Vy climb speed has no equivalent live dataref.** Short-Field Takeoff's
ACS skills name specific speeds -- Vx (best angle of climb) and Vy (best
rate of climb) -- but unlike Vso, those are performance-chart values X-Plane
doesn't expose anywhere (confirmed against DataRefs.txt: only
Vso/Vs/Vfe/Vno/Vne exist, all structural/stall limits, not climb-performance
speeds), and the real numbers can differ by flight school on top of that.
So this task reads `state.aircraft_key` + `configure_from_settings()` (see
aircraft_settings.py / controller.py) to pick up Vx/Vy the pilot entered
once, per aircraft, in the Settings screen -- **and refuses to arm at all**
(`blocking_reason()`) **until both are entered for the loaded aircraft**,
rather than falling back to a self-referential guess: an earlier version
captured whatever speed was established right after liftoff as a stand-in
target and only reported drift from *that* as an advisory note, but that
never actually verified real Vx/Vy compliance, only that a speed was held
steady (user-requested this be a hard requirement instead).

Flap timing/configuration (`state.flap_ratio`, from
`sim/flightmodel/controls/flaprat`, generic across aircraft) IS gradeable
without any per-aircraft setup:
- Takeoff (PA/CA.IV.E.S12, "configure the airplane... after a positive rate
  of climb has been verified"): busts if flaps are retracted by more than a
  small margin before a sustained positive climb is established.
- Landing (PA/CA.IV.F.S6, "establish the recommended landing configuration"):
  busts if flaps aren't at/near full by touchdown.

(Note: holding the yoke/elevator full aft during the roll is the SOFT-FIELD
technique, not part of either short-field task's ACS skills -- these tasks
don't check control-column input.)

**ShortFieldApproachLandingTask does not track heading.** An earlier
version armed on the start of descent (vs_fpm < APPROACH_ARM_VS_FPM,
which routinely happens while still on downwind) and held +/-10deg from
whatever heading that was for the rest of the approach -- copied from
ShortFieldTakeoffTask's directional-control check without noticing the
landing task's own ACS skills (PA/CA.IV.F.S6-S10) have no equivalent
heading requirement, unlike the takeoff's "maintain directional control...
throughout takeoff and climb" (S12). A real approach turns through
downwind/base/final, so that heading check busted a perfectly normal
pattern the moment the pilot turned base (user-reported: "Short-Field LDG
のreadyボタンを押すのは基本的にDown windなんだけどHDGのせいでfailになる").
Removed rather than reworked to only apply once established on final --
there's no reliable dataref-only way to detect "now on final" (no runway-
heading dataref, same limitation as Traffic Pattern/holding tasks), so a
half-fix would just move the false-bust to wherever the heuristic guessed
wrong instead of removing it.

**ShortFieldApproachLandingTask's airspeed check is capture-gated, not
live from the moment of arming.** Same root cause as the heading bug
above: arming happens as soon as descent begins (vs_fpm <
APPROACH_ARM_VS_FPM), which is routinely still on downwind at something
close to cruise speed -- and decelerating from there to the target
approach speed takes far longer than the tolerance tracker's 3s grace
period, so the task could bust in the very first moments of the approach
purely for not having slowed down yet (user-reported: "Down windではまだ
クルーズスピードに近いスピードも出ているだろうし"). Unlike heading, this
doesn't need any runway/pattern data to fix properly:
`ToleranceTracker(..., gate_until_captured=True)` (grading.py) doesn't
start its grace-period clock until IAS has actually entered the target
band at least once (the same "capture" idea `tasks/approaches.py` already
uses for glideslope) -- before that, being fast is expected and never
counted against the pilot; after capture, the existing 3s-sustained-
deviation grading applies exactly as before (so genuinely destabilizing
after being established still busts normally). The same gate applies to
ShortFieldTakeoffTask's Vx/Vy trackers below for the mirror-image reason
(user-reported: "Takeoff系もなんだけど速度が乗るまで少し時間がかかる") --
accelerating to a climb speed right after liftoff/obstacle-clear also
isn't instant.
"""
from ..grading import ToleranceSpec, ToleranceTracker
from ..util import heading_diff, resolve_approach_speed
from .base import Task

OBSTACLE_AGL_FT = 50.0
CLIMB_ESTABLISHED_S = 3.0
FLAP_RETRACT_THRESHOLD = 0.1
VY_HOLD_S = 15.0
TAKEOFF_TIMEOUT_S = 90.0
CLIMB_SPEED_ADVISORY_TOL_KT = 5.0  # still used by ShortFieldApproachLandingTask's Vso-unavailable fallback

APPROACH_ARM_VS_FPM = -100.0
FULL_FLAP_THRESHOLD = 0.8
LANDING_TIMEOUT_S = 120.0
APPROACH_SPEED_FACTOR = 1.3  # ACS: "not more than 1.3 x Vso" when no published approach speed is available


class ShortFieldTakeoffTask(Task):
    task_id = "short_field_takeoff"
    title = "Short-Field Takeoff and Maximum Performance Climb"

    def __init__(self, acs_ref: str = "PA.IV.E", tolerance_low: float = -5.0, tolerance_high: float = 10.0):
        super().__init__()
        self.acs_ref = acs_ref
        self._tol_low = tolerance_low
        self._tol_high = tolerance_high
        self._vx_kt = 0.0  # 0 = not registered for this aircraft (see configure_from_settings)
        self._vy_kt = 0.0
        self._phase = "ground"
        self._started_at = None
        self._liftoff_flap = None
        self._climb_established_streak = 0.0
        self._flap_retracted_early = False
        self._hdg_t = None
        self._vx_t = None
        self._vy_t = None
        self._vy_started_at = None

    def configure_from_settings(self, settings) -> None:
        self._vx_kt = settings.vx_kt
        self._vy_kt = settings.vy_kt

    def blocking_reason(self):
        if self._vx_kt <= 0.0 or self._vy_kt <= 0.0:
            return (
                "This aircraft's Vx and Vy aren't set yet. Open Settings and enter "
                "both before starting Short-Field Takeoff."
            )
        return None

    def instructions(self):
        if self._phase == "ground":
            return f"Hold the brakes, apply maximum power, then rotate and climb at best angle-of-climb speed (Vx, {self._vx_kt:.0f}kt) to clear the obstacle."
        if self._phase == "vx_climb":
            return f"Hold Vx until the obstacle is cleared (50 ft AGL), then accelerate to Vy ({self._vy_kt:.0f}kt)."
        return "Climb at Vy to a safe maneuvering altitude. Only raise the flaps now that the climb is established."

    def update(self, state, dt):
        if self.blocking_reason() is not None:
            return None  # waiting on Settings -- no timer running

        if self._started_at is None:
            self._started_at = state.t
        if state.t - self._started_at > TAKEOFF_TIMEOUT_S:
            return self._finish(False, ["did not complete the takeoff and climb in time"])

        if self._phase == "ground":
            if not state.on_ground and state.vs_fpm > 100.0:
                self._liftoff_flap = state.flap_ratio
                self._hdg_t = ToleranceTracker(ToleranceSpec.symmetric("Heading", "deg", state.heading_deg, 10.0), diff_fn=heading_diff)
                self._vx_t = ToleranceTracker(
                    ToleranceSpec("Airspeed", "kt", self._vx_kt, self._tol_low, self._tol_high),
                    gate_until_captured=True,
                )
                self.trackers = [self._hdg_t, self._vx_t]
                self._phase = "vx_climb"
            return None

        self._hdg_t.update(state.heading_deg, dt)

        if not self._flap_retracted_early:
            if state.vs_fpm > 100.0:
                self._climb_established_streak += dt
            else:
                self._climb_established_streak = 0.0
            established = self._climb_established_streak >= CLIMB_ESTABLISHED_S
            if not established and (self._liftoff_flap - state.flap_ratio) > FLAP_RETRACT_THRESHOLD:
                self._flap_retracted_early = True

        if self._phase == "vx_climb":
            self._vx_t.update(state.ias_kt, dt)
            if state.agl_ft >= OBSTACLE_AGL_FT:
                self._vy_t = ToleranceTracker(
                    ToleranceSpec("Airspeed", "kt", self._vy_kt, self._tol_low, self._tol_high),
                    gate_until_captured=True,
                )
                self.trackers.append(self._vy_t)
                self._vy_started_at = state.t
                self._phase = "vy_climb"
            return None

        # phase == "vy_climb"
        self._vy_t.update(state.ias_kt, dt)

        if state.t - self._vy_started_at >= VY_HOLD_S:
            notes = []
            if self._flap_retracted_early:
                notes.append("flaps were retracted before a positive rate of climb was well established")
            if not self._vx_t.captured:
                notes.append(
                    f"airspeed was never within tolerance of Vx ({self._vx_kt:.0f}kt) before clearing the "
                    "obstacle (advisory only -- never captured, so nothing to grade the sustained tolerance against)"
                )
            if not self._vy_t.captured:
                notes.append(
                    f"airspeed was never within tolerance of Vy ({self._vy_kt:.0f}kt) during the climb "
                    "(advisory only -- never captured, so nothing to grade the sustained tolerance against)"
                )
            return self._finish(not self._flap_retracted_early, notes)
        return None


class ShortFieldApproachLandingTask(Task):
    task_id = "short_field_approach_landing"
    title = "Short-Field Approach and Landing"

    def __init__(self, acs_ref: str = "PA.IV.F", tolerance_low: float = -5.0, tolerance_high: float = 10.0,
                 touchdown_distance_ft: float = 200.0):
        super().__init__()
        self.acs_ref = acs_ref
        self._tol_low = tolerance_low
        self._tol_high = tolerance_high
        self._touchdown_distance_ft = touchdown_distance_ft
        self._published_approach_kt = 0.0  # 0 = not registered for this aircraft
        self._started_at = None
        self._armed = False
        self._ias_t = None
        self._ias_is_advisory_only = False
        self._max_ias_dev = 0.0
        self._ias_target = None

    def configure_from_settings(self, settings) -> None:
        self._published_approach_kt = settings.short_field_approach_kt

    def instructions(self):
        return "Fly a stabilized short-field approach at the recommended approach speed, full flaps, to a firm touchdown at your aiming point."

    def update(self, state, dt):
        if self._started_at is None:
            self._started_at = state.t
        if state.t - self._started_at > LANDING_TIMEOUT_S:
            return self._finish(False, ["did not complete the approach and landing in time"])

        if not self._armed:
            if not state.on_ground and state.vs_fpm < APPROACH_ARM_VS_FPM:
                self.trackers = []
                # ACS formula (PA/CA.IV.F.S7): published speed if registered
                # in Settings, else 1.3 x this aircraft's own modeled Vso.
                target = resolve_approach_speed(self._published_approach_kt, state.vso_kt, APPROACH_SPEED_FACTOR)
                if target is not None:
                    self._ias_target = target
                    self._ias_t = ToleranceTracker(
                        ToleranceSpec("Airspeed", "kt", target, self._tol_low, self._tol_high),
                        gate_until_captured=True,
                    )
                    self.trackers.append(self._ias_t)
                else:
                    # neither a published speed nor Vso is available -- fall
                    # back to a self-referential target, downgraded to
                    # advisory only (same reasoning as the takeoff task).
                    self._ias_is_advisory_only = True
                    self._ias_target = state.ias_kt
                self._armed = True
            return None

        if self._ias_is_advisory_only:
            self._max_ias_dev = max(self._max_ias_dev, abs(state.ias_kt - self._ias_target))
        else:
            self._ias_t.update(state.ias_kt, dt)

        if state.on_ground:
            notes = [
                f"distance to your intended touchdown point isn't tracked -- self-assess "
                f"(ACS: within {self._touchdown_distance_ft:.0f} ft beyond/on the point)"
            ]
            passed = True
            if state.flap_ratio < FULL_FLAP_THRESHOLD:
                passed = False
                notes.insert(0, f"touched down with flaps at {state.flap_ratio * 100:.0f}% -- short-field calls for full flaps")
            if self._ias_is_advisory_only and self._max_ias_dev > CLIMB_SPEED_ADVISORY_TOL_KT:
                notes.append(
                    f"approach speed drifted up to {self._max_ias_dev:.0f}kt from where it was established "
                    "(advisory only -- this aircraft doesn't report a stall speed (Vso) and no published "
                    "approach speed is set in Settings, so nothing to grade against)"
                )
            elif not self._ias_is_advisory_only and not self._ias_t.captured:
                notes.append(
                    f"approach speed was never within tolerance of the target ({self._ias_target:.0f}kt) "
                    "before touchdown (advisory only -- never captured, so nothing to grade the sustained "
                    "tolerance against)"
                )
            return self._finish(passed, notes)
        return None
