# Checkride Examiner 仕様書

対象: X-Plane 12 / XPPython3プラグイン「Checkride Examiner」(PPL/ASEL・PPL/AMEL・Instrument Rating・Commercial Pilot・Commercial Pilot/AMEL・PPL/Helicopter)
最終更新: このドキュメントはコードから逆生成しています。実装(`plugin/`)が正であり、齟齬があれば実装を正とします。

---

## 1. 概要

X-Plane上で仮想のDPE(操縦士技能検査官)として振る舞い、FAAのACS(Airman Certification Standards)に定められた科目を1つずつ提示し、飛行データをACSの数値許容範囲と照らして自動採点するプラグイン。地上(無線交信・タキシング・ランナップ)から始まり、空中科目(基本計器飛行・急旋回・失速・緊急降下等)へと進む、実際のチェックライドに近い一連の流れを再現する。

対象資格: 6つ。Private Pilot, Airplane Single-Engine Land (PPL/ASEL、17科目)、PPL/AMEL(PPL/ASELの17科目+多発科目3つ=20科目)、Instrument Rating - Airplane (IR、6科目)、Commercial Pilot - Airplane (CPL、13科目)、Commercial Pilot/AMEL(CPLの13科目+多発科目3つ=16科目)、Private Pilot - Helicopter (PPL/Helicopter、FAA-S-ACS-15、9科目)。チェックライドモードの画面上部にあるレーティング選択ボタンで切り替える(§2.1, §6参照)。CFIは未着手。

---

## 2. 全体フロー

### 2.1 セッションのライフサイクル

```
X-Plane起動
  → XPPython3がプラグインを自動ロード (PI_CheckrideExaminer.py)
  → XPluginEnable():
       DataRefReader / Repositioner を生成
       AppController を生成
         ├─ ExaminerSession (checkride mode, 既定rating="ppl_asel" で build_ppl_asel_syllabus() の17科目)
         └─ PracticeSession (practice mode, 開始時は非アクティブ)
         mode = "checkride" (既定)
       ExaminerOverlay を生成 (ImGuiウィンドウを作成、初期状態は非表示 visible=0)
       flight loopコールバックを毎フレーム登録
  → 以降、毎フレーム:
       DataRefReader.snapshot() で FlightState を取得
       AppController.tick(state) → mode に応じて
         checkride: ExaminerSession.tick(state)
         practice:  PracticeSession.tick(state) (アクティブな科目がある場合のみ)
  → 並行して、ImGui描画コールバックが毎フレーム呼ばれ、
       現在のmodeに応じた画面(§2.4参照)を描画する
```

**ウィンドウは既定で非表示**: `overlay.py`の`_ImguiBackend`/`_PlainBackend`はどちらもウィンドウ生成時に`visible=0`を渡す(XPPython3の`xp_imgui.Window`自体の既定値もそう)。理由: このプラグインは機体の種類を問わず毎回のフライトで有効化される(XPPython3プラグインとして常時ロードされる)ため、以前のように`visible=1`で作っていると、チェックライドと無関係な機体(例: エアラインの旅客機)で飛ぶときにも毎回ウィンドウが勝手に開いてしまっていた(ユーザー報告)。Plugins > Checkride Examiner > Show/Hide Window(`ExaminerOverlay.toggle_visible()`)で必要な時だけ明示的に開く運用に変更した。

**ホーム画面と `AppController.started` ゲート**: `AppController.__init__` は `started=False` で始まり、`tick()` は `started` が真になるまで即return(checkride/practiceどちらも一切ティックしない)。ImGui UIはウィンドウ表示直後にホーム画面(レーティング選択 + 「Start Checkride Mode」/「Start Practice Mode」ボタン)を出し、いずれかのボタンで `controller.set_mode(...)` → `controller.start()` を呼んでから初めて画面がmode別表示に切り替わる。これにより、プラグイン読み込み直後(まだ機体を選ぶ前・滑走路上で考え中など)に無自覚のうちに直線水平飛行などの採点が始まってしまうことを防ぐ。画面上部の「Home」ボタンでホーム画面へ戻れるが、これは単なる画面遷移であり `started` を戻さない(＝一度startした後はホームに戻っても両modeの進行状況は保持される)。`_PlainBackend`(pyimgui無しの文字描画フォールバック)にはクリック可能なホーム画面を出す手段がないため、生成時に即 `controller.start()` を呼び、従来通りcheckrideモードの採点をすぐ開始する。

モード切替はいつでも可能(ウィンドウ上部のボタン、またはPluginsメニュー)。切替時に他方のmodeの状態は一切リセットされない — チェックライドを中断して練習モードに入り、また戻ると中断地点から再開する。

**レーティング切替**: チェックライドモード画面には別途「Rating:」ボタン列があり、`AppController.set_checkride_rating(key)` を呼ぶ。こちらはmode切替と異なり、選択中のレーティングが変わる場合は `ExaminerSession` を新規生成して丸ごと置き換える(= 進行中のチェックライドは破棄される)。同じレーティングを選び直した場合は何もしない。

### 2.1a 機体別設定(目標速度)の永続化と必須化ゲート (`aircraft_settings.py`, `tasks/base.py`, `controller.py`)

X-Planeには`acf_Vso`(失速速度)・`acf_Vno`(構造制限速度)のdatarefはあるが、Vx/Vy(性能グラフ由来の上昇速度)・VMC Demonstrationの復帰目標速度(Vyse相当)・Slow Flightの目標速度(MCA)に相当するdatarefが存在しない(§4.6, §7参照)。加えてこれらの実際の数値はフライトスクール/機体によって異なりうる(ユーザー指摘)。この不足を埋めるため、パイロットがSettings画面で一度だけ入力した値を機体ごとに記憶する仕組みを追加した:

```
毎フレーム DataRefReader.snapshot() で aircraft_key を取得
  (xp.getNthAircraftModel(0) が返す (fileName, fullPath) のうち fileName、例: "Cessna_172SP.acf")
  → AppController.tick(state) が state.aircraft_key を前回値と比較
  → 変化していたら(初回ロード含む): self.aircraft_key を更新し _apply_settings() を実行
       _apply_settings(): AircraftSettingsStore.get(aircraft_key) で AircraftSettings を取得し、
       現在のcheckrideセッションの全タスク + practiceのアクティブタスクへ
       Task.configure_from_settings(settings) を呼ぶ(基底実装はno-op、
       ShortFieldTakeoffTask/ShortFieldApproachLandingTask/VmcDemonstrationTask/
       SlowFlightTaskのみ override)
```

`_apply_settings()` は他に、`set_checkride_rating()`(セッション再生成直後)・`restart()`(タスクリスト再構築直後)・`start_practice()`/`retry_practice()`(新しいTaskインスタンス生成直後)からも呼ばれる — 「タスクが新規に作られた直後は必ず現在の設定を反映する」という一貫したルールにしている。これにより、機体を認識する前にセッションが組み立てられていても、設定画面で保存した瞬間に**既存のタスクインスタンスへ即座に反映**される(`save_aircraft_settings()`が`_apply_settings()`を呼ぶため)。

保存先は `AircraftSettingsStore`(`aircraft_settings.py`、xp非依存・純Python・テスト可能)。JSONファイルとして `dirname(xp.getPrefsPath())`(X-Planeの設定フォルダ、プラグイン本体のフォルダの外)に保存するため、INSTALL.txtの更新手順(`checkride_examiner/`フォルダを丸ごと上書き)で消えることはない。`path=None` で構築すると完全にメモリ内のみで動作する(テスト用、および万一パス解決に失敗した場合のフォールバック)。壊れた/読めないJSONファイルは例外を投げず空として扱う。

**必須項目とブロッキングゲート**: `AircraftSettings`の5フィールドのうち`vx_kt`/`vy_kt`/`vmc_recovery_kt`/`slow_flight_kt`の4つは**必須**(0のままだと対応する科目が一切開始できない)。`short_field_approach_kt`のみ任意(0なら`1.3 x Vso`という実測データに基づく妥当な自動フォールバックが既にあるため、§8参照)。必須化は`Task.blocking_reason()`(`tasks/base.py`、no-opがデフォルト)で実装している:

```
Task.blocking_reason() -> Optional[str]:
  対応する設定値が未登録(0)なら理由メッセージを返す。登録済みならNone。

HoldTask.update() (base.py):
  armedフェーズの最初に blocking_reason() をチェックし、None でなければ
  即座に None を返す(_armed_at を一切セットしない)。
  → ARM_TIMEOUT_S のカウントダウンがブロック中は絶対に始まらない
    (設定不足はパイロットの操縦ミスではないため、タイムアウト失敗に
    絶対になってはいけない、という設計)。

ShortFieldTakeoffTask / VmcDemonstrationTask (HoldTaskではない独自update()):
  同じパターンを手動で update() の先頭に実装(_started_at/_armed_at を
  ブロック中はセットしない)。
```

UI側では`overlay.py`の`_draw_checkride`/`_draw_practice_running`/`_PlainBackend._draw`が現在のタスクの`blocking_reason()`を毎フレームチェックし、Noneでなければ通常の指示文・許容範囲バー・Readyゲートの代わりに赤字の「SETTINGS REQUIRED」バナー+メッセージ+「Open Settings」ボタン(ImGui版のみ、クリックで`_open_settings()`)を表示する。Skip Task/Restart Sessionは引き続き押せるため、今すぐ設定したくない場合の抜け道は残している。プレーンテキスト版はテキスト入力欄が無いため「ImGui UIが必要」という案内のみ表示し、恒久的にブロックされたままになる。

### 2.1b 科目間のReadyゲート (`sequence.py`, `controller.py`, `PI_CheckrideExaminer.py`)

Checkride Modeで1科目が終了した瞬間、次の科目がすぐさま自分のarm条件の監視を始めると、直前の科目の「まだ回復しきっていない」状態(失速からの回復中、急旋回のロールアウト直後など)がそのまま次科目のarm条件を満たしてしまい、実質的に「移動していないのに採点対象に入ってしまう」問題があった(ユーザー報告 — Practice Modeのテレポート後`SETTLE_S`と同種の問題が、Checkride Modeでは科目間の遷移というまったく別の場面で発生していた)。

最初の対策として固定5秒のタイマー(`STABILIZE_S`)を入れたが、これもユーザー指摘で不十分と判明: 科目によって回復に必要な時間はまちまちで(失速からの回復とATCクイズの回答を同じ5秒で扱うのは不自然)、固定時間では短すぎたり逆に無駄に待たされたりする。実際のDPEは「レディ」の声を待ってから次の科目の計測を始める — つまり本質的にパイロット主導であり、タイマーで代替するものではなかった。

そこでタイマーを完全に廃止し、パイロットが明示的に「Ready」ボタン(または`checkride/examiner/ready`コマンド)を押すまで次科目の`Task.update()`を一切呼ばない方式に変更した。タイムアウトは無い — 何ティック待たされようと、`ready()`が呼ばれるまで次科目は一切動き出さない。

```
_advance(result):
  results.append(result); index += 1; _last_t = None
  index >= len(tasks) なら finished = True
  そうでなければ:
    次科目が quiz(answer属性を持つ)でなければ _waiting_for_ready = True
    (quizは直前科目の残存状態と無関係なので、Ready不要で即回答できる)

ready():  # パイロット操作。AppController.mark_ready() → ExaminerSession.ready()
  _waiting_for_ready = False

tick(state):
  ...
  if _waiting_for_ready: return (task.update()を呼ばない。_last_tも更新しない)
  result = task.update(state, dt)
  result があれば _advance(result)
```

`_last_t`は待機中ずっとNoneのまま更新しない — `ready()`が呼ばれた後の最初の`tick()`で改めて`_last_t = state.t`をセットするため、どれだけ長く待とうと最初のdtスパイクは発生しない(Practice Modeの`SETTLE_S`と同じ配慮)。科目が終了する経路は3つ(`tick()`内でのTaskResult確定、`submit_answer()`でのクイズ回答確定、`skip_current()`)あるが、すべて共通の`_advance(result)`メソッドを経由するようリファクタリング済みなので、Readyゲートの起動漏れは起きない。

セッションの最初の科目には先行科目が無いため、`_waiting_for_ready`は`__init__`で`False`のまま — 開始直後から即座に監視が始まる。`ExaminerSession.is_waiting_for_ready`(bool)をUI向けに公開しており、`overlay.py`の両バックエンドとも待機中は「Get set up for this task」+ Readyボタン(ImGui版)または「bind checkride/examiner/ready to a key」の案内(プレーンテキスト版、クリック可能領域が無いため)を表示する。`AppController.mark_ready()`がCheckride Mode限定でセッションへ橋渡しする(Practice Modeでは無視)。ウィンドウ内のReadyボタンはSkip/Restartボタンと同じ流儀で`session.ready()`を直接呼ぶ(`controller`を経由しない)。

### 2.1c シリアルキーによるライセンス認証 (`license.py`, `controller.py`, `overlay.py`)

配布用プラグインとしてシリアルキー認証を追加した。プラグインはネットワークアクセス無しで動作する前提のアドオンなので、サーバーへ問い合わせる方式は採れない — 代わりに完全オフラインで検証できる「鍵付きチェックサム」方式にした:

```
generate_key():  # 開発者専用 (tools/generate_license_key.py)
  payload = 6バイトの乱数
  checksum = HMAC-SHA256(_SECRET, payload) の先頭4バイト
  10バイト(payload+checksum, ちょうど80bit)をCrockford base32(紛らわしい I/L/O/U を除いた32文字)で16文字にエンコードし、4文字ずつ"-"区切りで整形

is_valid_key(raw):
  raw を正規化(大文字化・"-"や空白を除去)して16文字か確認
  base32デコードしてpayload/checksumに分割
  HMAC-SHA256(_SECRET, payload)の先頭4バイトを再計算し、hmac.compare_digestで一致を確認
```

`_SECRET`は`license.py`にハードコードされた固定バイト列。この方式の限界を隠さず明記する: `license.py`はコンパイルされたバイナリではなく配布物にそのまま入る平文のPythonソースなので、ファイルを開いて`_SECRET`を読めば誰でも有効な鍵を自作できる(§8参照)。これはタイプミス・当て推量・鍵の意図しない使い回しを防ぐ程度のものであり、ソースを読む気のある相手を止めるものではない。より強固にするにはサーバー側検証が必要だが、それはオフライン動作という前提と矛盾する。

```python
class LicenseStore:
    # aircraft_settings.AircraftSettingsStoreと同じ
    # atomic-write・壊れたファイル耐性・path=Noneでメモリ内動作 のパターン
    def is_activated -> bool:  # 保存済みキーをis_valid_key()で毎回再検証(フラグを信用しない)
    def activate(raw_key) -> bool: ...  # 有効な鍵のみ保存し True、無効なら何もせず False
```

保存先は`AircraftSettingsStore`と同じ`dirname(xp.getPrefsPath())`(X-Planeの設定フォルダ)、ファイル名は`Checkride Examiner License.json`。一度有効化すれば有効期限も失効も無く、プラグイン更新後も引き継がれる。

`AppController.is_licensed`(`LicenseStore.is_activated`をそのまま返す)が実際のゲート:

```
start():          if not is_licensed: return  # 何もせず抜ける
start_practice(): if not is_licensed: return  # 同上
```

UI側(`overlay.py`の`_show_settings`/`_home`判定より手前)で`not controller.is_licensed`ならライセンス入力画面を優先表示するが、ゲートの実体はUIではなく`AppController`側にあるため、画面遷移の実装ミスがあっても未認証コピーが採点を開始することは無い。プレーンテキスト版バックエンド(ImGui無し)はテキスト入力ウィジェットが無いため、「ImGui UIが必要」という案内のみ表示する。

配布物からは`tools/generate_license_key.py`(鍵生成スクリプト、開発者専用)を`package.sh`で除外している — これを顧客に渡すと`_SECRET`を直接渡すのと同じことになり、無制限に鍵を自作されてしまうため。

**鍵自体にレーティング制限を埋め込む(§8の「フルビルド流出」インシデントを受けた対策)**: `edition.py`の`SHIPPED_RATINGS`は「このビルドが何を見せるか」しか決められず、「このキーは何を買った人のものか」を一切知らない。そのため、万一より広いレーティングを見せるビルドが再び到達可能になった場合(実際に一度起きた)、正規のキーを持つ顧客がそのビルドを入れるだけで、買っていないレーティングまで解放されてしまう。これを塞ぐため、payload先頭バイトの最上位ビット(bit7)を「このキーはレーティング制限を持つ」フラグとして使い、bit0〜5に`_RATING_BITS`(`("ppl_asel", "ppl_amel", "ir", "cpl", "cpl_amel", "ppl_helicopter")`、一度出荷したら順序を変更してはいけない)のビットマスクを埋め込むようにした:

```
generate_key(ratings=None):
  payload = 6バイトの乱数
  if ratings is None:
    payload[0]のbit7を明示的に0にクリア  # 旧来のキーと同じ「制限なし」を表す
  else:
    payload[0] = 0x80(bit7) | ratingsのビットマスク(bit0-5)
  以降はchecksum計算・base32エンコードとも既存のgenerate_key()と全く同じ
    (checksumはpayloadのバイト列に対して計算するだけなので、
     ビットの意味付けが変わってもchecksum計算自体は無変更)

decode_licensed_ratings(raw) -> Optional[Tuple[str, ...]]:
  is_valid_key()と同じchecksum検証を内部で共有(_verified_payload())
  検証NGならNone
  bit7が0ならNone(=レガシーキー、制限なし。既存に発行済みの全キーはこちら)
  bit7が1ならbit0-5から_RATING_BITSの該当キーをタプルで返す
```

後方互換性は完全に保たれる: `generate_key()`を引数無しで呼ぶ(=このフィーチャー実装前からの唯一の呼び方)と、bit7を明示的に0にクリアするので、既に発行済みの全キーは「制限なし」として動作し続ける(再発行は不要)。`LicenseStore.licensed_ratings`(未認証時はNone)→`AppController.licensed_ratings`→`overlay.py`の3箇所の`visible_ratings(RATINGS, controller.licensed_ratings)`という経路で伝播し、`edition.visible_ratings()`が「ビルドが見せる範囲」と「キーが許可する範囲」の**両方の積集合**を最終的な選択可能レーティングとする(§2.1e参照)。`tools/generate_license_key.py --ratings ppl_asel`のようにCLIから直接指定できる。

### 2.1d 自前アップデート機構 (`updater.py`, `_version.py`, `controller.py`, `overlay.py`)

配布は当初SkunkCrafts Updater(X-Plane payware業界の事実上標準)への相乗りを検討したが、プラグイン単体の登録には唯一の管理者への個別連絡(Discord DM)が必要で公開の自己申請フローが存在しないことが判明した(2024年11月〜2026年1月の複数のフォーラムスレッドで同じ回答が繰り返されている)。これに配布をブロックされないため、Python標準ライブラリのみ(`urllib`/`json`/`zipfile`/`shutil` -- XPPython3の組み込みインタプリタに既に含まれる)で完結する自前の機構を実装した。

```
UpdateChecker(plugins_root, current_version, fetch_json=..., download=...):
  check() -> UpdateInfo | None:
    data = fetch_json(MANIFEST_URL)  # 公開の配布専用リポジトリのmanifest.json
    info = parse_manifest(data)      # 必須フィールド欠如などはUpdateErrorとして安全にラップ
    return info if info.version > current_version else None  # Noneは「最新」

  apply(info):
    zipをdownload() → 一時ディレクトリに展開
    展開結果が CheckrideExaminer/PythonPlugins/checkride_examiner/ と
      .../PI_CheckrideExaminer.py の想定レイアウトを持つか検証
      (無ければUpdateError、既存インストールには一切触れない)
    検証OKになって初めて実際の checkride_examiner/ フォルダとPI_CheckrideExaminer.pyを置き換え
```

`fetch_json`/`download`は関数として注入可能(デフォルトは実際の`urllib`呼び出し)-- これにより`tests/test_updater.py`はネットワーク無しで検証ロジック・展開ロジックの両方を実際にテストできる(不正なzipレイアウトを与えて「既存インストールが一切変更されないこと」まで確認済み)。

`MANIFEST_URL`は開発用のプライベートリポジトリとは別に用意した公開の配布専用リポジトリ(`xplane-checkride-examiner-releases`)を指す -- プライベートリポジトリのraw/Release URLは匿名の利用者からは認証無しで取得できないため、この分離は必須。`manifest.json`は`{"version": N, "zip_url": "...", "notes": "..."}`という最小限の形式で、配布専用リポジトリの`releases/`フォルダに実際のzipも一緒にコミットしてある。

**絶対規則: フルビルド(`--ratings`無し、全レーティング解放)をこの公開リポジトリ(または顧客のupdaterが到達しうるいかなる場所)に置いてはならない。** レーティング別の個別販売を構想しているため、あるエディションの購入者が「買っていないレーティング」まで解放されたビルドを更新経由で受け取ることは絶対に起きてはいけない(§2.1e参照)。この規則は一度破られた: PPL/ASELエディション(V1)を1つだけ販売/配布していた段階で、開発中に複数回フルビルド(v9・v10・v11・v23・v24)を誤ってこの公開リポジトリにpushしてしまっていた -- manifest.jsonがフルビルドのzipを指していたため、V1所持者が「Check for Updates」→「Download and Install」を押すと気づかないうちに全レーティング解放版に置き換わってしまう状態だった。ユーザー指摘(「フルビルドは絶対に公開されちゃダメ 別売りを構想してるし」)を受けて、当時リポジトリの現在のツリーに存在していたフルビルドのzipを全て削除し、PPL/ASEL制限版のzip(`CheckrideExaminer-ppl_asel-v26.zip`)のみを再publishした。ただし**gitの過去コミット履歴には該当ファイルがまだ残っている**(historyの書き換え=force pushは別途明示的な許可が無い限り行っていない、§8参照)。再発防止として、`package.sh`は`--ratings`無しの(フルビルドの)zipを作るたびに、公開リポジトリへpushしてはいけない旨の警告を出力するようにした。

**手動・利用者起動のみ、起動時の自動チェックは無い**。SkunkCrafts Updater自身のドキュメントが(旧・インゲームプラグイン版について)「リモートサーバーが応答しない場合、X-Planeは数分間応答不能になる」と明記している通りの失敗モードを、起動時の自動チェックという設計そのもので避けている -- ボタンクリック1回が固まるだけで、X-Plane起動自体を巻き込まない。

`AppController.check_for_update()`/`apply_update()`は例外を一切外に投げない(内部でtry/exceptして文字列化されたエラーメッセージを返す)-- ネットワーク障害はここでは「起こりうる通常の結果」であり、バグではないため、既存の`activate_license()`などと同じ「このクラスの境界を越えて例外を投げない」という規約に合わせた。

`PLUGIN_VERSION`(`_version.py`)は`package.sh`実行毎に`VERSION`と同じ値へ自動的に上書き生成される -- `VERSION`自体は配布zipに含まれないビルド専用ファイルなので、実行時にプラグイン自身が「今の自分のバージョン」を知るための専用の小さいファイルを別途用意した。

更新の反映には再起動または`Plugins > Plugin Admin > Reload Scripts`が必要(実行中に自分自身のインポート済み`.py`ファイルを書き換えても、Pythonインタプリタは次のインポートまで新しい内容を読まないため)-- `apply()`自体はこれを利用者に強制できないので、`overlay.py`の更新画面がインストール成功後に明示的にその旨を案内する。

**TLS証明書検証(`cacert.pem`)**: 実機のXPPython3上で「Check for Updates」実行時に`CERTIFICATE_VERIFY_FAILED: unable to get local issuer certificate`が実際に発生した(ユーザー報告)。事前にSPECにも「開発機のpython.orgインストーラー版Python 3.13で同様のエラーを確認済み、環境依存のリスクとして未確認のまま記載」としていたものが、実際にXPPython3の同梱インタプリタでも再現した形。これはXPPython3の組み込みPythonが、プラットフォームによってはルートCA証明書を一切持たない状態でビルドされている(python.org公式macOS版インストーラーが同じ問題で悪名高いのと同種の症状)ことを意味する。対策として、`certifi`プロジェクトが配布している標準的なMozillaルート証明書バンドルを`checkride_examiner/cacert.pem`として静的ファイルのままプラグインに同梱し(pip依存にはしない -- XPPython3の環境に`pip install`できる保証が無いため)、`updater.py`のHTTPS通信全てで`ssl.create_default_context(cafile=cacert.pemのパス)`を明示的に使うようにした:

```
_ssl_context() -> ssl.SSLContext:
  cacert.pem が存在すれば ssl.create_default_context(cafile=cacert.pemのパス) を返す
  存在しなければ(万一同梱ファイルが欠落していた場合のみ)ssl.create_default_context() にフォールバック
    -- インタプリタ自身の信頼ストアに委ねる、証明書検証を無効化するわけではない

_default_fetch_json() / _default_download(): urlopen(..., context=_ssl_context())
```

証明書検証そのものを無効化するフォールバック(`ssl._create_unverified_context()`等)は意図的に採用していない -- `apply()`は実行可能なPythonコードをダウンロードしてそのままインストールする処理であり、検証を外すと中間者攻撃で任意のコードを注入されるリスクに直結するため。実際にこの修正を、最初に`CERTIFICATE_VERIFY_FAILED`を再現した開発機のPython環境に対して再度end-to-endで検証し、正常に動作することを確認済み(`tests/test_updater.py`でも、cacert.pemの実在・証明書数・`_ssl_context()`が`CERT_REQUIRED`を維持していることをオフラインで検証)。

`cacert.pem`はある時点のスナップショットであり、ルート証明書は時間とともに失効・更新される。更新が必要になったら、`python3 -c "import certifi; print(certifi.where())"`(要`pip install certifi`)が指すファイルをそのまま`checkride_examiner/cacert.pem`に上書きコピーすればよい(`certifi`パッケージ自体をXPPython3に同梱する必要はない、あくまでファイルの中身を定期的に取ってくるだけ)。

**既知のギャップ: 現状`manifest.json`は1本しか無く、エディションを区別しない。** PPL/ASELエディションしか販売していない今はこれで問題ない(唯一のmanifestがPPL/ASEL制限版を指している)。しかし2種類目以降のエディション(別の単一レーティング、または複数レーティングのバンドル)を販売し始めた瞬間、共有の単一manifestではPPL/ASEL購入者とそれ以外の購入者を区別できなくなる -- 片方が更新を受け取れないか、最悪の場合(上記の絶対規則違反と同じ形で)買っていないレーティングまで解放されたビルドを受け取ってしまう。2つ目のエディションを販売する前に、エディションごとのmanifest(例: `manifest-<edition key>.json`、`updater.py`が`edition.py`の`SHIPPED_RATINGS`/明示的なエディションキーからURLを導出する)を実装する必要がある -- 現時点では未着手。

### 2.1e 限定エディション(レーティング制限)ビルド (`edition.py`, `overlay.py`, `package.sh`)

「PPL(ASEL)のExamとPractice版だけパッケージ化」のような、特定レーティングだけを選べるビルドを作る仕組み。全レーティングのタスク/シラバスのコード自体は常に同梱される(エディションごとにコードを分割するのは、`sequence.py`/`practice.py`のトップレベルimportを重複させるか条件付きimportにするかしか無く、複雑さに見合わない -- ソース自体はどのみち難読化されていないため、隠す意味も薄い。§8のlicense.pyの既知の制限と同じ理由)。UIで選べるレーティングだけを制限する。

```
edition.py:
  SHIPPED_RATINGS: Optional[Tuple[str, ...]] = None  # None = 全レーティング(デフォルト、フルビルド)

  visible_ratings(all_ratings, licensed_ratings=None) -> dict:
    SHIPPED_RATINGSがNoneならall_ratingsをそのまま(コピー)、そうでなければ
      all_ratingsのうちSHIPPED_RATINGSに含まれるキーだけを、all_ratingsの並び順を保ったまま
    さらに licensed_ratings が None でなければ、その結果を licensed_ratings とも積集合を取る
      (licensed_ratings は AppController.licensed_ratings、つまりアクティベート済み
       キーが§2.1cのdecode_licensed_ratings()で復元した許可レーティング -- Noneは
       「レガシーキー、キー側の制限は無し」を意味し、ビルド側の制限だけが効く)
```

つまり最終的に選べるレーティングは**「ビルドが見せる範囲」∩「キーが許可する範囲」**という2層構成になっている。ビルド側だけの制限では、§8のインシデントのように「より広いビルドが誤って到達可能になった」場合に無力だったため、キー側にも独立した制限を持たせた(§2.1c参照)。

`overlay.py`のレーティング選択箇所3箇所(ホーム画面・チェックライドモードの上部バー・練習モードのカタログフィルタ)はすべて`RATINGS.items()`を直接使わず`visible_ratings(RATINGS, controller.licensed_ratings).items()`を使う -- これによりPractice Modeのカタログフィルタも、制限されたレーティングしか選べない以上、自動的にそのレーティングのタスクしか出てこなくなる(`practice.py`自体は無変更)。

ビルドコマンド: `./package.sh --ratings ppl_asel --label V1` のように`--ratings`(カンマ区切りのRATINGSキー)と`--label`(zipファイル名、省略時は`--ratings`から自動生成)を指定する。`--label`は内部のビルド番号(`VERSION`、更新チェックに使う`PLUGIN_VERSION`)とは独立した、顧客向けの表示名として扱う設計 -- `VERSION`自体はエディションに関わらず`package.sh`実行のたびに通常通りインクリメントされ続ける。

`edition.py`の書き換え(`sed`によるSHIPPED_RATINGS行のみの置換、docstring等は保持)は`install.sh`(オフラインテスト実行+ローカルX-Planeへの同期)より**後**、ステージング/zip作成の直前にのみ行い、`trap ... EXIT`でビルド成功・失敗いずれの場合も必ずデフォルト値(`None`)へ復元する。これにより、限定エディションをビルドしても開発中のローカルX-Plane環境やテストスイートの実行内容は常にフル(全レーティング)のままで、意図せず制限されたままにならない。

### 2.1f Pre-flight Check(両モード共通) (`controller.py`, `overlay.py`)

旧実装は「Start Checkride Mode」を押した瞬間に`AppController.start()`を呼んでいたため、必須設定(§2.1a参照)が未登録のタスクは、そのタスクの番が回ってきた時点で初めて赤い「SETTINGS REQUIRED」バナーが表示される仕様だった。これはパイロット目線では「何科目か進めた後に突然中断される」という体験になっていた(ユーザー報告: 「速度系が入ってないとマニューバ前に言われる」)。修正として、「Start Checkride Mode」/「Start Practice Mode」とセッション開始の間にPre-flight Checkという画面を挟むようにした。当初はCheckride Modeのみが対象だったが、Practice Modeでも複数のカタログエントリを渡り歩く中で同じ「突然中断される」体験が起きうるとしてユーザーから追加要望があり、両モード共通の仕組みに拡張した:

```
AppController.checkride_blocking_reasons() -> List[str]:
  現在の checkride セッション(session.tasks、レーティング切り替え直後の
  _apply_settings() 済みの状態)の全タスクについて blocking_reason() を呼び、
  Noneでないものを重複排除しつつ収集して返す

AppController.practice_blocking_reasons(rating) -> List[str]:
  PRACTICE_CATALOG のうち rating が entry.ratings に含まれる全エントリについて、
  entry.factory() で使い捨てのTaskインスタンスを作り、
  現在の機体のAircraftSettingsをconfigure_from_settings()で適用したうえで
  blocking_reason() を呼ぶ(このインスタンス自体は開始も採点もされず捨てられる)。
  Noneでないものを重複排除しつつ収集して返す -- checkride版との違いは
  「既存のタスクインスタンス一覧を見るだけ」か「カタログから都度使い捨てを作る」かだけ

overlay.py 「Start Checkride Mode」/「Start Practice Mode」ボタン共通:
  旧: (rating/mode設定) → controller.start() → ホーム画面を閉じる
  新: (rating/mode設定) → ホーム画面を閉じる → _preflight_check = True
      (controller.start() はこの時点ではまだ呼ばない)

_draw_preflight_check():
  is_practice = controller.mode == MODE_PRACTICE
  rating = self._practice_rating_filter if is_practice else controller.checkride.rating
  blocking_reasons = (
    controller.practice_blocking_reasons(rating) if is_practice
    else controller.checkride_blocking_reasons()
  )
  if blocking_reasons:
    赤字で "SETTINGS REQUIRED BEFORE STARTING" + 理由を全件列挙 + [Open Settings] [Back to Home]
    (Settingsを保存して戻ってきても _preflight_check は True のままなので、
     次フレームで自動的に再評価される -- 明示的な「戻り先」管理は不要)
  else:
    このレーティングに登録済みの Vx/Vy/VMC復帰速度/Slow Flight目標/Short-Field進入速度を一覧表示
    [Confirm and Start] を押すと初めて controller.start() を呼び、_preflight_check = False
```

`_draw_content()`のディスパッチ順は `ライセンス → Settings → Weather → Updates → Pre-flight Check → Home → (通常のチェックライド/練習画面)`。`_show_settings`/`_show_weather`/`_show_update`が`_preflight_check`より手前にあるため、Pre-flight Check画面からSettings/Weather/Updatesを開いても、閉じれば自動的にPre-flight Checkへ戻る(既存の画面遷移の仕組みをそのまま流用しているだけで、新たな「戻り先」状態を追加していない)。`_preflight_check`という単一のフラグと`_draw_preflight_check()`という単一の描画関数を両モードで共有し、`controller.mode`で内部分岐しているだけで、Practice Mode専用の別画面は新設していない。

`checkride_blocking_reasons()`/`practice_blocking_reasons()`はどちらもオフラインでテスト可能(`tests/test_aircraft_settings.py`、`tests/test_practice_mode.py`)-- 未登録時に少なくとも1件返ること、全項目登録後に空リストになること、同一文言の重複が排除されること、存在しないレーティングを渡すと(該当エントリが無いため)空リストになることを検証している。

### 2.2 科目1つのライフサイクル(内部状態)

科目(Task)は自分自身で以下の状態遷移を持つ。パターンは大きく3種類:

**A. HoldTask 型**(直線水平飛行・上昇・降下・低速飛行など)
```
armed (開始条件待ち)
  → _arm_condition(state) が True になったら _on_arm(state) で基準値を記録
  → holding (HOLD_SECONDS 秒間、許容範囲を継続監視)
  → HOLD_SECONDS 経過で採点確定 → 完了
  ※ ARM_TIMEOUT_S 以内に armed → holding に遷移しないとその時点で不合格終了
```

**B. 個別state machine型**(急旋回・失速・緊急降下・地上目標旋回・方位旋回・タキシー・ランナップ)
科目ごとに専用の状態遷移を実装(詳細は §4 参照)。

**C. MultipleChoiceTask 型**(ATC交信クイズ)
```
表示 (問題文 + 4択)
  → update() では絶対に完了しない (飛行データを見ない)
  → ExaminerSession.submit_answer(index) が呼ばれて初めて採点・完了
```

### 2.3 PPL/ASELの科目順序 (`sequence.py: build_ppl_asel_syllabus()`)

| # | 科目 | 種別 | フェーズ |
|---|------|------|----------|
| 1 | Contact Ground (ATCクイズ) | MultipleChoiceTask | 地上 |
| 2 | Taxi | 個別 | 地上 |
| 3 | Before-Takeoff Run-Up | 個別 | 地上 |
| 4 | Contact Tower (ATCクイズ) | MultipleChoiceTask | 地上 |
| 5 | Short-Field Takeoff and Maximum Performance Climb | 個別(3段階: ground→vx_climb→vy_climb) | 離陸 |
| 6 | Constant Airspeed Climb | HoldTask | 空中 |
| 7 | Straight-and-Level Flight | HoldTask | 空中 |
| 8 | Turns to Headings | 個別 | 空中 |
| 9 | Steep Turn (Left, 45°) | 個別 | 空中 |
| 10 | Steep Turn (Right, 45°) | 個別 | 空中 |
| 11 | Maneuvering During Slow Flight | HoldTask | 空中 |
| 12 | Power-Off Stall | 個別 | 空中 |
| 13 | Power-On Stall | 個別 | 空中 |
| 14 | Constant Airspeed Descent | HoldTask | 空中 |
| 15 | Turns Around a Point | 個別 | 空中 |
| 16 | Emergency Descent | 個別 | 空中 |
| 17 | Traffic Pattern | 個別(§4.2b参照) | 場周 |
| 18 | Go-Around/Rejected Landing | 個別(2段階: approach→climbing) | 着陸帯 |
| 19 | Normal Approach and Landing | 個別 | 着陸 |
| 20 | Normal Takeoff and Climb | 個別(1段階、Vx区間なし) | 離陸 |
| 21 | Soft-Field Approach and Landing | 個別(yoke_pitch_ratioでロールアウト判定) | 着陸 |
| 22 | Soft-Field Takeoff and Climb | 個別(yoke_pitch_ratioで地上滑走判定) | 離陸 |
| 23 | Short-Field Approach and Landing | 個別 | 着陸 |

**空中フェーズの並びはACS原文の章立て順ではない**(ユーザー報告で判明した問題への対処): ACS原文はArea VIII(Basic Instrument Maneuvers = Straight-and-Level・Climbs・Descents・Turns to Headings)を4つまとめて、Area IV(離着陸)の直後に置いている。この通りの順序で実装すると、Short-Field Takeoffの上昇直後にConstant Airspeed Descent(降下科目)が来てしまい、「離陸した直後になぜ降下を要求されるのか」という不自然な流れになっていた。対策として、離陸後は高度を要する科目(上昇・直線水平・旋回・急旋回・低速飛行・失速)をまとめて先に消化し、降下が実際に必要になったタイミング(地上目標旋回の高度へ向けて)で初めてConstant Airspeed Descentを挟み、Emergency Descentは着陸前の最後に置くよう並べ替えた。高度が前半で上がり後半で下がる、実際のチェックライドに近い流れになっている(ACS文書の章立てを機械的になぞった結果の「上げ下げの往復」を避けた)。

**#17-23の着陸フェーズブロック**(ユーザー要望により追加): 実際の複数回着陸を伴うチェックライドの流れ(場周へ再進入 → 1回は着陸復行 → 各離着陸方式をタッチ・アンド・ゴーで順に実施 → 最後にフルストップ)を模して、場周経路 → 着陸復行 → 通常進入・着陸 → 通常離陸 → 軟land進入・着陸 → 軟地離陸 → (既存の)Short-Field進入・着陸、の順に並べた。Vx/Vyと同様、Normal/Soft-Field Takeoff・Go-AroundはいずれもVy(`vy_kt`)を、Normal/Soft-Field LandingはShort-Fieldと同じ`short_field_approach_kt`を流用する(§2.1a参照、実機のPOH数値は着陸方式に関わらず同じ値のため)。

### 2.3b IRの科目順序 (`sequence.py: build_ir_syllabus()`)

| # | 科目 | 種別 | ACS参照 |
|---|------|------|----------|
| 1 | Compliance with ATC Clearances (クリアランス復唱クイズ) | MultipleChoiceTask | IR.III.A |
| 2 | Intercepting and Tracking a Navigation Course | HoldTask | IR.V.A |
| 3 | Holding Procedure | 個別 | IR.III.B |
| 4 | Non-precision Approach | 個別(3段階) | IR.VI.A |
| 5 | Precision Approach (ILS) | 個別(2段階) | IR.VI.B |
| 6 | Missed Approach | HoldTask | IR.VI.C |

VOR/ローカライザー/グライドスロープ(NAV1のみ)を使用。GPS/RNAV進入、DME arc、周回進入(Circling Approach)、進入後の着陸(Landing from an Instrument Approach)、Area VII(緊急操作: 通信途絶・エンジン故障等)は未実装。

### 2.3c CPLの科目順序 (`sequence.py: build_cpl_syllabus()`)

| # | 科目 | 種別 | ACS参照 |
|---|------|------|----------|
| 1 | Short-Field Takeoff and Maximum Performance Climb | 個別(`ShortFieldTakeoffTask`、PPLと同じクラス) | CA.IV.E |
| 2 | Steep Turn (Left, 50°) | 個別(`SteepTurnTask`を`target_bank=50`で流用) | CA.V.A |
| 3 | Steep Turn (Right, 50°) | 同上 | CA.V.A |
| 4 | Chandelle (Left) | 個別 | CA.V.C |
| 5 | Chandelle (Right) | 個別 | CA.V.C |
| 6 | Lazy Eight (Left) | 個別 | CA.V.D |
| 7 | Lazy Eight (Right) | 個別 | CA.V.D |
| 8 | Maneuvering During Slow Flight (Commercial) | HoldTask(`SlowFlightTask`のサブクラス) | CA.VII.A |
| 9 | Power-Off Stall (Commercial) | 個別(`PowerOffStallTask`のサブクラス) | CA.VII.B |
| 10 | Power-On Stall (Commercial) | 個別(`_StallTaskBase`のサブクラス) | CA.VII.C |
| 11 | Accelerated Stall | 個別 | CA.VII.D |
| 12 | Emergency Descent | 個別(`EmergencyDescentTask`を`bank_required=True`で流用) | CA.IX.A |
| 13 | Traffic Pattern | 個別(PPLと同じクラス、`acs_ref="CA.III.B"`のみ変更 -- 許容はPPLと同じ非タイト化) | CA.III.B |
| 14 | Go-Around/Rejected Landing | 個別(許容±5kt) | CA.IV.N |
| 15 | Normal Approach and Landing | 個別(許容±5kt、接地距離基準200ft) | CA.IV.B |
| 16 | Normal Takeoff and Climb | 個別(許容±5kt) | CA.IV.A |
| 17 | Soft-Field Approach and Landing | 個別(許容±5kt) | CA.IV.D |
| 18 | Soft-Field Takeoff and Climb | 個別(許容±5kt) | CA.IV.C |
| 19 | Short-Field Approach and Landing | 個別(`ShortFieldApproachLandingTask`、PPLと同じクラス、許容±5kt) | CA.IV.F |

PPLと共通のクラスをパラメータ化して再利用している科目が多い(§3の依存注記参照)。CPLにはPPLのようなBasic Instrument Maneuvers(直線水平・上昇・降下・方位旋回)が無いため、離陸直後に降下科目が来てしまう問題はCPL側にはそもそも発生しない — Steep Turn以降はどれも高度を維持または上昇する科目で、Emergency Descentが最後に来るまで降下が要求されない。Steep Spiral・Eights on Pylonsは未実装(§4.4末尾参照)。#13-19の着陸フェーズブロックはPPL/ASELと同じ構成・同じ理由で追加した(§2.3参照) -- Traffic PatternのみACSで数値がタイト化されておらず、PPLと同じ±100ft/±10ktのまま。

### 2.3d PPL/AMEL・CPL/AMELの科目順序 (`sequence.py: build_ppl_amel_syllabus()` / `build_cpl_amel_syllabus()`)

実機のチェックライドと同じ考え方: 双発機(AMEL)での受験は単発版の科目を全てカバーした上で、多発固有の科目が追加される。そのため両関数は既存のビルダー関数の戻り値に3科目を**追加するだけ**(`build_ppl_asel_syllabus() + [...]` / `build_cpl_syllabus() + [...]`)。

| # | 科目 | 種別 | ACS参照(PPL / CPL) |
|---|------|------|----------|
| 24 (PPL) / 20 (CPL) | Engine Failure After Liftoff | 個別(3段階: armed→stabilizing→holding) | PA.IX.F / CA.IX.F |
| 25 (PPL) / 21 (CPL) | Maneuvering with One Engine Inoperative | HoldTask | PA.X.A+C / CA.X.A+C |
| 26 (PPL) / 22 (CPL) | VMC Demonstration | 個別(3段階: armed→entry→recovering) | PA.X.B / CA.X.B |

「Maneuvering with One Engine Inoperative」はACSの視覚科目(X.A)と計器科目(X.C)を1つのクラスでカバーする(両者の許容範囲が完全に同一で、フード使用の有無をプラグイン側で判定できないため)。

PPL版・CPL版の数値はVMC DemonstrationのS8(復帰時の増速許容範囲、PPLは+10/-5kt、CPLは±5kt)以外すべて同一のため、`acs_ref`(と`VmcDemonstrationTask`のみ`recovery_low`/`recovery_high`)パラメータで1つのクラスを両レーティングに流用している(§3参照)。

全レーティングとも順序は固定。スキップ(ボタン/メニュー/コマンド)は可能だが、順序の入れ替えや科目選択のカスタマイズは未実装(チェックライドモードのみの制約)。練習モード(§2.4)は全レーティングの科目をカタログに含み、レーティングフィルタで絞り込める。

### 2.4 練習モード (`practice.py`, `controller.py`)

チェックライドモードの「順番固定・合否は最後まで非公開」に対して、練習モードは「1科目だけ選んで・即結果表示・何度でも再挑戦」という対になる仕組み。

```
カタログ画面 (PracticeSession.active == False, setup画面も表示していない)
  → 画面上部のレーティングフィルタ(Checkride Modeと同じ RATINGS のボタン、既定 "ppl_asel")で
    PRACTICE_CATALOG を entry.ratings にフィルタ (overlay側の一時状態 _practice_rating_filter で保持)
  → フィルタ後のリストを地上/空中に分けて表示(スクロール領域内、高さ固定380px)
  → 科目を1つ選択 (ボタンクリック)
       地上科目 → ExaminerOverlay._draw_practice が即 controller.start_practice(entry) を呼ぶ
       空中科目 → setup画面へ遷移 (ExaminerOverlay._open_setup)

setup画面 (空中科目のみ、overlay側で保持する一時UI状態、PracticeSessionの状態ではない)
  → 開始位置: 「現在地」(既定) または 近隣空港 (airports.find_nearby_airports() の結果からボタンで選択)
  → 高度(AGL)・対気速度(IAS)・ピッチ角 をスライダーで調整 (既定値はカタログの値、ピッチ既定0°)
  → 「Start」→ PracticeSession.start(entry, agl_ft=.., ias_kt=.., pitch_deg=.., [lat=.., lon=.., ground_elevation_m=..]) を呼び、setup画面を閉じる
  → 「Cancel」→ setup画面を閉じてカタログへ戻る(何も開始しない)

PracticeSession.start(entry, **overrides):
  entry.factory() で新しいTaskインスタンスを生成
  entry.airborne_agl_ft が None でなければ Repositioner.reposition_airborne(...) を呼びテレポート
    (overridesで指定が無ければ entry のカタログ既定値にフォールバック)
    → テレポートした場合のみ self._settle_remaining_s = SETTLE_S (1.0秒) をセット
  (地上科目は何もせず、現在地のまま開始)
  → tick(state): self._settle_remaining_s > 0 の間は Task.update() を一切呼ばずreturn
       (dtだけは通常通り計算・消費する。エンジン強制始動同様テレポート直後の姿勢/速度は
       1フレーム前後不安定になりうるため、その揺れをタスク側に一切見せないための処置。
       詳細は下記コラム参照)
    → 猶予が尽きたら通常のTask.update(state, dt) ループ (チェックライドと同じ採点ロジックを共有)
  → 完了したら PracticeSession.last_result に即座に格納 → 画面に即表示
  → 「Try Again」で直前と同じ overrides を使い再度 start()(=新しいTaskインスタンス+再テレポート+再度SETTLE_S)
  → 「Back to List」/「Give Up」で stop() → カタログ画面に戻る
```

**テレポート後のsettle猶予(`SETTLE_S`, `practice.py`)**: カタログの空中科目の既定テレポート先(高度・対気速度)は、多くの科目でその科目自身のarm条件をほぼ即座に満たすように意図的に選んである(例: Straight-and-Levelは3,000ft AGL/100ktへテレポートすれば直ちに`|VS|<150fpm かつ |バンク|<10°`を満たす)。ところがハードなテレポート(位置・速度ベクトルの瞬間書き換え)の直後は、X-Planeの物理エンジンが変化を織り込むまでの1フレーム前後、姿勢・速度が一時的に不安定になりうる。以前はこの不安定な最初のフレームでタスクがそのままarmし、「テレポートによる移動そのもの」が採点の一部として紛れ込んでしまっていた(ユーザー報告)。対策として、テレポート直後は`SETTLE_S`(1.0秒)分のtickの間、`Task.update()`自体を一切呼ばないようにした — 個々のタスク側には一切手を入れず、`PracticeSession`側だけで解決している。Checkride Modeはそもそもテレポートしない(実際に飛んで科目条件を満たす前提)ため、この問題は存在せず、`SETTLE_S`もPractice Mode専用。

**カタログ (`PRACTICE_CATALOG`)**: `PracticeEntry.ratings`(タプル)で各エントリがどのレーティングフィルタに表示されるかをタグ付けしている。件数はチェックライドモードの科目数と一致するよう設計:

| レーティングフィルタ | 件数 | 内訳 |
|---|---|---|
| ppl_asel | 17 | PPL/ASELの全科目(Short-Field Takeoff/Landingの2科目を含む) |
| ppl_amel | 20 | ppl_asel の17 + AMEL科目3(PA.IX.F/PA.X.A+C/PA.X.Bの値で生成) |
| ir | 6 | IRの全科目 |
| cpl | 13 | CPLの全科目(急旋回は50°版、緊急降下は`bank_required=True`版、Short-Field Takeoff/Landingの2科目を含む) |
| cpl_amel | 16 | cpl の13 + AMEL科目3(CA.IX.F/CA.X.A+C/CA.X.Bの値で生成) |
| ppl_helicopter | 9 | PPL/Helicopterの全科目 |

PPL版とCPL版で数値が異なるAMEL3科目(特にVMC Demonstrationの復帰時増速許容範囲)は、`ppl_amel`用と`cpl_amel`用でそれぞれ別の`PracticeEntry`(別キー、`factory`が異なる`acs_ref`/`recovery_low`/`recovery_high`でタスクを生成)として登録している — 同じインスタンスを使い回すと片方のレーティングの数値が誤って適用されるため。

空中科目のテレポート先の既定値(setup画面で上書き可能)は各タスクファイルのカタログエントリに埋め込まれており、既存のPPL科目(§2.4当初のテレポート先表)に加えて、IR科目(4,000ft前後/100-110kt)・CPL科目(3,500-4,500ft/100kt)・AMEL科目(3,000-4,500ft/100kt)、そしてPPL/Helicopter科目(ホバー系は5ft AGL/0-5kt、離着陸・進入は50-300ft AGL/40-50kt、オートローテーションは1,000-1,500ft AGL/60kt)も同様に設定済み。ピッチ角の既定値は全科目共通で0°(水平)。setup画面のスライダー範囲は AGL 0〜10,000ft、対気速度 0〜160kt、ピッチ ±20°(ヘリのホバー科目が要求する低高度・低速をカバーするため、AGL/対気速度の下限をそれぞれ0まで拡張済み)。

カタログ画面はエントリ数が増えたため(最大20件、ppl_amel)、`imgui.begin_child`/`end_child` によるスクロール領域(高さ固定380px)内に描画する。この呼び出しもXPPython3の型スタブに無い関数のため、失敗時は例外を握りつぶしてスクロール無しで描画を続行する(`overlay.py: _begin_scroll`/`_end_scroll`)。

**開始位置の選択 (`airports.py`)**: 「地図をクリックして選ぶ」機能はXPLMのMap API(`createMapLayer`等)がマーカー・ラベルの描画専用で、プラグインへのクリック座標の通知手段が無いため実現不可。代わりに `find_nearby_airports()` が、現在地から近い順に並べた**空港リスト**を提供する:
1. `xp.findFirstNavAidOfType(Nav_Airport)` / `findLastNavAidOfType(Nav_Airport)` で空港タイプの連続ID範囲を取得(公式に想定された「1種類だけ列挙する」手順)
2. その範囲を `getNextNavAid()` で走査し、`NavAidInfo.reg == 1`(読み込み済みシーナリー範囲内)のものだけ採用
3. 現在地からの距離(簡易な緯度経度→NM換算)でソートし上位12件を返す
4. ボタン押下時に一度だけ実行(毎フレームではない)

**テレポート実装 (`reposition.py`)**: `lat`/`lon` を指定しない場合は現在地点の真上に高度だけ変えて配置(現在の地形標高 = `elevation` − `y_agl` を利用)。`lat`/`lon` を指定した場合(空港選択時)は `ground_elevation_m` (=選択した空港の`NavAidInfo.height`)をそのまま地表標高として使う(別地点の地形を都度プローブする手段は使っていないため)。手順:
1. 目標MSL標高 = 地表標高 + 指定AGL
2. `xp.worldToLocal(lat, lon, 目標MSL)` でOpenGLローカル座標に変換
3. `local_x/y/z`(書込可能double)に直接書き込み
4. `phi=0, theta=指定ピッチ, psi=現在方位` で姿勢を設定
5. 対気速度をピッチ角で水平・垂直成分に分解し、`local_vx/vy/vz` に方位・ピッチから計算した速度ベクトルを設定(でないと初期姿勢とズレて機体が暴れる)
6. エンジン1を強制始動: ミクスチャーをフルリッチ、点火を両方(BOTH)、燃料ポンプON、プロペラモードをNORMALに設定し、`ENGN_running` を1に書き込み、スロットルを65%(既定)に設定
7. **物理的な回転速度そのものを書き込む**: `ENGN_tacrad`(エンジン)と`POINT_tacrad`(プロペラ)に、既定2,300RPMをrad/secへ変換した値を書き込む

手順6だけでは不十分だった(実機で確認済みの不具合): `ENGN_running`はフライトモデルが計算した結果を表すステータスフラグであり、書き込んでもフライトモデル自体を駆動するわけではない。エンジン停止状態からテレポートすると、クランク軸・プロペラの回転速度(物理シミュレーション値)は0のままで、「稼働中」表示にはなってもスラストが出ない(RPMが上がらない)。そこで手順7で、実際にフライトモデルが積分している回転速度データレフ自体を直接書き換えることで、エンジンに「既に回っている」状態を与えている。

この手法はXPLMプラグインの標準的な「reposition」テクニック。風の影響は無視(対気速度と対地速度を同一視)、地形との衝突判定はしていない(現在地/選択空港の真上のみ)。ピッチはテレポート時の姿勢・速度ベクトルを一度設定するだけでトリムはしないため、機体は自分でその姿勢を維持する必要がある(放置すると水平に戻ろうとする可能性がある)。

---

## 3. アーキテクチャ

```
plugin/
├── PI_CheckrideExaminer.py      XPPython3エントリポイント。DataRef読取→controller.tick()、
│                                  コマンド登録 (skip/restart/answer_a..d)、Pluginsメニュー登録、
│                                  設定ファイルパス解決(dirname(xp.getPrefsPath()))
└── checkride_examiner/
    ├── state.py                 FlightState (dataclass、xp非依存)
    ├── datarefs.py               DataRefReader。xpに依存するI/O層(読み取り専用)
    ├── reposition.py             Repositioner。xpに依存するI/O層(書き込み専用、練習モードのテレポート)
    ├── airports.py                find_nearby_airports()。xpに依存するI/O層(読み取り専用、練習モードの開始位置候補)
    ├── aircraft_settings.py      AircraftSettings / AircraftSettingsStore -- 機体別Vx/Vy等の永続化。xp非依存(§2.1a)
    ├── license.py                generate_key / is_valid_key / LicenseStore -- シリアルキー認証。xp非依存(§2.1c)
    ├── grading.py                ToleranceSpec / ToleranceTracker / TaskResult
    ├── util.py                   heading_diff, local_xy_ft, resolve_approach_speed などの純粋関数
    ├── sequence.py                ExaminerSession (チェックライドモード: 科目リストの進行管理。Readyゲート、§2.1b)
    ├── practice.py                PracticeSession / PRACTICE_CATALOG (練習モード)
    ├── controller.py              AppController (2つのmodeを束ね、ticks/操作をルーティング。機体設定の適用もここ)
    ├── overlay.py                 UI (ImGui優先、失敗時はプレーンテキストにフォールバック。練習モード/Settings画面はImGui必須)
    ├── weather_presets.py         WeatherPreset / PRESETS / PRESETS_BY_KEY / cloud_base_and_tops_m -- 純粋データ(xp非依存)
    ├── weather.py                 WeatherController。xpに依存するI/O層(書き込み専用、IR用の天候プリセット適用)
    ├── updater.py                 UpdateChecker / UpdateInfo / parse_manifest -- 自前アップデート機構。xp非依存(§2.1d)
    ├── cacert.pem                 certifi由来のMozillaルート証明書バンドル(静的ファイル、updater.pyが読む。§2.1d)
    ├── _version.py                PLUGIN_VERSION -- package.sh実行毎に自動生成、VERSIONファイルと同期(§2.1d)
    ├── edition.py                 SHIPPED_RATINGS / visible_ratings() -- 限定エディション機構。xp非依存(§2.1e)
    └── tasks/
        ├── base.py               Task / HoldTask 基底クラス。configure_from_settings()フック(既定no-op)
        ├── basic_instrument.py   直線水平・上昇・降下・方位旋回
        ├── steep_turns.py        急旋回 -- target_bank/acs_refパラメータでPPL(45°)/CPL(50°)を両方カバー
        ├── slow_flight.py        低速飛行 -- SlowFlightTask(PPL) + CommercialSlowFlightTask(サブクラス、許容範囲を上書き)
        ├── stalls.py             失速(パワーオフ/パワーオン共通基底 + PPL/CPLの計4サブクラス)
        ├── ground_reference.py   地上目標旋回
        ├── emergency_descent.py  緊急降下 -- acs_ref/bank_requiredパラメータでPPL/CPLを両方カバー
        ├── ground_ops.py         タキシー・ランナップ
        ├── short_field.py        PPL/CPL: Short-Field Takeoff/Landing -- Vx/Vyはconfigure_from_settings()で機体別に登録必須(§2.1a, §4.2, §4.4, §8)
        ├── normal_landing.py     PPL/CPL: Normal Takeoff/Landing -- Vy/公表進入速度はShort-Fieldと同じSettingsフィールドを流用(§4.2b)
        ├── soft_field.py         PPL/CPL: Soft-Field Takeoff/Landing -- state.yoke_pitch_ratioで地上滑走/ロールアウト時の引き操作を判定(§4.2b, §8)
        ├── go_around.py           PPL/CPL: Go-Around/Rejected Landing -- 滑走路データ不要、スロットル上昇の検知のみでarm(§4.2b)
        ├── traffic_pattern.py    PPL/CPL: Traffic Pattern -- 実滑走路方位が取得できないため自己参照のdownwind基準で判定(§4.2b, §8)
        ├── quiz.py                ATCクイズ (MultipleChoiceTask) -- PPL(空港/タワー) + IR(クリアランス復唱)
        ├── nav_tracking.py       IR: VOR/ローカライザー追跡
        ├── holding.py             IR: ホールディング
        ├── approaches.py         IR: NPA/PA(ILS)進入 -- フェーズごとにトラッカーを追加のみ(§4.3.1)
        ├── missed_approach.py    IR: ミストアプローチ
        ├── chandelle.py           CPL: シャンデル
        ├── lazy_eight.py          CPL: レイジーエイト
        ├── accelerated_stall.py  CPL: 加速失速
        ├── multiengine.py         AMEL: エンジン故障後上昇・片発飛行 -- acs_refパラメータでPPL/CPLを両方カバー
        ├── vmc_demo.py            AMEL: VMCデモ -- acs_ref/recovery_low/recovery_highパラメータでPPL/CPLを両方カバー
        ├── heli_hovering.py       Helicopter: ロータ始動・ホバリング科目(§4.6)
        ├── heli_takeoff_landing.py  Helicopter: 離着陸・進入科目(§4.6)
        └── heli_performance.py   Helicopter: 急停止・オートローテーション(§4.6)
```

**依存方向の原則**: `state.py`・`grading.py`・`util.py`・`aircraft_settings.py`・`license.py`・`weather_presets.py`・`updater.py`・`_version.py`・`edition.py`・`tasks/*.py`・`sequence.py`・`practice.py`・`controller.py` は `XPPython3` を一切importしない(`Repositioner`と`WeatherController`はどちらもダックタイピングで渡されるだけで、importはしない。`updater.py`は`xp`はおろかXPPython3固有のものを何もimportしないため、`weather.py`と違って`controller.py`が直接importしている)。X-Planeへの依存は `datarefs.py`・`reposition.py`・`airports.py`・`weather.py`・`overlay.py`(および `PI_CheckrideExaminer.py`)のみに閉じ込めてある。これにより `tests/` はX-Plane無しでロジックを検証できる(`tests/test_practice_mode.py`は`Repositioner`を、`tests/test_weather.py`は`WeatherController`を、`tests/test_updater.py`は`UpdateChecker`のfetch_json/downloadをそれぞれフェイクに差し替えて呼び出し自体を検証)。`airports.py` は overlay.py からのみ呼ばれ、practice.py/controller.py からは見えない(位置選択はUI層の関心事)。`aircraft_settings.py` の `path` 引数はただの文字列で、実際のパス解決(`xp.getPrefsPath()`)は `PI_CheckrideExaminer.py` 側の責務。`weather.py`が書き込むdatarefは採点に一切使われない(タスク側はweather状態を読まない)ため、プリセット適用は純粋に没入感のための機能であり、どのタスクの合否判定にも影響しない。

---

## 4. 科目仕様一覧

数値の出典は各タスクファイル冒頭のコメントを参照(FAA-S-ACS-6/6B、OregonFlightSchool.com、AirTrekNorth summary)。「猶予」列は `ToleranceTracker` の `grace_seconds`(既定3秒)— この秒数を超えて連続で許容範囲を外れると不合格。

### 4.1 地上フェーズ

| 科目 | 開始条件 (arm) | 完了条件 | 採点内容 | タイムアウト時 |
|------|----------------|----------|----------|----------------|
| Contact Ground / Tower | 即座に4択問題を表示 | `answer(index)` 呼び出し | 正解=合格、不正解=**即不合格**(唯一ハードに落ちるクイズ) | なし(回答待ち) |
| Taxi | 地上速度 > 2kt | 地上速度 < 1kt を3秒継続 | 最大タキシー速度を参考記録(25kt超で助言メモ)。数値上限なし、常に合格 | 600秒で「未観測」として合格扱い |
| Before-Takeoff Run-Up | 地上 かつ RPM > 1500 | RPM を10秒以上>1500保持後、RPM<1000に戻す | 保持中の油圧<10psiを検知したら助言メモ。マグネトー点検自体は非検証 | 300秒で「未観測」として合格扱い |

### 4.2 空中フェーズ(ACS数値科目)

`state.flap_ratio`(`sim/flightmodel/controls/flaprat`、実際のフラップ展開量0〜1、機種非依存の汎用dataref)を使う科目がここに初めて登場する(Short-Field Takeoff/Landing)。要求動作の中身がタイトル欄と噛み合わせ、離陸科目は「上昇確立前にフラップを上げていないか」、着陸科目は「接地時にフルフラップか」を判定する。

**Vx/Vyは実は判定できていなかった**: 実装initial版はVx目標を「離陸した瞬間の実測速度」、Vy目標を「AGL50ft到達した瞬間の実測速度」として自己参照的にキャプチャしていたが、これは「速度を一定に保っているか」の確認にしかならず、機体の本当のVx/Vyと照合しているわけではなかった(ユーザー指摘により発覚 → 修正)。X-Planeには`acf_Vso`(失速速度)のような機体固有dataref群(`acf_Vs`/`acf_Vfe`/`acf_Vno`/`acf_Vne`)はあるが、Vx/Vy(性能グラフ由来の上昇速度)に相当するdatarefは存在しない(DataRefs.txt確認済み)。一度は「降下速度の逸脱を助言メモのみとする」対応にしたが、実際の数値はフライトスクール/機体によって異なるため、現在はSettings画面でのVx/Vy登録を**必須**とし、未登録ならこの科目自体が開始しない(`Task.blocking_reason()`、§2.1a・§8参照、ユーザー要望による方針転換)。

| 科目 (ACS参照) | 開始条件 | 保持/完了条件 | 高度 | 方位 | 対気速度 | バンク | その他 |
|---|---|---|---|---|---|---|---|
| Short-Field Takeoff and Maximum Performance Climb (PA.IV.E) | Settings画面でVx/Vy登録済み(必須、§8参照) かつ 空中 かつ VS>100fpm(離陸直後) | Vx区間: AGL 50ft到達で遷移。Vy区間: 15秒保持 | - | ±10°(ハード) | 登録済みVx/Vyに対し+10/-5kt(ハード、**キャプチャ制、§8参照**) | - | 上昇が3秒安定する前にフラップが離陸時より0.1以上減った場合は不合格(ハード)。90秒でタイムアウト不合格(未登録の間はカウント開始しない) |
| Straight-and-Level (PA.IX.A) | 空中 かつ \|VS\|<150fpm かつ \|バンク\|<10° | 30秒保持 | ±200ft | ±20° | ±10kt | - | - |
| Constant Airspeed Climb (PA.IX.A) | VS>200fpm | 25秒保持 | - | ±20° | ±10kt | - | - |
| Constant Airspeed Descent (PA.IX.A) | VS<-200fpm | 25秒保持 | - | ±20° | ±10kt | - | - |
| Turns to Headings (PA.IX.A) | 科目開始と同時にランダムな目標方位(±90/±120°)を割当 | 目標方位±10°以内 かつ バンク<10°を5秒経過後に達成 | ±200ft | 割当方位±10°(ロールアウト時) | ±10kt | - | 90秒でタイムアウト不合格 |
| Steep Turn L/R (PA.V.A) | バンクが25°を超える(対象方向) | 累積旋回角が360°到達、または300°以上到達済みでバンクが25°未満に戻った時点(§8参照) | ±100ft | ロールアウト時 entry heading ±10° | ±10kt | 45°±5° | 90秒でタイムアウト不合格(armedとturning各段階) |
| Slow Flight (PA.VIII.A) | Settings画面で目標速度登録済み(必須、§8参照) かつ 対気速度が登録値以下 かつ \|VS\|<150fpm かつ \|バンク\|<15° | 30秒保持 | ±100ft | ±10° | established値の+10/-0kt | 0°±10° | 1,500ft AGL未満で即不合格(常時監視)。ホールド中に失速警報が一度も鳴らなければ助言メモ(非ハード)。未登録の間はARM_TIMEOUTのカウント開始しない |
| Power-Off Stall (PA.VIII.B) | throttle<15% かつ 失速警報が2秒連続 | 失速警報が2秒クリア かつ VS>0 かつ \|バンク\|<15° | - | 失速突入時方位±10° | - | 0°±10° | 1,500ft AGL未満で即不合格。回復高度損失は300ft超で助言メモ(非ハード) |
| Power-On Stall (PA.VIII.C) | throttle>50% かつ 失速警報が2秒連続 | 同上 | - | 同上 | - | 同上 | 同上 |
| Turns Around a Point (PA.VI.B) | \|バンク\|>15° かつ AGL 600〜1300ft | 累積旋回角360°(1周)到達 | ±100ft | - | ±10kt | - | 半径は推定中心からの逸脱を参考記録のみ(非ハード)。armed段階は150秒、turning段階(1周完走)は240秒でタイムアウト不合格(§8参照) |
| Emergency Descent (PA.X.A) | throttle<15% かつ VS<-500fpmが2秒継続 | 指定高度(開始時-500ft)の+100ft以内に到達 | 開始時-500ft の±100ft(到達判定) | - | 開始時速度の+0/-10kt(established値基準、自己参照でACS通り) | 最大バンクが45°超なら助言メモ(非ハード) | 降下中に実測Vno(`state.vno_kt`、`acf_Vno`)を一度でも超えたら不合格(ハード、§8参照)。120秒でタイムアウト不合格 |
| Short-Field Approach and Landing (PA.IV.F) | 即座に監視開始、空中 かつ VS<-100fpmで確立とみなす | 接地(`on_ground`) | - | 方位は不採点(§8参照 -- ダウンウィンド降下で誤ってarmし、base/finalの通常旋回でバストしていたバグの修正) | Settings画面で公表進入速度を登録済みならその値、無ければ1.3×Vso(`state.vso_kt`、`acf_Vso`から取得)、いずれもどちらも+10/-5kt(ハード、**キャプチャ制、§8参照**)。どちらも無い機体のみ確立時実測値を代用し助言メモ降格 | - | 接地時フラップ比率<0.8なら不合格。接地点からの距離(ACS: 200ft以内)は非採点、助言メモのみ。120秒でタイムアウト不合格 |

**共通の安全フロア**: Slow Flight・Power-Off/On Stallは、開始前後を問わず毎ティック「1,500ft AGL未満なら即座に不合格終了」を監視している(`_tick_extra` / update先頭でのハードチェック)。

**地上開始バグの修正**: 空中科目の開始条件には `not state.on_ground` 相当のガードが入っている(Straight-and-Levelで明示、他は動作原理上ほぼ地上では成立しない条件設計)。これにより、エンジン停止のまま駐機した状態で誤って科目が進行することはない。

### 4.2b 着陸フェーズブロック: Normal/Soft-Field Takeoff/Landing・Go-Around・Traffic Pattern

数値の出典はcfi.treklog.com掲載のFAA-S-ACS-6C/7B各タスクのSkillsリストを直接取得・確認したもの(WebFetch/WebSearchで2系統以上のソースを突き合わせ、特にCommercial版Go-Aroundの許容(あるソースは+10/-5のまま、別の2ソースは±5に厳格化と記載されていたため、CPLの他タスクが軒並み±5に厳格化されるパターンと整合する後者を採用)、およびArea III Task B(Traffic Patterns)はFAA-S-ACS-6Cの当該ページを直接確認)。詳細は各タスクファイル冒頭のコメント参照。

Vy(`vy_kt`)とpublished approach speed(`short_field_approach_kt`)はShort-Field Takeoff/Landingと**同じ**Settingsフィールドを流用する(§2.1a) -- 実機のPOH数値は離着陸方式が変わっても同じ値のため、方式ごとに別フィールドを増やす理由がない。Vx区間が無い(Normal/Soft-Field/Go-Aroundはいずれも障害物回避が無く、Vyへ直接上昇するだけ)。

| 科目 (ACS参照) | 開始条件 | 保持/完了条件 | 対気速度 | 方位 | その他 |
|---|---|---|---|---|---|
| Normal Takeoff and Climb (PA.IV.A) | Vy登録済み(必須) かつ 空中 かつ VS>100fpm | 15秒保持 | 登録Vyに対し+10/-5kt(ハード、**キャプチャ制、§8参照**) | ±10°(ハード、ACS原文に明示の数値は無く、Short-Field/Soft-Fieldと同じ独自採用の値) | 90秒でタイムアウト不合格(未登録の間はカウント開始しない) |
| Normal Approach and Landing (PA.IV.B) | 即座に監視開始、空中 かつ VS<-100fpmで確立とみなす | 接地 | `resolve_approach_speed()`(公表速度 or 1.3×Vso)に対し+10/-5kt(ハード、**キャプチャ制、§8参照**)、どちらも無ければ助言メモ降格 | 方位は不採点(§8参照。Short-Field/Soft-Fieldの着陸と同じ理由で削除) | フラップ要件なし(Short-Fieldと異なりACSに明記が無い)。接地点からの距離(ACS: 400ft以内)は非採点、助言メモのみ。120秒でタイムアウト不合格 |
| Soft-Field Takeoff and Climb (PA.IV.C) | Vy登録済み(必須) かつ 空中 かつ VS>100fpm | 15秒保持 | 登録Vyに対し+10/-5kt(ハード、**キャプチャ制、§8参照**) | ±10°(ハード) | 地上滑走中、`state.yoke_pitch_ratio`(`sim/cockpit2/controls/yoke_pitch_ratio`、パイロットの生の昇降舵入力)が閾値0.2を超えた時間の累計が3秒以上でなければ不合格(ハード、継続不要 -- 実際の操作は最初強く引き、速度が乗るにつれ徐々に緩めるため)。90秒でタイムアウト不合格 |
| Soft-Field Approach and Landing (PA.IV.D) | 即座に監視開始、空中 かつ VS<-100fpmで確立とみなす | 接地後5秒(ROLLOUT_GRACE_S)経過 | `resolve_approach_speed()`に対し+10/-5kt(ハード、**キャプチャ制、§8参照**)、どちらも無ければ助言メモ降格 | 方位は不採点(§8参照。Short-Field/Normalの着陸と同じ理由で削除) | 接地後のロールアウト中、同じyoke_pitch_ratio判定(閾値0.2、累計3秒以上)で不合格判定。接地距離基準はACS上そもそも存在しないため非採点項目自体を持たない。120秒でタイムアウト不合格 |
| Go-Around/Rejected Landing (PA.IV.N) | Vy登録済み(必須) かつ 空中 かつ throttle_ratio>0.7(復行操作の検知) | 15秒保持 | 登録Vyに対し+10/-5kt(ハード、**キャプチャ制、§8参照**) | ±10°(ハード、スロットルを上げた瞬間の方位が基準) | 進入配置(降下中か等)は未確認 -- スロットル上昇のみで判定(§8参照)。90秒でタイムアウト不合格(未登録の間はカウント開始しない) |
| Traffic Pattern (PA.III.B) | 空中 かつ \|VS\|<300fpm(安定) | 累積旋回角180°到達、または150°以上到達済みでバンクが10°未満に戻った時点(Steep Turnsと同じロールアウト判定方式) | ±10kt(established値基準) | ロールアウト時、downwind方位+180°(自機推定の"滑走路方位")に対し±10° | 高度±100ft。降着帯方位を実際に取得する手段が無いため自己参照(§8参照)。180秒でタイムアウト不合格 |

Commercial版(CA接頭辞)はTraffic Pattern以外すべて許容±5kt(対称)に厳格化。Normal Landingの接地距離基準はPPL 400ft・CPL 200ft(Short-Fieldと同様、いずれも非採点で助言メモのみ)。

### 4.3 IR科目(FAA-S-ACS-8C)

数値の出典は各タスクファイル冒頭のコメント(`tasks/nav_tracking.py`, `tasks/holding.py`, `tasks/approaches.py`, `tasks/missed_approach.py`)。CDI/グライドスロープの「dots」は `nav1_hdef_dots_pilot`/`nav1_vdef_dots_pilot` を使用し、フルスケール(振り切り)を±2.0dotsと仮定(標準的なCDI/HSIの慣習だが実機での確認はしていない — §7参照)。¾スケール偏差 = 1.5dots。

| 科目 (ACS参照) | 開始条件 | 完了条件 | 採点内容 |
|---|---|---|---|
| Nav Tracking (IR.V.A) | 空中 かつ \|VS\|<150fpm かつ \|バンク\|<15° | 30秒保持 | 高度±100ft、対気速度±10kt、CDI≤1.5dots。方位は「コース維持のため常に変化する」性質上、固定目標では追跡しない(仕様上の簡略化) |
| Holding (IR.III.B) | \|バンク\|>20° | 累積旋回角360°(1周)到達 | 高度±100ft、対気速度±10kt、CDI≤1.5dots。進入方式(direct/teardrop/parallel)・レグ時間は非判定。360秒でタイムアウト不合格 |
| Nonprecision Approach (IR.VI.A) | タスク開始と同時に採点開始(3段階: enroute→descending→final) | descending: VS<-300fpmで遷移。final: \|VS\|<200fpmを3秒保持でMDA捕捉とみなし遷移、そこから30秒保持で完了 | 全区間: CDI≤1.5dots、対気速度±10kt。final区間のみ追加: 高度がMDA(捕捉時高度)の+100/-0ft。240秒でタイムアウト不合格 |
| Precision Approach / ILS (IR.VI.B) | タスク開始と同時に採点開始(2段階: enroute→final) | enroute: \|グライドスロープ偏差\|<0.5dots かつ \|ローカライザー偏差\|<1.5dots かつ VS<-200fpmでグライドスロープ捕捉とみなしfinalへ遷移。final: 捕捉高度から500ft降下でDA到達とみなし完了 | enroute: 高度±100ft、ローカライザー≤1.5dots、対気速度±10kt。final: ローカライザー≤1.5dots、対気速度±10kt、グライドスロープ≤1.5dots(高度トラッカーは以後更新しないが、bust済みなら合否判定に残り続ける — §4.3.1参照)。240秒でタイムアウト不合格 |
| Missed Approach (IR.VI.C) | throttle>85% かつ VS>200fpm | 25秒保持 | 方位±10°、対気速度±10kt。公表されたミストアプローチ経路・ステップアップ高度は非判定 |

#### 4.3.1 トラッカーの「追加のみ」原則 (`tasks/approaches.py`)

NPA/PAはフェーズが進むごとに新しいトラッカー(例: MDA到達後の高度トラッカー、グライドスロープ捕捉後の垂直偏差トラッカー)を生成するが、実装は既存の `self.trackers` リストに**追加するのみ**で、決して置き換えない。理由: `Task._finish()` は `self.trackers` に現存するトラッカーのbust状態だけを見て合否を決めるため、フェーズ遷移時に古いトラッカーを削除してしまうと、そのフェーズ中に発生していたbustが合否判定から消えてしまう(採点漏れ)。この設計はコメントに明記されており、オフラインテスト(`tests/test_ir_tasks.py`)でも確認済み。副作用として、オーバーレイの `status_lines()` は退役したトラッカー(例: グライドスロープ捕捉後の高度)の値が更新されず古い表示のまま残るが、これは表示上の些末な癖であり、採点の正確性を優先した結果。

### 4.4 CPL科目(FAA-S-ACS-7B)

数値の出典は各タスクファイル冒頭のコメント(`tasks/short_field.py`, `tasks/steep_turns.py`, `tasks/chandelle.py`, `tasks/lazy_eight.py`, `tasks/slow_flight.py`, `tasks/stalls.py`, `tasks/accelerated_stall.py`, `tasks/emergency_descent.py`)。PPLと同じクラスをパラメータ化して再利用している科目が多い(§3参照)。

| 科目 (ACS参照) | 開始条件 | 完了条件 | 採点内容 |
|---|---|---|---|
| Short-Field Takeoff and Maximum Performance Climb (CA.IV.E) | PA.IV.Eと同じ | PA.IV.Eと同じ | PA.IV.Eと同じ判定だが、Vx/Vy登録済みの場合の許容が対称±5kt(PA.IV.Eは+10/-5kt)。`ShortFieldTakeoffTask(acs_ref="CA.IV.E", tolerance_low=-5.0, tolerance_high=5.0)` — PPLと同じクラス、許容幅のみ違う |
| Steep Turn L/R, 50° (CA.V.A) | バンクが25°を超える(対象方向) | 累積旋回角360°到達、または300°以上到達済みでロールアウトした時点(§8参照) | 高度±100ft、対気速度±10kt、バンク50°±5°、ロールアウト entry heading±10°。`SteepTurnTask(target_bank=50.0)` — PPLと同じクラス、バンク目標のみ違う |
| Chandelle L/R (CA.V.C) | バンク>20° かつ VS>200fpm | 累積旋回角180°到達 | ロールアウト方位(entry+180°)±10°。かつ、ロールアウトまでに失速警報が1秒以上鳴った実績があること(「失速速度近くまで減速できたか」の近似)、ロールアウト時点で失速警報が鳴りっぱなしでないこと。バンク角自体はACSに数値基準が無いため非採点。1,500ft AGL未満で即不合格。90秒でタイムアウト不合格 |
| Lazy Eight L/R (CA.V.D) | バンク>15° | 累積旋回角180°到達 | 到達時点で一括判定: 高度がentry値の±100ft、対気速度がentry値の±10kt、方位がentry+180°の±10°。連続的に変化するのが本来の性質のため、180°到達までは何も追跡しない。1,500ft AGL未満で即不合格 |
| Maneuvering During Slow Flight (Commercial) (CA.VII.A) | PPL版と同じ(Settings画面で目標速度登録済み(必須) かつ 対気速度が登録値以下 かつ \|VS\|<150fpm かつ \|バンク\|<15°。§8参照) | 30秒保持 | 高度±50ft、方位±10°、対気速度+5/-0kt、バンク±5°(PPLより全て厳しいか同等)。1,500ft AGL未満で即不合格。ホールド中に失速警報が一度も鳴らなければ助言メモ(非ハード) |
| Power-Off Stall (Commercial) (CA.VII.B) | throttle<15% かつ 失速警報が2秒連続 | 失速警報が2秒クリア かつ VS>0 かつ \|バンク\|<15° | 方位±10°、バンク±5°(PPLの±10°より厳しい)。1,500ft AGL未満で即不合格 |
| Power-On Stall (Commercial) (CA.VII.C) | throttle≥65%(PPLの>50%より厳しい) かつ 失速警報が2秒連続 | 同上 | 方位±10°、バンク±5°。1,500ft AGL未満で即不合格 |
| Accelerated Stall (CA.VII.D) | バンクが35°を超える かつ 失速警報が1秒連続 | 失速警報が2秒クリア かつ VS>0 かつ \|バンク\|<15° | 3,000ft AGL未満で即不合格(他の失速科目より高いフロア)。バンク角(45°目標)自体はACSに数値基準が無いため非採点、AGLフロアと復帰のみ判定 |
| Emergency Descent (CA.IX.A) | throttle<15% かつ VS<-500fpmが2秒継続 | 指定高度(開始時-500ft)の+100ft以内に到達 | 対気速度は開始時速度の+0/-10kt(PPLと同じ)。`bank_required=True`のため、降下中の最大バンクが30〜45°の範囲外だと不合格(PPLでは同じ逸脱が助言メモ止まり)。`EmergencyDescentTask(acs_ref="CA.IX.A", bank_required=True)` — PPLと同じクラス |
| Short-Field Approach and Landing (CA.IV.F) | PA.IV.Fと同じ | PA.IV.Fと同じ | PA.IV.Fと同じ判定だが、対気速度許容が対称±5kt(PA.IV.Fは+10/-5kt)。接地点距離のACS基準もCPLは100ft(PPLは200ft)だが、こちらも同様に非採点。`ShortFieldApproachLandingTask(acs_ref="CA.IV.F", tolerance_low=-5.0, tolerance_high=5.0, touchdown_distance_ft=100.0)` |

**未実装(CPL)**: Steep Spiral(CA.V.B、地上目標点を中心に3周以上のスパイラル降下、PPLのTurns Around a Pointと同程度以上に複雑な地上参照点推定が必要)、Eights on Pylons(CA.V.E、高度・対気速度の数値基準がACSに存在せず、ピボタル高度を使った視覚的な追跡精度でしか評価できないため、飛行データのみでの採点が原理的に困難)、Power-Off 180 Accuracy Approach and Landing(滑走路接地点との位置関係データが必要、PPLの離着陸未実装と同じ理由で見送り)。

### 4.5 AMEL科目(FAA-S-ACS-6C Area IX.F・Area X.A-C / FAA-S-ACS-7B Area IX.F・Area X.A-C)

数値の出典は各タスクファイル冒頭のコメント(`tasks/multiengine.py`, `tasks/vmc_demo.py`)。PPL・CPLで数値がほぼ完全に一致するため、`acs_ref`(および`VmcDemonstrationTask`のみ`recovery_low`/`recovery_high`)パラメータで1クラスを両レーティングに流用している。

**エンジン判定の前提**: `state.throttle_ratio`をエンジン1(左)、`state.throttle2_ratio`をエンジン2(右)とみなす(X-Planeの`ENGN_thro`配列のindex 0/1をそのまま使用)。単発機では`throttle2_ratio`が常に0なので、AMEL科目は単発機では絶対にarmしない。センターライン推力機(前後配置の双発)には非対応。

| 科目 (ACS参照) | 開始条件 | 完了条件 | 採点内容 |
|---|---|---|---|
| Engine Failure After Liftoff (PA/CA.IX.F) | 非対称パワー(片方throttle<15%、もう片方>50%) | armed→stabilizing(5秒待機、この間は無採点)→holding(20秒保持) | 方位はarm時のentry headingの±10°、対気速度はstabilizing終了時点の値の±5kt(実際のVyseはPOHデータが無いため代替として使用)。armed→stabilizing中に非対称パワーが解消されたらarmedへ差し戻し |
| Maneuvering with One Engine Inoperative (PA.X.A+C / CA.X.A+C) | 非対称パワー かつ \|VS\|<200fpm かつ \|バンク\|<20° | 25秒保持 | 高度±100ft、対気速度±10kt、方位±10°。ACSの視覚科目(A)と計器科目(C)を同一クラスでカバー(§2.3d参照) |
| VMC Demonstration (PA.X.B / CA.X.B) | Settings画面で復帰目標速度(Vyse相当)登録済み(必須、§8参照) かつ 片方throttle<15% かつ もう片方throttle>70%(=критical engineの特定、動力側の方向を記録) | armed→entry→recovering。entry中に失速警報が鳴ったらrecovering開始。recoveringは「失速警報クリア かつ \|バンク\|<10° かつ 対気速度が警報発生時点より増加」で完了 | entry中: 動力側エンジンへ向くバンクが0〜5°の範囲を外れた状態が3秒超継続したら不合格要因(方向を間違えて逆バンクした場合も同じ扱い)。recovering完了時: 方位がentry headingの±20°以内か判定(ハード)。復帰時対気速度が登録済み目標に対しPPL +10/-5kt・CPL ±5ktの範囲外なら不合格(ハード -- 登録必須化に伴い、自己参照の代替値ではなく実際の目標との比較に変更)。1kt/秒の減速レートおよび設定手順(ギア/フラップ/プロペラRPM等)自体は非採点、150秒でタイムアウト不合格(未登録の間はカウント開始しない)、recovering開始後30秒でタイムアウト不合格 |

**未実装(AMEL共通)**: Engine Failure During Takeoff Before VMC(離陸滑走中のタスクで、他の離着陸科目と同じ理由で見送り)、Instrument Approach and Landing with an Inoperative Engine(CPLのみ、CA.X.D — IR科目相当の進入手順認識と着陸データの両方が必要なため未実装)。

### 4.6 PPL/Helicopter科目(FAA-S-ACS-15)

数値の出典は各タスクファイル冒頭のコメント(`tasks/heli_hovering.py`, `tasks/heli_takeoff_landing.py`, `tasks/heli_performance.py`)。固定翼のタスク群とは完全に別の科目群で、共有しているのはbase.pyの`Task`/`ToleranceTracker`の仕組みだけ。

**新規dataref**: `rotor_rpm`(main rotor回転数、RPM)。`sim/flightmodel/engine/POINT_tacrad`(index 0、rad/sec)から変換。エンジン回転数(`engine_rpm`)ではなくこちらを使う理由は、オートローテーション中はメインローターとエンジンがフリーホイールクラッチで切り離される(=このタスクの核心そのもの)ため、エンジン回転数を見てもローター回転数はわからないから。

**ホバリング高度許容範囲の共通ルール**(`_hover_alt_tolerance()`、複数科目で共有): 基準高度が地上10ft以内なら基準高度の±1/2、10ft超なら一律±5ft(ACS原文どおり)。

**「指定地点」系のタスクの共通の割り切り**: Vertical Takeoff/Landingの着陸、Normal/Steep Approachの終了点はいずれもACSで「指定地点の±4ft以内」を要求するが、パイロットが心の中でどの地点を狙っているかはプラグイン側から知りようがない。そこで代わりに「速度・高度がホバリング/接地の条件を満たした最初の瞬間の位置」を基準点として記録し、そこから最終的にどれだけ動いたか(半径)を判定する — つまり「狙った場所に降りたか」ではなく「一度止まったらそこで安定して止まっていたか」を採点している。オートローテーションの200ft以内着地(PH.VI.B.S12/PH.VI.C.S13)はこの手法すら使わず完全に非採点(後述)。

| 科目 (ACS参照) | 開始条件 | 完了条件 | 採点内容 |
|---|---|---|---|
| Powerplant Starting and Rotor Engagement (PH.II.C, 手続き科目) | なし(即座に監視開始) | `rotor_rpm` > 200 RPMを5秒連続維持 | 数値基準なし、達成のみで合格。300秒でタイムアウトしても「未観測」として合格扱い(Taxi/Run-Upと同じ方針) |
| Vertical Takeoff and Landing (PH.IV.A) | 空中 かつ AGL<25ft かつ 地上速度<3kt かつ \|VS\|<100fpm(=静止ホバー確立) | hover: 15秒保持 → landing: `on_ground`になるまで(60秒でタイムアウト) | hover中: 位置±4ft、高度(共通ルール)、方位±10°。landing到達時: 着陸地点が離陸位置の4ft以内かを追加判定(ハード、trackerとは別枠) |
| Hover Taxi (PH.IV.B) | 空中 かつ AGL<25ft かつ 地上速度1〜20kt | 20秒保持 | 進行方向に直交する横方向オフセット±4ft、高度(共通ルール)、方位±10°。前後方向の移動量自体は不問(ホバータキシーなので前進は前提) |
| Normal Takeoff and Climb (PH.V.A) | 空中 かつ VS>200fpm | 15秒保持 | 対気速度±10kt、方位±10°(`HoldTask`、固定翼のConstant Airspeed Climbと同型) |
| Normal and Crosswind Approach (PH.V.B) | なし(即座に監視開始、まだ低速低高度でなければ何もしない) | AGL<15ft かつ 地上速度<5ktを2秒継続、または`on_ground` | 「指定地点」ルール(上記)による位置±4ft判定のみ。120秒でタイムアウト不合格 |
| Steep Approach (PH.V.D) | 同上 | 同上 | 位置±4ft判定に加え、降下角(降下率と対地速度から逆算、`atan2`)の最大値を記録。15°(ACS上限)を超えたら不合格、8°未満(「本当にsteepだったか」の非公式な下限、ACS原文には無い)でも不合格 |
| Rapid Deceleration / Quick Stop (PH.VI.A) | 空中 かつ 対気速度>20kt かつ AGL<150ft | 地上速度<5ktを2秒継続(=ホバー確立) | 方位±10°を減速中ずっと保持。最低地上高を参考記録として表示(数値基準なし) |
| Straight-In Autorotation (PH.VI.B) | 空中 かつ throttle<15% かつ VS<-300fpm かつ AGL>300ftを2秒継続(=模擬エンジン故障の確立) | 最低3秒のグライドを経て、`on_ground`または(AGL<15ft かつ 地上速度<5ktを2秒継続) | 対気速度はarm時の値の±10kt。ローターRPMはarm直前に読んだ`rotor_rpm`を100%とした相対値で±10%(§末尾の注記参照、ACSはPOH依存の数値のためこれは代替のヒューリスティック)。**着地点が「指定地点」の200ft以内かは非採点**(下記参照) |
| Autorotation with Turns (PH.VI.C) | 同上 | 同上 | 上記に加え、旋回中(方位変化率>3°/秒)の累積旋回角が90°以上であること、旋回を終えた(方位変化率が3°/秒を下回った)瞬間のAGLが300ft以上であること。`AutorotationTask(require_turn=True)` — Straight-Inと同一クラスをパラメータ化 |

**オートローテーションの着地精度(200ft以内)を非採点にした理由**: `ground_reference.py`のTurns Around a Pointは「中心点」を機体の初期位置から推定するが、それは「だいたいこの辺りを旋回するはず」という前提が成り立つ科目だから成立する近似。オートローテーションは逆に「パイロットが選んだ特定の着陸地点に正確に降りられるか」こそが科目の本質であり、その地点を機体側の状態から逆算する手段が無い以上、精度を偽装するよりは「非採点」と明記する方が誠実と判断した。代わりに、飛行データから実際に読み取れる要素(対気速度・ローターRPMというエネルギー管理、および制御された終了かどうか)を採点している。

**未実装(PPL/Helicopter)**: Slope Operations・Confined Area Operations・Pinnacle Operations(いずれもACSの評価基準が数値ではなく現場選定・偵察の判断力そのものであり、飛行データだけでは採点不可能)、Go-Around・Maximum Performance Takeoff(既存タスクと同型だが未実装)、Area VIII全体(Vortex Ring State, Low Rotor RPM Recognition, Antitorque System Failure, Dynamic Rollover, Ground Resonance — いずれも「意図的に危険な状態を作り出す」ことがteleport/setup画面経由では安全に再現できず、かつACSの評価観点が数値ではなく認識・回復の判断力であるため)。

---

## 5. 採点モデル

### 5.1 ToleranceSpec / ToleranceTracker (`grading.py`)

- `ToleranceSpec(label, unit, target, low, high, grace_seconds=3.0)`: 目標値と許容下限・上限(非対称も可、例: Slow Flightの対気速度は `+10/-0`)。
- `ToleranceTracker.update(value, dt)`: 目標との偏差を計算(方位は `heading_diff` で360°wrap対応)。許容範囲外が `grace_seconds` を超えて連続すると `busted=True` になり、以後の `_finish()` で自動的に不合格要因として計上される。
- **「一瞬の逸脱は許すが、続けば不合格」** という設計は、実際のDPEが一時的な計器の揺れを許容し、持続的な逸脱のみを問題視する挙動を模している。
- `ToleranceTracker(spec, diff_fn=None, gate_until_captured=False)`: `gate_until_captured=True`の場合、`captured`プロパティが`False`の間は`update()`が偏差を`last_dev`/`max_dev`には反映しつつも`_consecutive_bad`のカウントを一切進めない -- 目標値に一度も入っていない状態でarmされるタスク(着陸系の進入速度、離陸/上昇系のVx/Vy、§8参照)向けの仕組み。値が一度でも許容範囲内に入った時点で`captured=True`になり、以後は`gate_until_captured=False`の場合と全く同じ挙動になる(一度確立した後に崩れれば正しくbustする)。`tests/test_grading.py`で単体テスト済み。

### 5.2 TaskResult (`grading.py`)

`TaskResult(task_id, title, passed, notes)`。`passed` は「明示的な合否判定」と「保持していた全トラッカーが未bust」の論理積(`Task._finish()` 内)。`notes` にはbust理由・参考情報・クイズの正解などが入る。

### 5.3 セッション全体の合否 (`sequence.py: score_summary()`)

単純な「合格数/総数」表示のみ。実際のチェックライドのように「1つでもUnsatisfactory Notice of Disapprovalで即終了」という挙動にはなっていない(全科目を最後まで走らせる)。

---

## 6. UI / 操作

- 描画は `overlay.py` の `_ImguiBackend`(XPPython3同梱のpyimgui+PyOpenGL使用)。import失敗時は `_PlainBackend`(生XPLMDisplay文字描画)に自動フォールバック — この場合 practice modeの科目選択リストもホーム画面もSettings/License画面もクリック不可。テキスト入力ができないためライセンス認証手段が無く、「ImGui UIが必要」という案内を表示するのみで採点は一切開始しない(`controller.is_licensed`が`False`のまま、§2.1c参照)。

**License画面**(`_ImguiBackend._draw_license_gate`。ImGuiのみ): `controller.is_licensed` が `False`、または `self._force_license_screen` が `True` の間、他のどの画面よりも優先して表示される(`_draw_content`の最初のif分岐)。認証済みなら現在のキーを緑字で表示。テキスト入力欄(`imgui.input_text`)+「Activate」ボタンで `controller.activate_license(input)` を呼び、成功すれば入力欄をクリアして通常画面へ、失敗すれば赤字で「That key isn't valid」を表示したまま留まる。認証済みの状態でここへ来た場合のみ「Back」ボタンで抜けられる(未認証では抜け道が無い)。ホーム画面の「Change Key」ボタンから `self._force_license_screen=True` にして再度開ける。

**ホーム画面**(`_ImguiBackend._draw_home`、`self._home` フラグで表示切替。ImGuiのみ、かつ`controller.is_licensed`が`True`の場合のみ到達可能): タイトル + 説明文 → 現在の機体名(`controller.aircraft_key` から `.acf` 拡張子を除いた表示) + 「Settings」ボタン → 「License: {キー}」表示 + 「Change Key」ボタン(押すと`_force_license_screen=True`でLicense画面へ) → 未登録機体なら黄色の注意書き(§8参照) → 「Rating:」ボタン列(選択は `self._home_rating` に保持、まだ`controller`には反映しない) → 「Start Checkride Mode」ボタン(`set_checkride_rating` → `set_mode(checkride)` → `controller.start()`) / 「Start Practice Mode」ボタン(practice用レーティングフィルタに反映 → `set_mode(practice)` → `controller.start()`)。どちらかを押すまで `self._home=True` のままで、他の画面は一切描画されない(= `AppController.tick()` も上記ゲートで何もしない)。

**Settings画面**(`_ImguiBackend._draw_settings`、`self._show_settings` フラグで表示切替。ImGuiのみ): ホーム画面、およびホーム離脱後のどの画面の最上部からも「Settings」ボタンで到達できる。開いた瞬間 `controller.current_settings()` を読んでスライダーの初期値にする(`_open_settings`)。5スライダー: Vx(0〜120kt、必須)・Vy(0〜120kt、必須)・Short-Field公表進入速度(0〜120kt、任意、0なら1.3×Vso自動)・VMC Demo復帰速度(0〜160kt、必須、AMELのみ)・Slow Flight目標速度(0〜120kt、必須)。Slow Flightのみ、未登録(0)かつ`controller.last_vso_kt>0`の場合に限り、スライダーの初期表示を`round(1.2 x last_vso_kt)`にする(`_open_settings`内、あくまで表示上の提案値であり保存しなければ登録されない)。「Save」ボタンで `AircraftSettings` を組み立てて `controller.save_aircraft_settings()` を呼ぶ(ファイル書き込み + 現在のタスクへの即時反映、§2.1a参照)。「Back」は保存せずに戻る。機体未検出(`aircraft_key` が空)の場合は入力欄を出さず「機体をロードしてください」の案内のみ。

- ホーム画面を離れた後の画面最上部は常に共通: タイトル + 現在レーティング + 「Home」ボタン(押すと `self._home=True` に戻すだけ、`controller.started`は変えない) + 「Checkride Mode」「Practice Mode」の切替ボタン(現在mode に `[active]` 表示)。以下は選んだmodeにより分岐。

**Checkride Modeの画面**: 全体進捗バー → 科目番号ストリップ → 現在科目名+ACS参照 → `task.blocking_reason()`がNoneでなければ赤字「SETTINGS REQUIRED」バナー+メッセージ+「Open Settings」ボタンを表示してここで打ち切り(指示文・Readyゲート・許容範囲バーは一切描画しない。Skip Task/Restart Sessionのみ引き続き押せる、§2.1a参照)。ブロックされていなければ通常どおり: 指示文 → `session.is_waiting_for_ready`中のみ「Get set up for this task」+ Readyボタン(§2.1b) → (通常科目)許容範囲バー / (クイズ)4択ボタン → 次科目プレビュー → Skip/Ready/Restartボタン。
- **合否は最後まで非公開**: 実際のチェックライドと同様、セッション進行中は「どこまで進んだか」(番号ストリップ: 済み=中立色/現在=黄/未着手=灰)のみを示し、済んだ科目が合格だったか不合格だったかは一切表示しない(結果ログもセッション中は非表示)。全科目終了後の debrief 画面で初めて、科目ごとの合否・メモ・総合スコア(合格数/総数)がまとめて開示される。

**Practice Modeの画面**:
- 科目未選択時: `PRACTICE_CATALOG` を「地上(その場で開始)」「空中(テレポートしてから開始)」の2グループに分けてボタン一覧表示。
- 科目選択後・結果確定前: `task.blocking_reason()`がNoneでなければCheckride Modeと同じSETTINGS REQUIREDバナー(「Give Up / Back to List」ボタンのみ併記)、そうでなければ通常科目と同じ許容範囲バー(またはクイズの4択)を表示、「Give Up / Back to List」ボタン。
- 結果確定後: SATISFACTORY/UNSATISFACTORYを即座に色付き表示 + メモ、「Try Again」(同じ科目を再テレポートして再挑戦)/「Back to List」ボタン。

操作手段は3系統(機能は同一):
  1. ウィンドウ内ボタン(Skip Task / Ready / Restart Session / クイズのA〜D / モード切替 / 科目選択・Try Again・Back to List / Settings・Save・Back)
  2. X-PlaneのPluginsメニュー > Checkride Examiner(Show/Hide, Skip, Ready for Next Task, Restart, Switch to Checkride/Practice Mode)
  3. X-Planeコマンド: `checkride/examiner/skip_task`, `/ready`, `/restart`, `/answer_a`..`/answer_d`(Settings > Keyboardでバインド可能。科目選択・モード切替・機体設定の入力自体にはコマンドは無く、ImGui UI操作が必要)

---

## 7. 使用DataRef一覧 (`datarefs.py`)

| 用途 | DataRef | 型 |
|------|---------|-----|
| 緯度・経度 | `sim/flightmodel/position/latitude` / `longitude` | double |
| 指示高度 | `sim/cockpit2/gauges/indicators/altitude_ft_pilot` | float |
| AGL | `sim/flightmodel/position/y_agl` (m→ft変換) | float |
| 対気速度 | `sim/flightmodel/position/indicated_airspeed` | float |
| 方位(機体の実姿勢、計器誤差シミュレーションなし) | `sim/flightmodel/position/psi` | float |
| バンク角 | `sim/flightmodel/position/phi` | float |
| ピッチ角 | `sim/flightmodel/position/theta` | float |
| 昇降率 | `sim/flightmodel/position/vh_ind_fpm` | float |
| 失速警報 | `sim/cockpit2/annunciators/stall_warning` | int(bool) |
| スロットル(エンジン1・左) | `sim/flightmodel/engine/ENGN_thro[0]` | float[] |
| スロットル(エンジン2・右、AMEL用) | `sim/flightmodel/engine/ENGN_thro[1]` | float[] |
| 地上判定 | `sim/flightmodel/failures/onground_any` | int(bool) |
| 地上速度 | `sim/flightmodel/position/groundspeed` (m/s→kt変換) | float |
| パーキングブレーキ | `sim/multiplayer/controls/parking_brake[0]` | float[] |
| エンジン回転数 | `sim/cockpit2/engine/indicators/engine_speed_rpm[0]` | float[] |
| 油圧 | `sim/cockpit2/engine/indicators/oil_pressure_psi[0]` | float[] |
| NAV1 CDI/ローカライザー水平偏差(IR用) | `sim/cockpit2/radios/indicators/nav1_hdef_dots_pilot` | float |
| NAV1 グライドスロープ垂直偏差(IR用) | `sim/cockpit2/radios/indicators/nav1_vdef_dots_pilot` | float |
| メインローター回転数(Helicopter用、rad/sec→RPM変換) | `sim/flightmodel/engine/POINT_tacrad[0]` | float[] |
| フラップ展開量(Short-Field科目用、実際の展開比率0〜1) | `sim/flightmodel/controls/flaprat` | float |
| 失速速度・着陸形態(Short-Field進入速度の1.3×Vso計算用、機体固有) | `sim/aircraft/view/acf_Vso` | float |
| 最大構造巡航速度(Emergency Descentのオーバースピード判定用、機体固有) | `sim/aircraft/view/acf_Vno` | float |
| パイロットの生の昇降舵操作入力(-1下げきり〜+1上げきり、Soft-Field科目の引き操作判定用。トリム/オートパイロットの影響を受ける舵面変位ではなく操作入力そのもの) | `sim/cockpit2/controls/yoke_pitch_ratio` | float |
| 機体識別(機体別設定のキー、§2.1a参照) | `xp.getNthAircraftModel(0)` の `fileName`(`.acf`ファイル名) | XPLMPlanes関数、datarefではない |

※ `sim/flightmodel/position/magpsi` と `sim/cockpit2/controls/parking_brake_ratio` はX-Plane側で非推奨('DO NOT USE THIS'/'REPLACED')のため意図的に不使用。**方位は`sim/cockpit/misc/compass_indicated`(パネルの磁気コンパス指示値)ではなく`psi`(機体の実姿勢)を使う** -- 前者は実機の湿式磁気コンパス特有の「旋回誤差・ダイップ誤差」までシミュレートしているdatarefで(DataRefs.txtの`gyr_magnetometer_diff`の説明にも「水平直線飛行時のみ正確、磁力計はダイップ誤差の影響を受ける」と明記されている)、まさにバンクした旋回中(=Steep Turns・Chandelle・Lazy Eight・Turns Around a Point・Traffic Pattern・Holding Procedureなど、`heading_diff`で毎ティック差分を積算して累積旋回量を追跡するすべての科目が方位データを最も必要とする場面)に最も不正確になる特性を持っていた。これが「Steep Turnが終わらない」という報告の真因で、以前の対策(tasks/steep_turns.pyのロールアウト判定緩和、§8参照)はそれ単体では解決しきれていなかった(累積が本当に300°にすら届かないケースがあったため)。`psi`は実機のDG/HSI(方向ジャイロ、旋回中も誤差が出ない)に相当する値で、パイロットが実際に旋回を判断する基準・DPEが実際に見る基準と一致する。純粋にdatarefの選択のみの変更なので`tasks/*.py`は無変更 -- オフラインテストはheading_degを直接値として与えるため、この種の不具合はそもそもオフラインテストでは検出できない(実機シミュレータでの検証でのみ判明する)。同様に `nav1_hdef_dot`/`nav1_vdef_dot`(単位表記が曖昧な"prcnt")ではなく、単位が明示的に"dots"の`_dots_pilot`系を採用(フルスケール±2.0dotsは標準的なCDI/HSIの慣習に基づく仮定であり、実機での確認はしていない)。メインローター回転数に`engine_speed_rpm`(エンジン軸回転数)ではなく`POINT_tacrad`(reposition.pyがエンジン再始動時に書き込むのと同じ「物理的に計算された回転速度」)を使うのは、オートローテーション中はメインローターとエンジンがフリーホイールクラッチで切り離されるため、エンジン回転数を見てもローターの実際の回転数は分からないから。フラップも同様に、パイロットが最後に指示した位置(`flaprqst`)ではなく実際に展開されている量(`flaprat`)を採用 — フラップは動くのに数秒かかるため、「今何が起きているか(実際の空力配置)」を見るのが目的で、「最後に何を指示したか」ではない。

### 7.1 書き込み専用DataRef (`reposition.py`、練習モードのテレポートのみ)

| 用途 | DataRef | 型 |
|------|---------|-----|
| 機体位置(OpenGLローカル座標) | `sim/flightmodel/position/local_x` / `local_y` / `local_z` | double |
| 速度ベクトル(ローカル座標) | `sim/flightmodel/position/local_vx` / `local_vy` / `local_vz` | float |
| 姿勢角 | `sim/flightmodel/position/phi` / `theta` / `psi` | float |
| スロットル(再設定) | `sim/flightmodel/engine/ENGN_thro[0]` | float[] |
| エンジン強制始動(ステータス) | `sim/flightmodel/engine/ENGN_running[0]` | int[] |
| エンジン回転速度(物理値、本質的な修正箇所) | `sim/flightmodel/engine/ENGN_tacrad[0]` | float[] |
| プロペラ回転速度(物理値) | `sim/flightmodel/engine/POINT_tacrad[0]` | float[] |
| ミクスチャー | `sim/cockpit2/engine/actuators/mixture_ratio[0]` | float[] |
| 点火スイッチ | `sim/cockpit2/engine/actuators/ignition_on[0]` | int[] |
| 燃料ポンプ | `sim/cockpit2/engine/actuators/fuel_pump_on[0]` | int[] |
| プロペラモード | `sim/cockpit2/engine/actuators/prop_mode[0]` | int[] |

座標変換には `xp.worldToLocal(lat, lon, alt_m)` を使用(緯度経度+MSL標高→OpenGLローカル座標)。地形標高の算出には読み取り用の `sim/flightmodel/position/elevation`(海抜MSL, double)も使用する。

### 7.2 ナビゲーションDB API (`airports.py`、開始位置の候補一覧)

DataRefではなくXPLMNavigation APIを使用。

| 用途 | 関数 | 備考 |
|---|---|---|
| 空港タイプの範囲取得 | `xp.findFirstNavAidOfType(Nav_Airport)` / `xp.findLastNavAidOfType(Nav_Airport)` | 空港のみの連続ID範囲を得る公式パターン |
| 範囲の走査 | `xp.getNextNavAid(navRef)` | 上記範囲内でのみ呼ぶ(全件走査はしない) |
| 詳細取得 | `xp.getNavAidInfo(navRef)` | `.latitude/.longitude/.height/.navAidID/.reg` を使用。`.reg`が1のものだけ採用(読み込み済みシーナリー範囲内) |

### 7.3 書き込み専用DataRef (`weather.py`、IR用天候プリセットのみ)

| 用途 | DataRef | 型 | 備考 |
|------|---------|-----|------|
| 天候の変化モード | `sim/weather/region/change_mode` | int | 常に3(Static)に固定 -- X-Planeの自動遷移で上書きされないように |
| 即時反映フラグ | `sim/weather/region/update_immediately` | int(bool) | 常に1。雲以外は即時反映(§8参照、雲は別途regen_weatherコマンド併用) |
| 視程 | `sim/weather/region/visibility_reported_sm` | float | 単位はstatute miles |
| 雲タイプ(層0のみ) | `sim/weather/region/cloud_type[0]` | float[3] | 0=巻雲・1=層雲・2=積雲・3=積乱雲。層雲(1)固定、曇天なしなら0 |
| 雲量(層0のみ) | `sim/weather/region/cloud_coverage_percent[0]` | float[3] | 0.0〜1.0 |
| 雲底(層0のみ) | `sim/weather/region/cloud_base_msl_m[0]` | float[3] | MSL、メートル。現在の地表標高(`elevation`−`y_agl`、reposition.pyと同じ算出法)+プリセットのAGL値から算出 |
| 雲頂(層0のみ) | `sim/weather/region/cloud_tops_msl_m[0]` | float[3] | 雲底 + プリセットの層厚 |
| 雲の即時再計算コマンド | `sim/operation/regen_weather`(コマンド、DataRefではない) | - | `update_immediately`だけでは雲は最大60秒かけてフェードインするとX-Plane公式ドキュメントに明記されているため、雲配列書き込み直後に`commandOnce`で発火 |

`sim/weather/region/weather_source`(0=Preset, 1=Real Weather, 2=Controlpad, 3=Plugin)はDataRefs.txt上で書き込み不可('n')と明記されている読み取り専用の状態表示で、プラグインが`sim/weather/region/*`のいずれかに書き込んだ瞬間にX-Plane側が自動的に3(Plugin)へ切り替える、というのがX-Plane公式の天候dataref解説記事の記述。ただし直接書き込んで確認したわけではないため、この自動切り替えの実機挙動は§8に未確認事項として明記している。地上標高(`elevation`)・AGL(`y_agl`)は読み取り専用として使用(reposition.pyと同じdataref、書き込みはしない)。

---

## 8. 既知の制限(READMEと重複するが仕様として明記)

- **[修正済み・重大] 配布用の公開リポジトリに、フルビルド(全レーティング解放)のzipが複数回誤ってpushされていた**(§2.1c/§2.1d参照)。PPL/ASEL限定エディション(V1)しか販売/配布していない段階で、開発中の通常ビルド(v9・v10・v11・v23・v24)を配布専用リポジトリ`xplane-checkride-examiner-releases`に`manifest.json`と一緒にpushしてしまっており、V1所持者が「Check for Updates」→「Download and Install」を押すと全レーティング解放版に置き換わる状態になっていた(ユーザー指摘: 「フルビルドは絶対に公開されちゃダメ 別売りを構想してるし」)。レーティング別の個別販売という事業計画そのものを崩しかねない不具合だったため最優先で対応、3段階で修正した:
  1. リポジトリの現在のツリーからフルビルドのzipを全て削除し、PPL/ASEL制限版のzipのみを再publish
  2. それでもforce push後に古いコミットSHA経由のraw URLがまだ200を返す(=ダウンロード可能)ことを実機確認できたため(GitHubはforce pushしただけでは古いオブジェクトをすぐには破棄しない)、**リポジトリ自体を削除して同名で作り直し**、クリーンな単一コミットのみをpush。削除は破壊的操作のため実行前にユーザーの明示的な許可を得ている。作り直し後、同じ古いコミットSHA・raw URLが404になることを再確認済み
  3. 運用ルール(公開するのはエディション制限版のみ、`package.sh`のフルビルド警告)は「守り続けられる」という前提に依存する対策でしかないため、根本対策として**ライセンスキー自体にレーティング制限を埋め込む**方式を追加(§2.1c参照)。これにより、万一(3)の運用ルールが将来また破られてより広いビルドが到達可能になったとしても、個々の顧客のキー自体がその顧客の購入範囲を超えて解放することはない

  さらに、現状`manifest.json`はエディションを問わず1本しか無いため、2種類目以降の有料エディションを売り始める前にエディション別manifestの実装が必要(§2.1d「既知のギャップ」参照) -- ただし(3)のキー側の制限がある以上、これを怠っても「買っていないレーティングが解放される」という最悪の事態は起きなくなった(顧客が更新を受け取れない、という不便に留まる)。
- **Normal/Short-Field/Soft-Field Landing(着陸系3タスク)は方位を一切採点しない**(`tasks/normal_landing.py`・`tasks/short_field.py`・`tasks/soft_field.py`)。旧実装は離陸タスクの方位保持ロジックをそのまま着陸タスクにも流用し、降下開始(`VS<-100fpm`)の瞬間の方位を基準に±10°を接地まで保持する仕様だった。しかしこの降下開始条件は多くの場合まだダウンウィンド上で成立してしまうため、その後のbase/finalへの通常のパターン旋回(方位が90〜180°変化する)で毎回バストしていた(ユーザー報告: 「Short field LDGなどLDG系の科目のreadyボタンを押すのは基本的にDown windなんだけどHDGのせいでfailになる」)。離陸タスクの方位保持(PA.IV.A.S12「maintain directional control...throughout takeoff and climb」)は直線の上昇であるため正当だが、着陸系タスクのACS技能リスト(PA/CA.IV.B/D/F)には方位に関する数値基準がそもそも存在しない。「ファイナルに確立してから」だけ判定するよう作り直す案も検討したが、滑走路方位を取得するdatarefが無い(Traffic Patternと同じ制約)ため「いつファイナルに確立したか」を信頼できる形で検知する手段が無く、中途半端なヒューリスティックはバストの発生場所を移すだけで問題の解決にならない。よって方位チェック自体を完全に削除した。離陸タスク側の方位保持は変更していない(引き続き正しく採点される)。
- **着陸系3タスク+離陸/上昇系5タスク、計8タスクの対気速度判定はキャプチャ制**(`tasks/normal_landing.py`・`tasks/short_field.py`・`tasks/soft_field.py`・`tasks/go_around.py`)。着陸側(Normal/Short-Field/Soft-Field Landing)は上記の方位バグと根本原因が同じ: armはVS<-100fpmで発生し、これは多くの場合まだダウンウィンド上、つまりクルーズに近い速度が残っている状態で成立する。ところが旧実装はarmと同時に目標進入速度への許容判定(3秒猶予、grading.pyの`ToleranceSpec.grace_seconds`既定値)をそのまま開始していたため、クルーズから進入速度まで減速しきる前に3秒の猶予を使い切って不合格になりうる設計だった(ユーザー報告: 「Down windではまだクルーズスピードに近いスピードも出ているだろうし」)。離陸/上昇側(Short-Field/Normal/Soft-Field Takeoff、Go-Around)は鏡写しの問題: Vx/Vyの許容判定が離陸直後(またはGo-Aroundの場合は復行操作の瞬間)から即座に開始されるが、その時点の実測対気速度はまだ目標に達していない(ユーザー報告: 「Takeoff系もなんだけど速度が乗るまで少し時間がかかる」)。特にSoft-Field TakeoffはACS技能自体が「接地後、地面効果内で加速してからVyへ上昇する」という遅延を明示的に要求しているため、8タスクの中で最もこのバグの影響を受けやすかった。

  方位バグと違い、この修正には滑走路方位のような追加データは不要 -- IASだけで完結する。`tasks/approaches.py`のグライドスロープキャプチャと同じ考え方で、対気速度が一度でも目標の許容範囲内に入るまでは許容判定のクロックを一切進めない設計にした。当初は各タスクに手書きの`_ias_captured`/類似の真偽値フラグを個別実装していたが、着陸3タスクに続いて離陸系5タスクにも同じ修正が必要になった時点で、`grading.py`の`ToleranceTracker`自体に`gate_until_captured`という共通のコンストラクタ引数として一本化した(`tests/test_grading.py`で単体テスト済み) -- 8箇所に同じロジックを複製するのではなく、1箇所の共有・テスト済みプリミティブにした形。キャプチャ前はどれだけ目標からずれていても不合格の対象にならず、キャプチャ後は従来通り3秒持続逸脱で不合格になる(=一度確立した後に崩れるケースは引き続き正しく検知する)。着陸ではタッチダウンまで、離陸/上昇では保持時間(15秒)が終わるまでに一度もキャプチャしなかった場合は、非ハードの助言メモ(「... was never within tolerance ...」)を残すのみで、不合格にはしない。離陸系タスクの方位保持(ヘディング)チェックは今回変更していない(引き続き非ゲート、正当な判定として維持)。
- **[修正済み] Update画面のネットワーク呼び出しが、Python実行環境のCA証明書バンドル次第でSSL証明書検証に失敗する不具合があった** -- 当初は開発機のpython.orgインストーラー版CPython 3.13で再現した「環境依存の未確認リスク」として記載していたが、その後実際にXPPython3の実機環境でも同じ`CERTIFICATE_VERIFY_FAILED`がユーザー報告された。§2.1dに記載の通り、`certifi`由来のルート証明書バンドルを`cacert.pem`として同梱し、`updater.py`の全HTTPS通信がそれを明示的に使うよう修正済み(証明書検証を無効化する形のフォールバックは意図的に採用していない -- `apply()`が実行可能コードをダウンロード・インストールする処理である以上、検証を外すことは中間者攻撃のリスクに直結するため)。修正後、最初にこのエラーを再現した開発機のPython環境で再度end-to-endの動作を確認済み。
- **Weather画面(IR用天候プリセット)は演出専用**(`weather.py`、§7.3参照)。どのタスクもweather状態を読まないため、プリセットを適用しても採点結果は一切変わらない。また、プラグインが天候の制御を握る仕組み(`weather_source`が自動的に3=Pluginへ切り替わるというX-Plane公式ドキュメントの記述)は実機で直接確認していない -- `weather_source`自体が読み取り専用のため、切り替わったかはDataRefEditor等で別途確認する必要がある。雲は`cloud_type`/`cloud_coverage_percent`/`cloud_base_msl_m`/`cloud_tops_msl_m`の3層中layer0のみ書き込み、layer1-2は未使用(単一の雲底を設定できれば十分という判断)。雲底/雲頂は適用した瞬間の地表標高から算出するため、その後大きく高度を変えるとプリセットが意図したAGL値とはズレる。
- **科目間のReadyゲートにはタイムアウトが無い**。Readyを押し忘れる/気づかなくても、セッションは無期限に待ち続ける(採点を黙って始めてしまうよりは安全という判断)。科目番号ストリップは次科目を「現在」として黄色表示し続けるが、待機中かどうかの区別は無い。クイズ回答ボタン自体はこのゲートの影響を受けない(`submit_answer()`は`tick()`を経由しないため) -- クイズは直前科目の残存状態問題とは無関係。
- **失速検知**: 実際のAoA/失速角ではなく「失速警報が2秒連続」で近似。
- **Steep Turnsはロールアウトで終了判定し、累積360.0°ちょうどへの到達では判定しない**(`tasks/steep_turns.py`)。実際のDPEは計器の合計値ではなく、進入時の方位に戻ったかを目視で判断する -- そのため数度手前で切り上げたり数度過ぎてから戻したりするのはごく普通の飛び方だが、旧実装は累積符号付き方位変化が文字通り360°以上になるまで終了しない仕様だったため、少し早めにウイングスレベルへ戻すと方位が変化しなくなり、二度と360に到達せずTIMEOUT_S(90秒)まで待たされ続けていた(ユーザー報告: 「360度で終わらない」)。修正後は、累積旋回量が300°以上に達した後でバンクを`ARM_BANK_DEG`未満まで戻した時点でも終了するようにした -- 300°未満でロールアウトした場合は依然として「早期に諦めた」扱いのまま、正しくTIMEOUT失敗になる。**ただしこの対策だけでは実機シミュレータ上で再発した**(ユーザー再報告: 「これ終わらないねえ」)-- 真因は`heading_diff`で累積旋回量を積算する際の方位データそのものにあった。`datarefs.py`が読んでいた`sim/cockpit/misc/compass_indicated`は湿式磁気コンパスの旋回誤差までシミュレートするdatarefで、バンクした旋回中(=このタスクが最も方位を必要とする場面)ほど不正確になり、累積が300°にすら届かないケースがあった。`psi`(機体の実姿勢、§7参照)へのdataref変更でこの根本原因を解消し、本項のロールアウト緩和と合わせて二重の対策になっている。
- **Slow Flightは失速警報ホーンではなく、Settings画面で登録した目標速度でarmする(必須)**(`tasks/slow_flight.py`)。旧々実装はarmする前に警報ホーンが鳴っている実績(`_warning_streak`)を必須としていたが、機体によって警報が鳴り始めるAoAの設定はまちまちで、安全に制御可能な低速飛行速度では鳴らず実際の失速寸前まで減速しないと鳴らない機体もあり、そのような機体では科目がほぼ開始不可能になっていた(ユーザー報告: 「ストールホーン鳴らさないと始まらない」)。次に`acf_Vso`の1.2倍という自動計算に切り替えたが、実際の目標速度はフライトスクールによって異なりうるため(ユーザー指摘)、最終的にSettings画面での登録を必須とした -- 未登録なら`blocking_reason()`によりこの科目自体が開始しない(§2.1a参照)。ホーン自体はホールド中も監視を続け、機体依存の項目として一度も鳴らなかった場合のみ助言メモを付ける(合否には影響しない)。
- **地上目標旋回の半径**: GPSから推定した仮の中心点からの逸脱であり、実際に選んだ地上物を認識しているわけではない。参考情報のみ、不合格要因にはしない。
- **Turns Around a Pointが実機で終わらなかった不具合の真因はTIMEOUT_S不足だった**(`tasks/ground_reference.py`、ユーザー報告: 「turns aloud pointが終わらなかった」)。当時この科目は累積旋回角720°(2周)到達が完了条件で、旧実装はarm用とturning用に同一の`TIMEOUT_S=150秒`を流用していた。NOMINAL_RADIUS_FT(3,038ft = 約1/2nm)の円を2周する地上距離は約6.28nm(38,177ft)であり、この科目の通常の飛行速度(80〜100kt)だけで225〜285秒を要する -- つまり風修正のための追加操作を一切考慮しなくても、150秒という制限時間はどう飛んでも物理的に間に合わない設計になっていた(1周360°に360秒を与えているholding.pyと比べても、2周720°により少ない時間しか与えていない逆転が起きていた)。`ARM_TIMEOUT_S=150秒`(旋回確立まで、変更なし)と`TURN_TIMEOUT_S`を分離して解決。方位datarefの不具合(直後の項目参照)とは別系統の原因であり、こちらもタスクロジック自体は無変更のタイミング定数のみの変更のため、オフラインテスト(疑似的な時間経過で720°分の方位を素早く与えている)では検出できない不具合だった。**その後、実際のDPE/フライトスクールへの確認で「実技試験では1周で完了とみなされる」ことが判明**(ユーザー報告: 「turns around pointは1周でっせ」)。FAA Airplane Flying Handbook第10章の記述("two or more complete circles")は練習用の目安であり、実際のチェックライドの合格基準ではない。完了条件を累積旋回角360°(1周、`COMPLETION_TURN_DEG`)に変更し、`TURN_TIMEOUT_S`も1周分の飛行距離(3.14nm、80〜100ktで113〜141秒)に合わせて240秒に短縮した。
- **緊急降下**: 「イエローアーク下限」の機種別バンク角は検証していない(速度の一貫性と復帰高度の的中のみ判定)。ただし降下中の実際のオーバースピードは、機体固有の`acf_Vno`(構造制限速度)dataref(§7参照)を使って**ハード判定するようになった**(以前は「機種別Vnoデータレフを使っていない」ため未検証だったが、実際にはこのdatarefが存在することが判明したため実装した)。
- **失速はすべて直進侵入**(旋回中失速は未対応)。フラップ・ミクスチャー・キャブヒートの構成確認は未実装(パワーのみ判定)。
- **ATCクイズが唯一のハード不合格**: 他の地上科目(Taxi/Run-Up)は原則タイムアウトしても合格扱いになる「参考記録」止まりだが、クイズは誤答で即不合格。
- **Maximum Performance Takeoffのみ未実装**(Short-Fieldとは別のACSタスクで、個別に作り込んでいない)。Normal/Soft-Field Takeoff/Landing・Go-Around・Traffic Patternは実装済み(§4.2b参照) -- いずれも「飛行データだけで判定できる要素」(速度・方位・引き操作・スロットル・高度)に絞っており、実際の滑走路上の接地点との厳密な位置関係(タッチダウン距離基準)は従来のShort-Fieldと同じく非採点・助言メモ止まり。
- **Soft-Field Takeoff/Landingの引き操作判定は「体重が主翼に移った」ことを直接検知しているわけではない**。`state.yoke_pitch_ratio`(`sim/cockpit2/controls/yoke_pitch_ratio`)はパイロットの生の操作入力であり「引いているか」の妥当な代理指標にはなるが、機体ごとの実際の挙動(ノーズホイールが実際に浮いたか)までは確認できない。閾値0.2を超えた時間の累計が3秒以上あれば合格とする設計で、最初強く引いて徐々に緩める実際の技術には寛容だが、形だけ一瞬触れる操作は検知できない。
- **Go-Areoundは実際に進入配置(降下中など)にあったことを確認していない**。スロットルが「復行操作をした」とみなせる閾値を超えたことだけで判定するため、水平飛行中からでもarmできてしまう。
- **Traffic Patternは実際の滑走路に対して採点できない** -- X-Planeには滑走路方位のdatarefが無く、プラグインのナビゲーションAPI(`airports.py`が使うもの)は空港の基準点座標のみを返し、個々の滑走路方位は取得できない。そのため地上目標旋回(Turns Around a Point)と同じ発想で、downwindで確立した自機の方位を「滑走路」の代わりに使い、そこからの180°ターンのロールアウトを判定する。ACSが数値基準を与えている高度±100ft・対気速度±10ktの2点のみ実際に採点し、それ以外(パターン手順の遵守、間隔維持など)は判定対象にしていない。
- **マグネトー点検・キャブヒート点検の具体的検証は無し**(汎用的なデータレフが機種依存のため)。
- **練習モードのテレポート**: 位置は「現在地の真上」または「選択した空港の真上」のみ(実際にその場所まで飛んでいくわけではない)。風は無視(速度ベクトル=対気速度として設定)、地形との衝突判定なし。急激な位置・速度の変更は物理エンジンにとって「瞬間的なカット」であり、なめらかな遷移ではない(その揺れ自体が採点に混入しないよう`SETTLE_S`の猶予を設けている、§2.1参照 — ただしテレポート後1秒より長く不安定な状態が続く機体があれば、それでも混入しうる)。
- **開始位置の選択は地図ではなくリスト**: XPLMのMap APIはプラグインへのクリック通知手段を持たないため、地図タップでの位置選択は実現不可。近隣空港を距離順リストから選ぶ方式で代替している。
- **ピッチ角はトリムではない**: テレポート時に姿勢・速度ベクトルを一度設定するだけで、その後は保持されない。放置すると機体が自然に水平へ戻ろうとする可能性がある。
- **練習モードはImGui必須**: プレーンテキストフォールバック時(pyimgui未使用時)はクリック可能な科目リスト・setup画面・スライダーを描画できないため、チェックライドモードのみ利用可能。
- **IR科目はVOR/ローカライザー/グライドスロープ(NAV1)のみ**: GPS/RNAV進入・垂直誘導・DME arcは未対応。
- **CDI/グライドスロープのフルスケールは±2.0dotsと仮定**(標準的なCDI/HSIの慣習)。実機での確認はしていないため、IRの採点結果が妙だと感じたらまずここを疑う(`datarefs.py`)。
- **NPA/PAとも実際の公表された進入方式(FAF・MDA・DA・ミストアプローチ経路)を認識していない**: 飛行プロファイルから「最終区間」をヒューリスティックに推定している(NPAは持続降下、ILSはグライドスロープ捕捉を起点とみなす -- `tasks/approaches.py`参照)。Missed Approachも、公表された経路への準拠ではなく、ゴーアラウンド後の方位・対気速度保持のみを採点。
- **Circling ApproachとLanding from an Instrument Approachは未実装**(PPLの離着陸と同様、滑走路との位置関係データが必要)。
- IRの科目セットにはPreflight Preparation/Procedures、Departure/En Route/Arrival Operations、Area VII(緊急操作: 通信途絶・AMEL/AMESのエンジン故障・パーシャルパネル)は含まれていない -- v1はATC/航法/進入のコアのみ。
- **練習モードのカタログのスクロール領域は固定高さ(380px)**: 将来さらに科目が増えた場合、レーティングごとの件数次第では窮屈になる可能性がある。
- **Chandeleの「失速速度近く」判定**は失速警報が1秒以上鳴った実績があるかで近似(他の失速科目と同じ手法を上昇旋回に適用)。バンク角自体(Chandelleの30°、Accelerated Stallの45°)はACSに数値基準が無いため非採点 -- AGLフロアと復帰条件のみで合否を決める。
- **Lazy EightとHoldingは1回分に簡略化**(Lazy Eightは180°の片側半分のみ、Holdingは1周のみ)。実際の試験官はより多い反復を求めることもある。
- **Steep SpiralとEights on Pylonsは未実装**: 前者はPPLのTurns Around a Point以上に複雑な地上参照点推定が必要、後者はACSに高度・対気速度の数値基準そのものが存在せず(ピボタル高度を使った視覚的追跡精度のみで評価される科目のため)、飛行データだけでの採点が原理的に困難。
- **Commercialの Power-Off 180 Accuracy Approach and Landing は未実装**(PPLの離着陸未実装と同じ理由)。
- CPLの科目セットにはPreflight Preparation/Procedures、Airport Operations、Navigation、High-Altitude Operations、Emergency Operationsの大半(Emergency Descent以外)、Multiengine Operationsは含まれていない -- v1はパフォーマンス機動と低速飛行/失速のコアのみ。
- **エンジンの左右判定はindex順の仮定**(`throttle_ratio`=エンジン1=左、`throttle2_ratio`=エンジン2=右、X-Planeの`ENGN_thro`配列そのまま)。一般的な双発機では正しいが、センターライン推力機(前後配置)には対応していない(VMC Demonstrationの「動力側へのバンク」という概念自体が成立しない)。
- **VMC Demonstrationは1kt/秒の減速レートを採点しない**。復帰時対気速度の判定は、Settings画面で登録した目標速度(Vyse相当)との比較による**ハード判定**(必須設定、未登録ならこの科目自体が開始しない、§2.1a参照)。旧実装は失速警報発生時点の対気速度を基準にした自己参照的な代替値と比較していたため、実際のVx/Vy遵守を検証できておらず常に助言メモ止まりだった(Short-Field Takeoffと同じ問題)。
- **Engine Failure During Takeoff Before VMCは未実装**(離陸滑走中のタスクで、他の離着陸科目と同じ理由)。**Instrument Approach and Landing with an Inoperative Engine**(CPLのみ、CA.X.D)も未実装 -- IR科目相当の進入手順認識と着陸データの両方が必要なため。
- **「Maneuvering with One Engine Inoperative」はACSの視覚科目(X.A)と計器科目(X.C)を同一クラスでカバー**(許容範囲が完全に同一で、フード使用の有無を判定できないため)。
- **Short-Field Takeoff/Landingの接地距離基準(PPL 200ft、CPL 100ft)は非採点**。理由はヘリのオートローテーション/進入科目と同じ(§4.6末尾参照) -- パイロットが滑走路上のどの点を狙ったか、プラグイン側から知る手段が無い。
- **Short-Field TakeoffのVx/Vy判定は、機体設定への登録が必須 -- 未登録ならこの科目自体が開始しない**。ACS原文は具体的な速度名(Vx/Vy)を指定しているが、X-Planeには`acf_Vso`のような機体固有datarefがVx/Vyには存在しない(DataRefs.txt確認済み: `acf_Vs`/`acf_Vfe`/`acf_Vno`/`acf_Vne`はいずれも構造・失速限界であり上昇性能速度ではない)。初期実装は「離陸/50ft到達の瞬間の実測速度」を自己参照的な目標にしていたが、これは「速度が安定しているか」しか検証できず本物のVx/Vy遵守の確認にはならないと判明したため(ユーザー指摘)、まず助言メモに降格 → さらにその後、Settings画面で機体ごとにVx/Vyを一度だけ手入力して記憶させる仕組み(§2.1a)を追加し、登録済みならハード採点に格上げされるようにした。しかし実際の数値はフライトスクールによって異なりうるため(ユーザー指摘)、最終的には未登録の場合そもそも科目を開始させない方針に転換した(`Task.blocking_reason()`、§2.1a参照)。フラップタイミングと方位は常にハード採点。
- **Short-Field Approach and Landingの進入速度判定は、機体設定が無くても本物のACS計算式で判定できる**: `state.vso_kt`(`sim/aircraft/view/acf_Vso`、機体固有の実測Plane Makerデータ)を使い、ACSの「1.3×Vso」をそのまま計算。Settings画面で公表進入速度を登録していればそちらが優先される(ACS原文の優先順位どおり)。Vso未対応機(値が0)かつ未登録の場合のみ、従来の自己参照的な代替目標+助言メモ降格にフォールバックする。
- **機体別設定のキーは`.acf`のファイル名のみ**(フルパスではない)。同名の`.acf`ファイルが別々のアドオンフォルダに存在する場合(まず無いはずだが)、理論上は設定が混同されうる。`xp.getNthAircraftModel(0)`が返すフルパスの方はキーには使っていない -- インストール場所が変わっても(アドオンをフォルダごと移動しても)同じ機体として認識され続けるようにするため、あえてファイル名だけを採用している。
- **ヨーク/エレベーターを引き続ける操作はSoft-Fieldの技術であり、Short-Fieldには含まれない**。ACSのShort-Field Takeoff/Landingのskillリストには持続的な引き操作の要求が無いため(Soft-Field科目は未実装)、これらのタスクは操縦桿入力を一切見ておらず、フラップのタイミング/設定のみを判定している。
- **ヘリコプターのメインローターRPM許容範囲(±10%)はACSの数値ではなく本プラグイン独自のヒューリスティック**。ACS原文は「main rotor (Nr) within normal limits」としか書いておらず、実際の正常範囲は機種(POH)ごとに全く異なる(Robinson R22とBell 206では別物)。arm直前に読んだ実測値を100%とみなした相対バンドで代用している。
- **オートローテーションの「指定地点の200ft以内に着地」は非採点**(§4.6末尾参照)。パイロットが選んだ着陸地点をプラグイン側から知る手段が無いため、精度を偽装するより非採点にする方を選んだ。
- **練習モードでヘリコプターをテレポート開始すると、表示されるローター回転数の絶対値が非現実的になりうる**: `reposition.py`のエンジン強制始動は`ENGN_tacrad`と`POINT_tacrad`に同じ`engine_rpm`(既定2300、固定翼のエンジン軸回転数を想定)を書き込む。固定翼(直結プロペラ)ならエンジン軸=プロペラ軸でほぼ問題ないが、ヘリのメインローターは減速ギアを介するため実際は300〜500RPM程度が正常値であり、2300は明らかに高すぎる。ただしAutorotationTaskの採点はarm時に読んだ値を100%とする相対評価のため、この絶対値のズレが採点結果を狂わせることはない(表示上の違和感のみ)。
- **PPL/Helicopterの地上科目はRotorEngagementのみ**(固定翼のTaxi/Contact Ground/Tower相当は未実装 -- ACS上はAirport/Heliport Operations(Area III)として存在するが、内容が固定翼のTaxi/ATC科目と本質的に同じであるため優先度を下げた)。
- **ライセンス認証はサーバー無しのローカルチェックサム方式であり、鍵の失効・再発行の仕組みは無い**(§2.1c参照)。`license.py`は配布物にそのまま入る平文Pythonソースのため、ファイルを開いて`_SECRET`を読めば有効な鍵を自作できてしまう -- タイプミス・当て推量・鍵の意図しない使い回しを防ぐ程度の対策であり、ソースを読む気のある相手を止めるものではない。より強固な方式(サーバー側検証)はオフライン動作の前提と矛盾するため採用していない。鍵生成スクリプト(`tools/generate_license_key.py`)は`package.sh`で配布物から除外している。

---

## 9. 今後の展望(未着手)

- Maximum Performance Takeoff(Normal/Soft-Field/Short-Field Takeoff/Landing・Go-Around・Traffic Patternは実装済み、§4.2b参照)
- Short-Field/Normal/オートローテーションの接地距離基準をきちんと採点する仕組み: タスク開始前にパイロットが実際の目標地点を選べるようにする(Practice Modeの近隣空港リストと同じ仕組みを転用)。今は非採点のまま自己判断に委ねている
- Traffic Patternを実際の滑走路方位に対して採点する仕組み(XPLMに滑走路ジオメトリを返すAPIが無いため、現状は自己参照のdownwind基準 -- §8参照)
- IR: Circling Approach、Landing from an Instrument Approach、GPS/RNAV進入、Departure/En Route/Arrival Operations、Loss of Communications
- CPL: Steep Spiral、Eights on Pylons、Power-Off 180 Accuracy Approach and Landing
- AMEL: Engine Failure During Takeoff Before VMC、Instrument Approach and Landing with an Inoperative Engine(CPLのみ)
- PPL/Helicopter: Slope Operations、Confined Area Operations、Pinnacle Operations、Go-Around、Maximum Performance Takeoff、Area VIII全体(Vortex Ring State、Low Rotor RPM Recognition、Antitorque System Failure、Dynamic Rollover、Ground Resonance)、Airport/Heliport Operations(地上科目)、Commercial Pilot - Helicopter(FAA-S-ACS-16)、Instrument Rating - Helicopter
- CFIの科目セット -- 「教える能力」を見る試験のため、飛行データでの採点にほぼ向かず、MultipleChoiceTask(クイズ)形式が中心になる見込み
- 自動判定が不安定な科目向けに、パイロット側の「準備完了」を明示するコマンド導入の検討
- セッション全体の合否ロジックの見直し(1科目不合格で即終了するか、全科目走らせて総合評価するか)
- 練習モードのテレポート先を、現在地/空港の真上だけでなく実際の練習エリア・場周経路へ拡張(地形プローブAPIが必要)
- 練習モードのプレーンテキストフォールバック対応(科目選択の代替手段)
- 開始位置選択の視覚的な地図化(ImGuiウィンドウ内に航空写真/チャートタイルを描画する必要があり、現状のXPLM Map APIでは実現不可)
- ピッチ角の維持(オートパイロットやトリム設定との連携)
- Settings画面に他の項目も追加(例: 短距離離陸で推奨されるフラップ設定値そのもの — 今は「離陸時から上昇確立前に減らしていないか」というタイミングしか見ていない)
- Settings画面のスライダーを数値直接入力(ImGuiの`input_float`系)に置き換え、120ktを超える機体(ターボプロップ等)にも対応
