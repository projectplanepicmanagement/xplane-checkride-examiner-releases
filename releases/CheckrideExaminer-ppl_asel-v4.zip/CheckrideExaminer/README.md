# Checkride Examiner (X-Plane 12 / X-Plane 11 / XPPython3)

A virtual DPE for X-Plane: it calls out one FAA ACS task at a time as an
on-screen overlay and grades your flying against the FAA's published
numeric tolerances, task by task, like a real practical test. Runs on
X-Plane 12 and X-Plane 11 (11.50+) via XPPython3 -- see INSTALL.txt for
which XPPython3 version to grab for each. X-Plane 10 is not supported
(XPPython3 itself doesn't run on it).

## Status: v1, six ratings (PPL/ASEL, PPL/AMEL, Instrument Rating, Commercial Pilot, Commercial Pilot/AMEL, PPL/Helicopter)

Checkride Mode now has a **rating selector** (buttons at the top, alongside
the mode toggle) -- pick which checkride to fly. Switching ratings starts a
fresh session for that rating (unlike switching between Checkride/Practice
Mode, which preserves both).

### PPL / ASEL (23 tasks)

Starts on the ground and works its way into the air, and back down again.

**Ground phase** (procedural checkpoints, not numeric ACS tasks -- see
Known limitations):
- Contact Ground (multiple-choice ATC quiz), Taxi, Before-Takeoff Run-Up,
  Contact Tower (multiple-choice ATC quiz)

**Takeoff**, from the Private Pilot - Airplane ACS (FAA-S-ACS-6 / -6C),
Area IV (Takeoffs, Landings, and Go-Arounds):
- Short-Field Takeoff and Maximum Performance Climb (PA.IV.E) -- busts if
  flaps are retracted before a positive rate of climb is well established
  (`state.flap_ratio`, from `sim/flightmodel/controls/flaprat`), and
  heading is held throughout. Climb speed (Vx to 50ft AGL, then Vy) is
  hard-graded, +10/-5kt, against this aircraft's real Vx/Vy entered in
  Settings -- **mandatory**: the task won't even start until both are
  entered, since X-Plane has no Vx/Vy dataref of its own and there's no
  sound default to guess (see Aircraft Settings above, and Known
  limitations)

**Airborne phase**, from the same ACS -- flown in this order:
- Constant Airspeed Climb, Straight-and-Level Flight, Turns to Headings
  (PA.IX.A, Basic Instrument Maneuvers)
- Steep Turns, left and right (PA.V.A)
- Maneuvering During Slow Flight (PA.VIII.A)
- Power-Off Stall, Power-On Stall (PA.VIII.B/C)
- Constant Airspeed Descent (PA.IX.A)
- Turns Around a Point (PA.VI.B)
- Emergency Descent (PA.X.A)

This order is deliberately NOT the ACS document's own Area sequence (which
groups all four Basic Instrument Maneuvers together, right after
Takeoffs/Landings) -- following that literally meant Constant Airspeed
Descent came right after the short-field takeoff's climb-out, i.e. being
asked to descend the instant you'd just taken off (user-reported). Instead
this climbs out and stays up for the altitude-hungry airwork first, only
descends once there's an actual reason to (down toward ground-reference
altitude), and saves Emergency Descent for last before landing --
altitude trends up then down over the flight, not up-down-up-down to match
the ACS's own document structure.

**Back in the pattern** (Area III/IV -- a landing-phase block: re-enter the
pattern, fly one approach that gets rejected, then land and immediately
depart again for each remaining takeoff/landing technique, mirroring how a
real multi-landing checkride segment flows):
- Traffic Pattern (PA.III.B) -- holds pattern altitude ±100ft and airspeed
  ±10kt through a downwind-base-final turn; graded against your own
  downwind heading (see Known limitations for why -- there's no way to
  read a real runway's heading from a plugin)
- Go-Around/Rejected Landing (PA.IV.N) -- from an approach configuration,
  apply go-around power and climb at Vy, +10/-5kt, holding heading; needs
  no runway data at all, unlike the full landing tasks
- Normal Approach and Landing (PA.IV.B) -- same approach-speed formula as
  Short-Field's (1.3 x Vso or a registered published speed); touchdown
  distance (ACS: within 400ft) is a self-assessed note, not graded; no
  flap requirement (unlike Short-Field)
- Normal Takeoff and Climb (PA.IV.A) -- climbs straight to Vy, +10/-5kt (no
  obstacle-clearance Vx segment, unlike Short-Field)
- Soft-Field Approach and Landing (PA.IV.D) -- same approach-speed formula;
  hard-grades sustained back-elevator pressure during rollout
  (`sim/cockpit2/controls/yoke_pitch_ratio`, the pilot's own raw elevator
  input) to keep the nosewheel light; no touchdown-distance standard in
  this task's ACS skills at all
- Soft-Field Takeoff and Climb (PA.IV.C) -- hard-grades sustained
  back-elevator pressure during the ground roll the same way, then climbs
  at Vy, +10/-5kt

**Landing** (Area IV):
- Short-Field Approach and Landing (PA.IV.F) -- approach speed +10/-5kt of
  1.3 x this aircraft's actual stall speed (`state.vso_kt`, from
  `sim/aircraft/view/acf_Vso` -- a real per-aircraft number, matching the
  ACS's own fallback formula), full flaps by touchdown (busts otherwise);
  how close the touchdown was to your intended point (ACS: within 200ft
  beyond/on it) is NOT graded -- see Known limitations

Vy (Normal/Soft-Field Takeoff and Go-Around) and the published approach
speed (Normal/Soft-Field Landing) reuse the exact same Aircraft Settings
fields as Short-Field's -- they're the same real POH numbers regardless of
which takeoff/landing technique is being flown, so there's no reason to
ask for them twice.

### Instrument Rating - Airplane (6 tasks)

From the Instrument Rating ACS (FAA-S-ACS-8C). VOR/localizer + glideslope
(NAV1) only -- no GPS/RNAV approaches yet.

A **Weather** button (Home screen and the top bar in any mode) applies one
of three presets -- Clear/VMC, an en-route overcast, or a low-IFR approach
layer -- so these tasks can actually be flown in reduced visibility instead
of only being graded as if they were. See "Weather (IR immersion)" below.

- Compliance with ATC Clearances (IR.III.A, multiple-choice clearance
  readback quiz)
- Intercepting and Tracking a Navigation Course (IR.V.A)
- Holding Procedure (IR.III.B) -- one full 360° circuit, altitude/airspeed/
  CDI tracked throughout
- Non-precision Approach (IR.VI.A) -- tracks the course inbound, then grades
  MDA hold (+100/-0 ft) after you level off from your descent
- Precision Approach / ILS (IR.VI.B) -- grades localizer/glideslope/airspeed
  from glideslope capture to a simulated DA (500 ft below capture altitude)
- Missed Approach (IR.VI.C) -- go-around power + climb, heading/airspeed held

### Commercial Pilot - Airplane (19 tasks)

From the Commercial Pilot ACS (FAA-S-ACS-7B). Tighter tolerances than PPL
throughout, plus three maneuvers PPL doesn't have.

- Short-Field Takeoff and Maximum Performance Climb (CA.IV.E) -- same shape
  as PPL's, but ±5kt on Vx/Vy (vs. PPL's +10/-5kt) once registered in
  Settings
- Steep Turns, left and right (CA.V.A) -- ~50° bank (vs. PPL's 45°), same
  ±100ft/±10kt/±5°/±10° tolerances otherwise
- Chandelles, left and right (CA.V.C) -- climbing 180° turn, ~30° bank to
  the 90° point, rollout to the reciprocal heading (±10°) just above stall
  speed without actually stalling
- Lazy Eights, left and right (CA.V.D) -- continuously-varying 180° turn,
  graded at the 180° point: altitude/airspeed/heading back to entry values
  (±100ft/±10kt/±10°)
- Maneuvering During Slow Flight (CA.VII.A) -- ±50ft/+5-0kt/±5° bank,
  tighter than PPL's ±100ft/+10-0kt/±10°
- Power-Off Stall, Power-On Stall (CA.VII.B/C) -- ±5° bank (vs. PPL's
  ±10°); power-on requires >=65% power specifically, not just "some power"
- Accelerated Stall (CA.VII.D) -- 45° banked turn, increasing back pressure
  to a stall, 3,000ft AGL floor (higher than the wings-level stalls' 1,500ft)
- Emergency Descent (CA.IX.A) -- same numbers as PPL's, but the 30-45°
  bank is graded here, not just advisory
- Traffic Pattern (CA.III.B) -- identical ±100ft/±10kt tolerances to PPL's
  (not tightened, unlike almost everything else Commercial)
- Go-Around/Rejected Landing (CA.IV.N), Normal Approach and Landing
  (CA.IV.B), Normal Takeoff and Climb (CA.IV.A), Soft-Field Approach and
  Landing (CA.IV.D), Soft-Field Takeoff and Climb (CA.IV.C) -- same shape
  as PPL's versions, tightened to ±5kt; Normal Landing's touchdown standard
  is the ACS's 200ft (vs. PPL's 400ft)
- Short-Field Approach and Landing (CA.IV.F) -- approach speed ±5kt (vs.
  PPL's +10/-5kt), full flaps by touchdown; touchdown-point distance is
  the ACS's 100ft (vs. PPL's 200ft) but, same as PPL, isn't graded

**Not yet implemented for Commercial**: Steep Spiral and Eights on Pylons
both need a ground-reference-point estimate (at least as involved as PPL's
Turns Around a Point), and Eights on Pylons has no numeric altitude/airspeed
tolerance in the ACS to grade against in the first place -- see Known
limitations.

### PPL/AMEL and Commercial Pilot/AMEL (26 and 22 tasks)

A real checkride in a twin covers everything the single-engine version
does, *plus* the AMEL-specific multiengine tasks -- so **PPL/AMEL is the
full 23-task PPL/ASEL syllabus plus 3 more**, and **Commercial Pilot/AMEL
is the full 19-task Commercial syllabus plus the same 3**. Both ratings'
extra tasks are numerically identical except where noted:

- **Engine Failure After Liftoff** (PA.IX.F / CA.IX.F) -- arms when one
  engine's throttle drops to idle while the other stays at power (a
  simulated failure); grades heading (±10°) and airspeed (±5kt) once you
  stabilize a single-engine climb
- **Maneuvering with One Engine Inoperative** (PA.X.A+C / CA.X.A+C) --
  altitude (±100ft), airspeed (±10kt), and heading (±10°) held with one
  engine simulated inoperative. Covers both the ACS's visual (A) and
  instrument/hood-on (C) versions of this task, since they share identical
  tolerances and this build can't detect hood use anyway
- **VMC Demonstration** (PA.X.B / CA.X.B) -- bank must stay within 5°
  *toward* whichever engine still has power (checked using which engine's
  throttle is actually up, not just "left" by convention); recovery, once
  the stall warning fires, must roll out within 20° of the entry heading.
  Recovery-airspeed tolerance is Private's +10/-5kt vs. Commercial's
  tighter ±5kt -- the only number that differs between the two ratings'
  versions of this task

**Not implemented**: Engine Failure During Takeoff Before VMC (a takeoff-
roll task, same reason as every other takeoff/landing task) and Instrument
Approach and Landing with an Inoperative Engine (Commercial-only, needs
both real approach-procedure awareness and landing data, neither of which
this build has).

**Not yet implemented anywhere** (see Known limitations): Maximum
Performance Takeoff (a distinct ACS task from Short-Field, not built out
separately), Commercial's Power-Off 180 Accuracy Approach and Landing,
S-turns, PPL navigation/diversion, circling approaches, GPS/RNAV
approaches, and CFI.

### PPL / Helicopter (9 tasks)

The first rotorcraft rating, from FAA-S-ACS-15 (Private Pilot - Rotorcraft
Category, Helicopter). Entirely new task shapes from the airplane
ratings -- hovering, vertical takeoffs/landings, and autorotations rather
than stalls and steep turns -- so nothing here is shared code with the
airplane task set beyond the base Task/ToleranceTracker machinery:

- **Powerplant Starting and Rotor Engagement** (PH.II.C, procedural) --
  same "best-effort substitute" as Taxi/Run-Up: confirms main rotor RPM
  comes up and stabilizes above a generic "spinning at an operating speed"
  threshold, since real normal rotor RPM varies too much by type (Robinson
  R22 ~530, R44 ~453, Bell 206 ~394) for one hard number
- **Vertical Takeoff and Landing** (PH.IV.A) -- hover position (±4ft),
  altitude (±1/2 the hovering altitude within 10ft of the surface, else a
  flat ±5ft), and heading (±10°) held for a hover, then a vertical descent
  back to within 4ft of the takeoff point
- **Hover Taxi** (PH.IV.B) -- ground track (±4ft), altitude, and heading
  held while creeping forward
- **Normal Takeoff and Climb** (PH.V.A) -- airspeed and heading held
  (±10kt / ±10°) once a climb is established
- **Normal and Crosswind Approach** (PH.V.B) -- comes to a stable stop
  within 4ft of wherever it first slowed down and got low, rather than a
  point only the pilot knows (see Known limitations)
- **Steep Approach** (PH.V.D) -- same stop check, plus a derived approach
  angle (from descent rate vs. groundspeed) that must be steep (roughly
  8-15°) without exceeding the ACS's 15° maximum
- **Rapid Deceleration / Quick Stop** (PH.VI.A) -- heading held (±10°)
  while decelerating from forward flight to a hover
- **Straight-In Autorotation** and **Autorotation with Turns** (PH.VI.B/C)
  -- power-off glide airspeed (±10kt) and main rotor RPM (±10% of whatever
  it read right before the simulated chop -- see Known limitations) held
  through the glide to a controlled hover or touchdown; the turning version
  also requires an actual turn (≥90° total) rolled out at or above 300ft
  AGL

**Not implemented**: Slope Operations, Confined Area Operations, and
Pinnacle Operations (almost entirely site-selection/reconnaissance
judgment, not numeric ACS standards), Go-Around and Maximum Performance
Takeoff (same shape as tasks already built, just not done yet), and all of
Area VIII's emergency tasks -- Vortex Ring State, Low Rotor RPM Recognition,
Antitorque Failure, Dynamic Rollover, Ground Resonance -- since deliberately
provoking any of those is unsafe to script into a teleport/setup screen and
the ACS grades recognition/recovery judgment there, not a number.

## Install / update

```
./install.sh
```

This runs the offline tests, then copies `plugin/` into
`~/X-Plane 12/Resources/plugins/PythonPlugins/`. Run it again any time you
edit a file under `plugin/`. (First-time XPPython3 setup is already done on
this machine: it's installed at
`Resources/plugins/XPPython3/`, quarantine removed.)

Launch X-Plane, load any aircraft (tuned for the default Cessna 172 SP).
The window starts **hidden** -- the plugin is enabled for every flight
regardless of aircraft, so it doesn't pop open uninvited on, say, an
airliner flight that has nothing to do with a checkride. Open it via
X-Plane's menu bar > Plugins > Checkride Examiner > Show/Hide Window when
you actually want it.

To build the customer-facing distributable instead (a zip with
`PythonPlugins/`, `README.md`, `SPEC.md`, `INSTALL.txt`), run:

```
./package.sh
```

This runs `install.sh` (tests + sync into X-Plane) and then writes
`dist/CheckrideExaminer-vN.zip`, where `N` is read from `VERSION` and
incremented every run -- each build gets its own version number
automatically rather than one typed by hand, and older `-vN.zip` files are
left in place as a history rather than overwritten. `tools/` (the license
key generator) is deliberately excluded -- see License activation above.
`package.sh` also regenerates `plugin/checkride_examiner/_version.py`
(`PLUGIN_VERSION = N`) to match -- this is the version number the shipped
plugin actually knows about at runtime (see "In-app updates" below);
`VERSION` itself never ships in the distributable zip.

### Editions (restricted single/multi-rating builds)

```
./package.sh --ratings ppl_asel --label V1
```

builds a zip whose UI only lets a pilot pick the ratings listed (here,
just PPL/ASEL) -- every rating's task/syllabus code still ships inside the
package either way (splitting that out per edition isn't worth the
complexity, and the source isn't hidden from a curious user regardless,
same as the license-key situation below), only which ratings are
*selectable* is restricted, via `checkride_examiner/edition.py`'s
`SHIPPED_RATINGS`. `--label` controls the zip's file name
(`CheckrideExaminer-V1.zip` here instead of the usual `-v<N>.zip`) --
useful for a customer-facing label ("V1") distinct from the internal
build counter in `VERSION`, which keeps incrementing normally regardless
of edition. `--ratings` alone (no `--label`) derives a name from the
ratings list itself.

`edition.py` is only touched -- and always restored afterward, even if
the build fails partway -- around the staging/zip step; `install.sh`'s
test run and the sync into the local X-Plane install always use the
default, unrestricted `edition.py` (`SHIPPED_RATINGS = None`), so building
a restricted edition never leaves the local dev install artificially
limited for ongoing multi-rating testing.

**HARD RULE: a full (unrestricted, `--ratings` omitted) build must never
be pushed to the public `xplane-checkride-examiner-releases` distribution
repo, or anywhere else a customer's in-app updater could reach it.**
Per-rating sales depend on it -- a customer holding any one edition's
update channel must never be able to receive a build with more ratings
unlocked than they paid for. `package.sh` prints a loud warning whenever
it produces a full build for exactly this reason. This was violated once
in practice: several full builds were pushed to the distribution repo
while only one restricted (PPL/ASEL) edition had actually been sold, which
meant that edition's own "Check for Updates" would have silently upgraded
it to every rating unlocked. Fixed in three layers: (1) the leaked
full-build zips were removed from the distribution repo's history entirely
(the repo was deleted and recreated from a clean single commit, since a
force-push alone left old commit SHAs still fetchable from GitHub's own
caches for a while -- confirmed by directly re-testing an old raw URL
after the force-push and getting the leaked file back), (2) only
edition-restricted zips are published from then on, and (3) license keys
can now bind to specific ratings (see "Keys can bind to specific ratings"
below) so that even *if* a more permissive build ever became reachable
again, a customer's own key would still cap them at what they paid for --
this is the layer that actually closes the gap for good, since (1) and
(2) are operational discipline that can be violated again by mistake,
while (3) holds regardless. See "In-app updates" below for the remaining
single-manifest limitation this doesn't fully solve yet.

## In-app updates

An "Updates" button (Home screen, top bar, and shown as `Updates (vN)` on
Home, where `N` is the customer-facing `PUBLIC_VERSION` -- see "Version
numbers: internal vs. customer-facing" below) checks for and installs new
versions without leaving X-Plane or
manually re-downloading/re-copying files. This does **not** use SkunkCrafts
Updater (the de facto standard for X-Plane payware) -- it turned out to
require personally contacting its one maintainer to get a new addon
onboarded, with no public self-serve process (confirmed via several forum
threads spanning Nov 2024 to Jan 2026, all answered "DM me on Discord").
Rather than block shipping updates on that, `checkride_examiner/updater.py`
is a small from-scratch mechanism using only Python's standard library
(`urllib`/`json`/`zipfile`/`shutil`, already present in XPPython3's
embedded interpreter -- nothing new to install).

- **"Check for Updates"** fetches a small `manifest.json` from a *public*
  GitHub repo dedicated to distribution
  (`xplane-checkride-examiner-releases`, kept separate from this private
  source repo -- a private repo's raw/release URLs need an auth token an
  anonymous install obviously doesn't have) and compares its `version`
  field against the installed `PLUGIN_VERSION`.
- If newer, **"Download and Install"** downloads the linked zip, verifies
  it has the expected `CheckrideExaminer/PythonPlugins/...` layout, and
  only then replaces the installed `checkride_examiner/` folder and
  `PI_CheckrideExaminer.py` -- a malformed or truncated download is
  rejected before anything on disk is touched (see
  `tests/test_updater.py`'s malformed-zip case).
- This is **manual and user-initiated only** -- there is no automatic
  check on startup. SkunkCrafts Updater's own documentation warns about
  its older in-sim plugin version: "if a remote server is unresponsive
  then X-Plane will be unresponsive for a couple of minutes." A button
  means a slow/unreachable server can only ever stall that one click, not
  X-Plane's own startup.
- Installing a new version doesn't take effect immediately -- like any
  plugin file replacement, it needs X-Plane to restart or Plugins > Plugin
  Admin > Reload Scripts, which the Update screen says explicitly after a
  successful install.

**Known gap: there is currently only one `manifest.json`, shared by every
install regardless of edition.** That's fine while only one edition
(PPL/ASEL) has ever been sold -- the single manifest currently points to a
PPL/ASEL-restricted zip, so PPL/ASEL customers get appropriate updates.
But it does **not** generalize to selling more than one distinct edition:
as soon as a second edition exists (a different single rating, or a
bundle), a single shared manifest can't correctly tell a PPL/ASEL customer
and, say, an IR customer apart -- one of them would either get no update
or (worse, per the HARD RULE above) a build with rating(s) they didn't
buy. This needs a per-edition manifest (e.g. `manifest-<edition
key>.json`, with `updater.py` deriving the URL from `edition.py`'s own
`SHIPPED_RATINGS`/an explicit edition key) before a second paid edition
ships -- not yet built.

### Version numbers: internal vs. customer-facing

`PLUGIN_VERSION` (`_version.py`) is the real, monotonically-increasing
build counter `UpdateChecker` compares against the manifest's `version`
field -- it never resets and is never affected by anything below, so
update detection keeps working correctly for every install regardless of
when it was issued. But by the time the first real customer (a friend,
running the very first distributed build) was going to see a second
update, this project's internal build count had already climbed past 30
(dev churn, the full-build-leak incident and its remediation, etc.) --
showing that raw number in the UI (`Installed version: v32`, `Update
available: v33`) would have been confusing with no benefit to the
customer. `_version.py` also derives `PUBLIC_VERSION = PLUGIN_VERSION -
PUBLIC_VERSION_BASE`, a fixed one-time offset (set in `package.sh`, `=31`)
chosen so the first build shipped under this scheme displays as a clean
`v1` -- every later build then displays `v2`, `v3`, ... in step with the
raw counter, for **every** install (the friend's original one included,
since it keeps comparing on the untouched raw number). `overlay.py`'s
three version labels all use `PUBLIC_VERSION` (or, for a remote update's
number, `self._update_info.version - PUBLIC_VERSION_BASE`); nothing that
affects update *detection* ever uses it. `PUBLIC_VERSION_BASE` must never
change once set -- doing so would repeat or skip a customer-visible
version number.

## License activation

Before the home screen, first launch shows a LICENSE screen: enter the
serial key you received with your copy and press Activate. The key's own
format is checked entirely offline (`checkride_examiner/license.py`) -- a
key is a random payload plus a keyed checksum (HMAC-SHA256, truncated)
against a secret embedded in that file, so a random or mistyped string
fails but anything this plugin's own `generate_key()` minted passes. No
expiry: once activated, it's saved to the same X-Plane preferences folder
as Aircraft Settings (see below) and activation persists across restarts
and plugin updates. `is_licensed` gates both `AppController.start()` and
`start_practice()` directly (not just the overlay's screen order), so an
unactivated copy can't begin grading no matter how the UI is reached.

**Activating now also makes one online call, to enforce one license per
device.** A self-contained key/checksum, by design, validates identically
no matter how many machines it's typed into -- nothing purely offline can
stop the same key being activated on ten different computers. To actually
guarantee "1 license = 1 device," `checkride_examiner/activation.py` POSTs
the key plus a random per-install `device_id` to a small hosted server
(`/server/activation-worker.js`, a Cloudflare Worker -- see `/server/README.md`
for the one-time deploy steps) on every Activate press; the server accepts
whichever device presents a given key *first* and rejects every other
device from then on, with a clear on-screen reason
("already activated on a different installation..."). **This is a
one-time check at activation only, not continuous phone-home**: once it
succeeds, `is_licensed` goes back to being a purely local, offline check,
so the plugin still runs with no internet connection on any ordinary
flying day -- only pressing "Activate" itself needs connectivity. A
network failure at that moment fails *closed* (activation is refused, not
silently allowed) -- see `activation.py`'s module docstring for why that's
the one place in this plugin where "can't reach the network" isn't a
harmless, ignorable outcome. Moving a license to a new computer needs the
seller to clear the old binding first (`/server/README.md`'s
`/admin/reset`, protected by a separate admin token).

Honest limitations (see also Known limitations below): (1) because
`license.py` ships as plain, readable Python source, a person willing to
open the file and read `_SECRET` can mint their own valid-*looking* key --
device binding only stops a *legitimately issued* key from being shared
across machines, it can't tell a forged key from a real one, since the
activation server never re-derives or checks the checksum itself, only
tracks device binding for whatever key string it's handed. (2) copying the
entire `license.json` file (key *and* the device_id that already satisfied
the server), rather than just the key text, to a second machine is not
caught -- that would need continuous re-verification, which conflicts with
running fully offline the rest of the time. `tools/generate_license_key.py`
(the script that mints new keys) is a developer-only tool and is
deliberately left out of the distributed package by `package.sh`.

Already-activated pilots can view or replace their key from the Home
screen's "Change Key" button next to the license status line. The
plain-text fallback overlay (ImGui unavailable) has no text-input widget,
so it just displays a message pointing at the ImGui UI instead of a way to
activate.

### Keys can bind to specific ratings

`tools/generate_license_key.py --ratings ppl_asel` mints a key that only
ever unlocks PPL/ASEL -- the ratings a key authorizes are HMAC-covered
inside the key itself, not something the installed build decides alone.
This closes a real gap the "Editions" restriction above doesn't cover by
itself: `SHIPPED_RATINGS` caps what a given *build* exposes, but if a more
permissive build ever becomes reachable (exactly what happened once --
see Known Limitations' incident writeup), a customer's own legitimate key
would previously have unlocked whatever that build offered, since the key
carried no restriction of its own. Now the pilot only ever sees a rating
that's *both* in the build's `SHIPPED_RATINGS` *and* in their key's own
encoded set (`edition.visible_ratings()` intersects the two) -- so even a
leaked/misconfigured build can't unlock more than a specific key was
actually issued for.

Fully backward compatible: `generate_key()` with no `--ratings` (the only
form that existed before this) mints a "legacy" key that explicitly marks
itself as carrying no restriction, decoding as "whatever the build
allows" -- exactly its old behavior. Every key already issued keeps
working identically; nothing needs reissuing unless you specifically want
the extra layer for a given customer.

## Home screen

The window opens on a home screen, not straight into a checkride: pick a
rating, then "Start Checkride Mode" or "Start Practice Mode". Nothing is
tracked before you press one of those -- `AppController.started` gates
`tick()`, so simply loading the plugin (or sitting on the ramp deciding
what to fly) never silently starts grading Straight-and-Level in the
background. A "Home" button next to the rating label in either mode
returns you to this screen at any time without losing progress in either
mode; it's pure navigation, not a reset. (The plain-text fallback overlay,
used only if ImGui isn't available, has no clickable Home screen -- it
skips straight to Checkride Mode, same as before this feature existed --
though it still won't grade anything until a key is activated, same as the
ImGui backend.)

## Aircraft Settings (target speeds)

X-Plane has a dataref for stall speed (`acf_Vso`) and max structural
cruising speed (`acf_Vno`), but nothing for Vx/Vy, a VMC Demonstration
recovery speed (Vyse), or a Slow Flight target -- those are performance-
chart/POH numbers, not part of the basic flight model, and the real values
can differ by flight school on top of that. So the Home screen (and the top
bar of every other screen) has a "Settings" button where you type in this
aircraft's numbers once:

- **Vx and Vy** (Short-Field Takeoff and Maximum Performance Climb)
- **VMC Demonstration recovery speed**, e.g. Vyse (AMEL ratings only)
- **Slow Flight target speed** (an MCA speed, just above stall)
- Short-field approach speed (optional -- see below)

**The first three are mandatory.** Their task refuses to arm at all --
showing a red "SETTINGS REQUIRED" banner with an "Open Settings" shortcut
right on the task screen, in both Checkride and Practice Mode -- until the
number is entered for the currently-loaded aircraft (user-requested: a real
target speed varies too much by flight school/aircraft to guess at, so
there's no silent fallback for these three the way there is for short-field
approach speed below). Being blocked this way never counts against the
task's own arm-timeout clock -- it's not a flying failure, just missing
configuration -- so there's no risk of it silently failing out from under
you while you go set it up. Skip Task/Restart Session stay available if you
don't want to configure it right now.

Short-field approach speed stays optional: the ACS's own fallback formula
(1.3 x Vso) is a real, aircraft-specific number X-Plane already reports, so
leaving it at 0 there just uses that instead of blocking.

Settings are saved **per aircraft**, keyed by its `.acf` file name, to a
JSON file in X-Plane's own preferences folder (`dirname(xp.getPrefsPath())`
-- not inside `checkride_examiner/`, so overwriting that folder on a plugin
update, per the Install/update instructions above, never touches it). Load
a different add-on and its own settings (or lack of them) apply
automatically -- the Home screen shows which aircraft is currently loaded
and flags it with a note if it isn't registered yet, so you're reminded
every time you fly an aircraft you haven't set up. Registering one
aircraft's numbers never leaks onto another.

### Pre-flight check (both modes)

Neither "Start Checkride Mode" nor "Start Practice Mode" drops you
straight into flying anymore. Both go through a PRE-FLIGHT CHECK screen
first:

- **Anything mandatory still missing** (Vx/Vy, VMC Demo recovery speed,
  Slow Flight target -- see above) -- every distinct reason is listed up
  front, with an "Open Settings" shortcut, and nothing can start until
  all of them are resolved. In Checkride Mode this scans the whole
  rating's ordered syllabus; in Practice Mode it scans every catalog
  entry available under the chosen rating (a throwaway task instance per
  entry, just to ask `blocking_reason()` -- none of them are started or
  graded), not just whichever one you're about to pick.
- **Everything's already registered** -- a one-screen summary of the
  aircraft's current Vx/Vy/VMC-recovery/Slow-Flight/short-field-approach
  numbers, with a "Confirm and Start" button.

Before this, a tester could sail past several tasks (or pick one practice
entry after another) and only be told a number was missing when a specific
maneuver's turn came up -- a mandatory Settings gate that used to surface
as a surprise interruption (user-reported: "速度系が入ってないとマニュー
バ前に言われる"). Now every mandatory number for the chosen rating is
resolved (or confirmed) once, before anything starts. `AppController.start()`
itself is deferred until this screen confirms, for either mode -- so no
grading/tracking can begin while it's showing, the same guarantee
`is_licensed` already gave the license gate.

## Weather (IR immersion)

X-Plane 12's regional weather is controllable through writable
`sim/weather/region/*` datarefs (cloud layer, visibility, etc.). A
"Weather" button (Home screen and the top bar in any mode) applies one of
three named presets:

- **Clear (VMC)** -- resets to clear skies, 15sm visibility.
- **Overcast (en-route IMC)** -- overcast ~2,500 ft AGL, 3sm visibility.
- **Low IFR (approach practice)** -- overcast ~300 ft AGL, 0.75sm
  visibility (an approximation of typical approach minimums, not any
  specific published minimum).

Ceilings are computed from your *current* ground elevation (same
"elevation minus AGL" technique `reposition.py` uses), so a preset means
roughly the stated AGL number regardless of local terrain -- but only at
the moment you click it, not continuously, so climbing/descending a long
way afterward can put the cloud layer at an AGL other than what you picked.

**This is presentation only.** No task reads weather state -- grading
(CDI dots, altitude, airspeed, MDA/DA, etc.) is identical in any weather.
The point is being able to actually fly an IR task in reduced visibility
for realism, not to change what's checked.

## Two modes: Checkride Mode and Practice Mode

Once past the home screen, switch between the two modes any time with the
two buttons at the top of the window (or Plugins menu > Checkride Examiner
> Switch to ...). Switching never resets the other mode -- leave a
checkride mid-session, practice a task, and come back to find it exactly
where you left it.

- **Checkride Mode**: the full ordered task session for whichever rating
  is selected (see above). Pass/fail is withheld until the end (see below).
  When one task finishes, the next one doesn't start watching for its own
  arm condition until you press **Ready** (also bindable as
  `checkride/examiner/ready`) -- there's no timer or timeout of its own, so
  take as long as you need. This mirrors what a real DPE does (waiting for
  your "ready" call before starting the next maneuver's clock) and fixes a
  real issue: without it, the tail end of the task you just finished (still
  recovering from a stall, rolling out of a steep turn) could immediately
  satisfy the next task's arm condition before you'd actually started it.
  Skipped for multiple-choice quiz tasks -- those can just be answered
  right away, no "recovering from the last maneuver" concern applies.
- **Practice Mode**: pick a rating with the same selector buttons as
  Checkride Mode, then pick any single task from that rating's catalog
  (PPL/AMEL and Commercial Pilot/AMEL each also include everything their
  single-engine version has, same as the checkride syllabus). Ground tasks
  (ATC quiz, taxi, run-up) start immediately from wherever you currently
  are. **Airborne tasks go to a setup screen first**, where you pick:
  - **Start location**: "Current Position" (teleports straight up from
    where you are), or one of the airports found nearby in the currently
    loaded scenery, picked from a distance-sorted list. This is a list,
    not a visual map -- X-Plane's plugin API can draw markers on its own
    map but can't report clicks back to a plugin, so there's no way to tap
    a point on a real map and get a lat/lon from it. `airports.py` finds
    candidates by scanning the loaded nav database for airports.
  - **Altitude (ft AGL)**, **airspeed (kt)**, and **pitch (deg, + nose
    up)** via sliders, pre-filled with sensible per-task defaults (e.g.
    Steep Turns: 4,000 ft AGL / 100 kt / 0°; Slow Flight: 3,000 ft AGL /
    90 kt / 0°) that you can override.

  Press "Start" to teleport (if airborne) and begin. Feedback is immediate
  (SATISFACTORY/UNSATISFACTORY + notes as soon as the task finishes), and
  "Try Again" reruns the same task with the *same* setup you chose
  (repositioning again if it's airborne) as many times as you want.
  - The location picker only changes *where* you teleport to -- it's still
    a hard cut, not a flight there. It writes directly to `local_x/y/z`,
    `local_vx/vy/vz`, and `phi/theta/psi` (`reposition.py`) -- the standard
    XPLM reposition technique -- so it works with any aircraft, but pitch
    only sets the initial attitude/velocity component; it doesn't trim the
    aircraft, so it may drift back toward level on its own afterward.
  - **The teleport itself gets a settling grace period before grading
    starts.** A hard position/velocity cut can leave the flight model
    momentarily unsettled (an attitude/velocity transient for a frame or
    few as X-Plane's physics reconciles the sudden change), and since the
    catalog's default start conditions are deliberately chosen to already
    satisfy most tasks' arm conditions, a task would otherwise arm on that
    very first, unsettled frame -- meaning the teleport's own transient got
    graded as if it were the start of the maneuver. `PracticeSession`
    doesn't call the task's `update()` at all for `SETTLE_S` (1 second)
    after an airborne reposition, so nothing the task tracks (arm
    conditions, reference position, anything) ever sees that transient.
  - **The engine is force-started on teleport** (mixture full rich,
    ignition both, fuel pump on, prop mode normal, throttle set to a
    cruise-ish default) -- otherwise a reposition from a cold-and-dark ramp
    start, or right after shutting the engine down practicing something
    else, would leave you gliding with no way to arm any task that needs
    power. Flipping `ENGN_running` true turned out not to be enough on its
    own (confirmed in testing) -- it's a status flag the flight model
    reports, not one that drives it, so the engine stayed "on" but the
    crankshaft/prop stayed at 0 RPM. The actual fix also writes the
    physically-simulated rotation speed directly, `ENGN_tacrad` (engine)
    and `POINT_tacrad` (prop), both in rad/sec, so there's something
    already spinning for the engine model to sustain. This is still the
    standard "instant relight" trick plugins use; it may not stick on a
    study-level aircraft with its own engine-start modeling.
  - Practice Mode (task catalog, setup screen, sliders), the Settings
    screen, and the License screen all need the ImGui UI (specifically its
    text-input widget for Settings/License); if XPPython3 falls back to the
    plain-text overlay (see below), there's no way to enter Vx/Vy, VMC
    recovery speed, or a Slow Flight target, so those three tasks stay
    permanently blocked (the plain overlay says so instead of grading
    anything), and there's no way to activate a license at all either. See
    Known limitations for how license validation itself works and its
    trade-offs.

## UI / Controls

The overlay is an ImGui window (colored per-parameter tolerance bars, a
1-11 task progress strip, in-window buttons) rendered with XPPython3's
bundled pyimgui + PyOpenGL. If that stack isn't available for some reason,
the plugin automatically falls back to a plain text overlay instead of
failing to load -- check `XPPython3Log.txt` if you ever see the plain
version and expected the ImGui one.

Three ways to control the session, all equivalent:

- **Buttons in the window**: "Skip Task" / "Restart Session", a "Ready"
  button while waiting between tasks, plus a "Restart Session" button on
  the final debrief screen. An ATC task shows four answer buttons (A-D)
  instead. The Home screen also has "Settings" (Aircraft Settings) and
  "Change Key" (License activation) buttons. A task with a missing
  mandatory setting (Vx/Vy, VMC recovery speed, Slow Flight target -- see
  Aircraft Settings above) shows an "Open Settings" shortcut right there
  instead of anything to fly.
- **Plugins menu > Checkride Examiner**: Show/Hide Window, Skip Current
  Task, Ready for Next Task, Restart Session.
- **X-Plane commands** (Settings > Keyboard, if you want a hotkey/joystick
  button): `checkride/examiner/skip_task`, `checkride/examiner/ready`,
  `checkride/examiner/restart`, `checkride/examiner/answer_a` ..
  `answer_d` (for the ATC quiz).

Otherwise the session runs itself: each task arms automatically once you
enter roughly the right setup (e.g. rolling into a bank arms Steep Turns,
slowing to at or below the registered Slow Flight target speed arms that
task -- see Aircraft Settings above and Known limitations for why a
registered number is required rather than a guess). The window also
previews the next task.

**Pass/fail is withheld until the end**, like a real checkride: the
progress strip and task list only show how far along you are (attempted /
current / not yet reached), never which of the attempted tasks were
satisfactory. Only the final debrief screen, once every task has been
attempted, reveals per-task results and the overall score.

## Architecture

- `plugin/PI_CheckrideExaminer.py` -- XPPython3 entry point: reads DataRefs
  once per frame, feeds them to the session, owns the Plugins-menu entries,
  and resolves the aircraft-settings and license file paths (X-Plane's own
  preferences folder, via `dirname(xp.getPrefsPath())`) to build the
  `AircraftSettingsStore` and `LicenseStore` passed into `AppController`.
- `plugin/checkride_examiner/aircraft_settings.py` -- `AircraftSettings` (a
  plain dataclass: `vx_kt`/`vy_kt`/`vmc_recovery_kt`/`slow_flight_kt`
  (mandatory, blocking when 0) and `short_field_approach_kt` (optional,
  has a real Vso-formula fallback) and `AircraftSettingsStore`, which
  loads/saves them as JSON keyed by aircraft `.acf` file name. No XPPython3
  import (a bare `path` string in, `path=None` runs fully in-memory) so
  it's unit-testable and reusable the same way `state.py`/`grading.py` are;
  a corrupt file is treated as empty rather than raised, so a hand-edited
  or truncated JSON file can't take the plugin down.
- `plugin/checkride_examiner/license.py` -- offline serial-key validation:
  `generate_key()`/`is_valid_key()` (a random payload plus a truncated
  HMAC-SHA256 checksum against an embedded secret, Crockford base32
  encoded) and `LicenseStore`, same JSON-file/atomic-write/corrupt-tolerant/
  in-memory-if-`path=None` pattern as `AircraftSettingsStore`. No XPPython3
  import. `AppController.is_licensed`/`start()`/`start_practice()` are the
  only things that read it. `generate_key(ratings=...)` /
  `decode_licensed_ratings()` bind a key to a specific ratings set (bit 7
  of the payload's first byte marks "this key encodes a restriction"; bits
  0-5 are the ratings bitmask, checksum-covered like the rest of the
  payload) -- see "Keys can bind to specific ratings" above.
  `AppController.licensed_ratings` exposes the currently-activated key's
  decoded set (or `None` for a legacy/unrestricted key) for
  `edition.visible_ratings()` to intersect with the build's own
  `SHIPPED_RATINGS`.
- `plugin/checkride_examiner/overlay.py` -- the ImGui UI (`_ImguiBackend`)
  plus the plain-text fallback (`_PlainBackend`); `ExaminerOverlay` picks
  whichever import succeeded. Every ImGui call not covered by XPPython3's
  typed stub is individually try/except-wrapped, because XPPython3's window
  wrapper permanently stops rendering a window after any exception escapes
  its draw callback.
- `plugin/checkride_examiner/state.py`, `grading.py`, `util.py` -- pure
  Python, no XPPython3 import. `FlightState` is a plain dataclass;
  `ToleranceTracker` implements "must be out of tolerance continuously for
  more than N seconds to bust the task" (mirrors how a real examiner
  tolerates a brief excursion but flags a sustained one), plus an optional
  `gate_until_captured` flag that doesn't start that clock at all until
  the tracked value has entered tolerance once (see the capture-gate
  bullets under Known Limitations) -- used by every approach/takeoff/
  climb task that arms before the aircraft has had time to actually reach
  its target speed. Covered by `tests/test_grading.py`.
- `plugin/checkride_examiner/tasks/*.py` -- one state machine per task
  (arm on some entry condition -> hold/track -> grade). `tasks/base.py`'s
  `HoldTask` factors out the common "wait, then hold reference values"
  shape used by several of the tasks, and its `Task.blocking_reason()` hook
  (no-op by default) is how `ShortFieldTakeoffTask`, `VmcDemonstrationTask`,
  and `SlowFlightTask`/`CommercialSlowFlightTask` refuse to arm at all
  until a mandatory Aircraft Settings value is entered -- `HoldTask.update()`
  checks it before ever starting the arm-timeout clock, so being blocked on
  missing Settings can never itself time out into a failure.
  `tasks/ground_ops.py` holds
  taxi/run-up. `tasks/quiz.py` holds `MultipleChoiceTask` -- unlike every
  other task, it never completes from `update()`; it waits for
  `ExaminerSession.submit_answer(index)` (wired to overlay buttons and the
  answer_a..d commands) to grade and finish. `tasks/nav_tracking.py`,
  `tasks/holding.py`, `tasks/approaches.py`, `tasks/missed_approach.py` are
  the IR-specific tasks; `approaches.py`'s two tasks only ever *append* new
  trackers as they move through phases (enroute -> final) rather than
  replacing `self.trackers`, so a bust from an earlier phase is never
  silently dropped from grading when the phase changes. `tasks/chandelle.py`,
  `tasks/lazy_eight.py`, `tasks/accelerated_stall.py` are the three
  Commercial-only maneuvers; Commercial's tighter-tolerance slow flight and
  stalls are subclasses in `tasks/slow_flight.py` / `tasks/stalls.py`
  (`CommercialSlowFlightTask`, `CommercialPowerOffStallTask`,
  `CommercialPowerOnStallTask`) that just override tolerance class
  attributes, and `SteepTurnTask`/`EmergencyDescentTask` take a
  `target_bank`/`acs_ref`/`bank_required` constructor param so the same
  class serves both PPL (45° bank, advisory descent-bank) and Commercial
  (50° bank, graded descent-bank) rather than duplicating the state machine.
  `EmergencyDescentTask` also hard-busts a real `state.vno_kt` overspeed
  during the descent, on top of its pre-existing (and correctly
  self-referential) entry-speed hold check. `tasks/multiengine.py`
  (`EngineFailureAfterLiftoffTask`, `ManeuveringOneEngineInoperativeTask`)
  and `tasks/vmc_demo.py` (`VmcDemonstrationTask`) are the AMEL-specific
  tasks, shared between PPL/AMEL and Commercial/AMEL the same way -- an
  `acs_ref` (and, for VMC, `recovery_low`/`recovery_high`) constructor
  param picks which rating's label/tolerance applies.
  `VmcDemonstrationTask` grades its recovery airspeed against the
  registered `vmc_recovery_kt` Aircraft Setting (mandatory -- see Aircraft
  Settings above), not a self-reference. Both arm on asymmetric engine
  power (`throttle_ratio` vs `throttle2_ratio`, see `datarefs.py`), which
  is why none of them can ever arm on a single-engine aircraft.
  `tasks/heli_hovering.py`, `tasks/heli_takeoff_landing.py`,
  `tasks/heli_performance.py` are the PPL/Helicopter tasks -- an entirely
  separate task shape from every airplane task above (hovering, vertical
  takeoffs, autorotations), sharing only the base `Task`/`ToleranceTracker`
  machinery. `AutorotationTask(require_turn=...)` covers both Straight-In
  and With-Turns the same parameterized way `SteepTurnTask` covers PPL/CPL.
  `tasks/short_field.py` (`ShortFieldTakeoffTask`, `ShortFieldApproachLandingTask`)
  are PPL/CPL's Short-Field Takeoff and Landing, both taking an `acs_ref`/
  `tolerance_low`/`tolerance_high` constructor param (landing also takes
  `touchdown_distance_ft`) to pick Private's or Commercial's numbers, same
  pattern as `SteepTurnTask`. These are the first tasks to read
  `state.flap_ratio` (actual flap deployment) to check configuration/
  technique instead of just attitude/airspeed, `state.vso_kt`
  (`sim/aircraft/view/acf_Vso`) to grade the landing's approach speed
  against the ACS's real 1.3 x Vso formula, and the first to override
  `Task.configure_from_settings()` -- `AppController` calls this whenever
  the loaded aircraft (or its saved settings) changes, handing over an
  `AircraftSettings` with that aircraft's registered values. Only
  `ShortFieldTakeoffTask` (Vx/Vy) is mandatory/blocking here --
  `ShortFieldApproachLandingTask`'s approach speed stays optional, since
  1.3 x Vso is a sound automatic fallback. `util.resolve_approach_speed()`
  is the shared "published speed, else 1.3 x Vso, else None" helper used by
  this task and the two landing tasks below, so that formula lives in one
  place instead of three.
  `tasks/normal_landing.py` (`NormalTakeoffTask`, `NormalLandingTask`) and
  `tasks/soft_field.py` (`SoftFieldTakeoffTask`, `SoftFieldLandingTask`)
  reuse the exact same `AircraftSettings.vy_kt` /
  `short_field_approach_kt` fields as Short-Field's -- they're the same
  real POH numbers regardless of takeoff/landing technique, so there's no
  reason to add near-duplicate Settings fields for them. The soft-field
  pair are the first tasks to read `state.yoke_pitch_ratio`
  (`sim/cockpit2/controls/yoke_pitch_ratio`, the pilot's own raw elevator
  control input, not the resulting surface deflection) to hard-grade
  sustained back-elevator pressure during the ground roll/rollout -- a
  real, verifiable check for an ACS skill ("transfer weight from wheels to
  wings") that has no other dataref standing in for it.
  `tasks/go_around.py` (`GoAroundTask`) needs no runway/landing-point data
  at all -- it just watches for the throttle to cross a "go-around power
  applied" threshold while airborne, then grades the resulting Vy climb and
  heading hold the same way the takeoff tasks do.
  `tasks/traffic_pattern.py` (`TrafficPatternTask(direction=...)`) can't
  grade against a real runway heading either (X-Plane exposes no
  runway-geometry dataref, and the XPLM navigation API's airport lookup --
  `airports.py` -- only reports airport reference points), so like Turns
  Around a Point it grades a self-referenced downwind-to-final turn
  instead, using the same early-rollout-vs-exact-360 fix as
  `SteepTurnTask` (grade on rollout, not on an exact cumulative-degrees
  threshold) scaled down to a 180° turn.
- `plugin/checkride_examiner/sequence.py` -- `build_ppl_asel_syllabus()` /
  `build_ir_syllabus()` / `build_cpl_syllabus()` / `build_ppl_helicopter_syllabus()`
  build each rating's task list; `build_ppl_amel_syllabus()` / `build_cpl_amel_syllabus()` are the
  ASEL/Commercial list plus the 3 AMEL tasks appended, since a real twin
  checkride covers everything the single-engine one does. `RATINGS` is the
  registry the overlay's rating selector renders. `ExaminerSession(rating=...)`
  walks whichever list in order, collecting `TaskResult`s (Checkride Mode);
  `restart()` rebuilds the *same* rating, not always PPL/ASEL. Every way a
  task can finish (a flight-data tick, a quiz `answer()`, or `skip_current()`)
  goes through one shared `_advance()`, which sets `is_waiting_for_ready`
  (unless the next task is a quiz) so the next task's `update()` is never
  called until the pilot calls `ready()` -- the same "don't let the task
  see any data until told to" idea `PracticeSession`'s `SETTLE_S` uses
  after a teleport, except pilot-paced rather than timer-based here.
- `plugin/checkride_examiner/practice.py` -- `PracticeSession` runs one
  task at a time with immediate feedback and a `retry()` (Practice Mode);
  `PRACTICE_CATALOG` is every practiceable task across all 6 ratings, each
  tagged with a `ratings` tuple so the overlay's rating filter can show
  only the relevant subset (mirroring each rating's checkride syllabus --
  e.g. `ppl_amel` entries are PPL/ASEL's 17 plus the 3 AMEL-only tasks).
  After an airborne reposition, `PracticeSession` withholds `SETTLE_S`
  (1s) worth of ticks from the task entirely -- not even `update()` is
  called -- so the teleport's own settling transient can never be graded
  as part of the maneuver.
- `plugin/checkride_examiner/controller.py` -- `AppController` owns both
  sessions and a `mode` flag, and routes `tick()`/`skip_current()`/
  `submit_answer()` to whichever is active. Also owns the
  `AircraftSettingsStore` and tracks `state.aircraft_key`; on any change
  (aircraft loaded/switched, or `save_aircraft_settings()` from the
  Settings screen) it calls `configure_from_settings()` on every
  currently-relevant task -- the current checkride session's full task
  list and the active practice task, if any -- so a task built before the
  aircraft was known still picks up its settings, and a rating switch or
  session restart's freshly-built tasks are configured immediately rather
  than waiting for the next aircraft change. It also tracks
  `last_vso_kt` from every tick, purely so the Settings screen can suggest
  a starting Slow Flight target (1.2 x that) instead of a bare 0 slider.
  `checkride_blocking_reasons()` collects every distinct
  `Task.blocking_reason()` across the current session's full syllabus,
  deduplicated; `practice_blocking_reasons(rating)` does the same for
  every `PRACTICE_CATALOG` entry available under a rating, building a
  throwaway `Task` per entry via `PracticeEntry.factory()` purely to ask
  it -- both are the data source for the pre-flight check screen (see
  above). `overlay.py`'s "Start Checkride Mode" and "Start Practice Mode"
  buttons no longer call `start()` directly, deferring it until that
  screen confirms.
- `plugin/checkride_examiner/reposition.py` -- `Repositioner`, teleports
  the aircraft for Practice Mode's airborne tasks; accepts an optional
  lat/lon/ground-elevation override plus pitch, beyond just AGL/airspeed.
- `plugin/checkride_examiner/airports.py` -- `find_nearby_airports()`,
  the setup screen's location picker: scans the loaded nav database for
  nearby airports (list, not a visual map -- see below) once per button
  press, not per flight-loop tick.
- `plugin/checkride_examiner/weather_presets.py` / `weather.py` -- named
  IR-immersion weather presets (clear/en-route IMC/low IFR) and the
  `WeatherController` that applies one via the writable
  `sim/weather/region/*` datarefs. Split into a pure-data file (imported by
  `controller.py`, so it has to stay usable without X-Plane installed) and
  the `xp`-importing one that actually writes datarefs, the same split as
  `sequence.py`/`practice.py` vs. `reposition.py`. Presentation only --
  no task ever reads weather state, so this never changes what's graded.
- `plugin/checkride_examiner/updater.py` -- `UpdateChecker`
  (check/download/install from the public distribution repo's
  `manifest.json`), plus `_version.py`
  (`PLUGIN_VERSION`, regenerated by `package.sh`). Unlike
  `reposition.py`/`weather.py`, this imports no `xp` at all (just
  `urllib`/`json`/`zipfile`/`shutil`/`ssl`), so `controller.py` imports it
  directly rather than needing a pure/impure split -- `check()`/`apply()`
  still take injectable `fetch_json`/`download` params purely so
  `tests/test_updater.py` can exercise the real logic without a real
  network call. Every HTTPS request builds its `SSLContext` from a
  vendored `cacert.pem` sitting next to this file (see the "Fixed: ...SSL
  certificate verification" bullet below) rather than the interpreter's
  own default trust store.
- `plugin/checkride_examiner/edition.py` -- `SHIPPED_RATINGS` /
  `visible_ratings()`, the restricted-edition mechanism (see "Editions"
  above). No `xp` import; `overlay.py` filters all three of its rating
  pickers (Home, Checkride Mode's top bar, Practice Mode's catalog filter)
  through `visible_ratings()` rather than iterating `RATINGS` directly --
  each call site passes `controller.licensed_ratings` too, so the build's
  own restriction and the activated key's own restriction (`license.py`)
  are both applied, independently of each other.
- `plugin/checkride_examiner/datarefs.py` -- reads X-Plane's DataRefs into
  a `FlightState`; everything except `datarefs.py`, `reposition.py`,
  `airports.py`, `weather.py`, and `overlay.py` only ever sees plain
  `FlightState`/`Task` objects, which is why `tests/` can run without
  X-Plane installed at all.

## Tolerance sources

**PPL/ASEL**: all numeric tolerances are pulled from the FAA Private Pilot -
Airplane ACS (FAA-S-ACS-6 / -6B), specifically as tabulated by
OregonFlightSchool.com (Nov 2018, ACS-6B) and an AirTrekNorth Cessna 172 ACS
settings summary (ACS-6, June 2016) -- both cited in comments at the top of
each task file. Short-Field Takeoff/Landing (PA.IV.E/F) is the exception:
those numbers were read directly from the current FAA-S-ACS-6C PDF
(faa.gov), fetched fresh rather than from either secondary source above.

**Instrument Rating**: pulled directly from the skill (`.S#`) bullets of the
FAA Instrument Rating - Airplane ACS (FAA-S-ACS-8C, November 2023), read
from a Gleim Aviation reproduction of the PDF, cited task-by-task
(IR.III.A/B, IR.V.A, IR.VI.A/B/C) in `tasks/nav_tracking.py`,
`tasks/holding.py`, `tasks/approaches.py`, `tasks/missed_approach.py`.

**Commercial Pilot**: pulled directly from the skill (`.S#`) bullets of the
FAA Commercial Pilot - Airplane ACS (FAA-S-ACS-7B), fetched straight from
faa.gov, cited task-by-task (CA.IV.E/F, CA.V.A/C/D, CA.VII.A/B/C/D, CA.IX.A)
in `tasks/short_field.py`, `tasks/steep_turns.py`, `tasks/chandelle.py`,
`tasks/lazy_eight.py`, `tasks/slow_flight.py`, `tasks/stalls.py`,
`tasks/accelerated_stall.py`, `tasks/emergency_descent.py`.

**AMEL (both ratings)**: pulled directly from the skill (`.S#`) bullets of
the same two ACS documents' Area IX.F and Area X.A/B/C, fetched straight
from faa.gov -- Private's and Commercial's numbers turned out identical
except VMC Demonstration's recovery-airspeed tolerance, cited in
`tasks/multiengine.py` and `tasks/vmc_demo.py`.

**PPL/Helicopter**: pulled directly from the skill (`.S#`) bullets of the
FAA Private Pilot for Rotorcraft Category Helicopter Rating ACS
(FAA-S-ACS-15, November 2023), fetched straight from faa.gov, cited
task-by-task (PH.II.C, PH.IV.A/B, PH.V.A/B/D, PH.VI.A/B/C) in
`tasks/heli_hovering.py`, `tasks/heli_takeoff_landing.py`,
`tasks/heli_performance.py`. Main rotor RPM's normal-range tolerance is the
one number here that is NOT from the ACS (which just says "within normal
limits" -- see Known limitations).

If the FAA revises any of these, re-check these numbers against the current
`FAA-S-ACS-6` / `FAA-S-ACS-8` / `FAA-S-ACS-7` / `FAA-S-ACS-15` PDFs on
faa.gov.

## Known limitations / heuristics (read before trusting a grade)

- **Normal/Short-Field/Soft-Field Landing no longer track heading.** An
  earlier version copied the takeoff tasks' directional-control check
  (arm, then hold +/-10deg from whatever heading you were on) onto the
  landing tasks too -- but they armed as soon as descent began
  (`vs_fpm < -100`), which routinely happens while still on downwind, and
  then held that downwind heading through the entire approach. A real
  approach turns ~180deg through downwind/base/final, so this busted a
  perfectly normal pattern every time the pilot turned base (user-reported:
  "Short-Field LDGのreadyボタンを押すのは基本的にDownwindなんだけどHDGの
  せいでfailになる"). Unlike the takeoff tasks' directional-control check
  (PA.IV.A.S12 -- a legitimate straight climb-out), the landing tasks' own
  ACS skills (PA/CA.IV.B/D/F) have no heading requirement at all, so this
  was removed rather than reworked to apply only once established on final
  -- there's no reliable dataref-only way to detect "now on final" without
  runway-heading data (same limitation as Traffic Pattern). Takeoff tasks
  are unaffected; they still correctly hold heading through the climb-out.
- **Normal/Short-Field/Soft-Field Landing's airspeed check is now
  capture-gated, not live from the moment of arming.** Same root cause as
  the heading bug above: arming happens as soon as descent begins, which
  is routinely still on downwind at something close to cruise speed --
  and decelerating from there to the target approach speed takes far
  longer than the tolerance tracker's 3s grace period, so the task could
  bust in the very first moments of the approach purely for not having
  slowed down yet (user-reported: "Down windではまだクルーズスピードに
  近いスピードも出ているだろうし"). Unlike heading, this didn't need any
  runway/pattern data to fix properly: the tolerance tracker's `update()`
  is now only called once IAS has actually entered the target band at
  least once (the same "capture" idea `tasks/approaches.py` already uses
  for glideslope) -- being fast while still slowing down on downwind is
  never counted against the pilot, but destabilizing *after* being
  established still busts exactly as before. If the approach speed never
  captures at all before touchdown, that's now a non-hard advisory note
  ("approach speed was never within tolerance... before touchdown")
  instead of silently passing or unfairly failing.
- **Every takeoff/climb task's Vx/Vy check got the same capture gate,
  for the mirror-image reason.** Short-Field/Normal/Soft-Field Takeoff and
  Go-Around all used to start grading Vx/Vy the instant of liftoff (or,
  for Go-Around, the instant go-around power is applied) -- but the
  aircraft hasn't had time to accelerate from rotation/approach speed up
  to the target yet, so these could bust in the first moments of the
  climb purely for not having sped up yet (user-reported: "Takeoff系も
  なんだけど速度が乗るまで少し時間がかかる"). Soft-Field Takeoff was
  arguably the worst-exposed of the five, since its own ACS skill list
  explicitly calls for a deliberate ground-effect acceleration period
  *before* climbing at Vy, not an immediate climb. `gate_until_captured`
  moved from a bespoke boolean flag in each of the (now eight) affected
  tasks into `ToleranceTracker` itself (`grading.py`) -- one shared,
  tested primitive instead of three-then-eight near-identical copies of
  the same gating logic (see `tests/test_grading.py`). Same "never
  captured" advisory-note treatment as the landing tasks; takeoff tasks'
  heading checks are untouched (still ungated, still legitimate).
- **Fixed: the Update screen's network call could fail on SSL certificate
  verification, depending on the Python environment's CA bundle.**
  Originally flagged as a documented-but-unconfirmed risk (a python.org-
  installed CPython 3.13 raised `CERTIFICATE_VERIFY_FAILED` on the exact
  same `urllib` call that worked fine under macOS's system Python 3.9),
  then actually hit for real on a live XPPython3 install pressing "Check
  for Updates" (user-reported, same error). Confirms XPPython3's embedded
  interpreter can ship with no usable root CA list on some platforms --
  the same failure mode python.org's own macOS installer is notorious
  for. Fixed by vendoring a static root CA bundle
  (`checkride_examiner/cacert.pem`, the standard Mozilla bundle via the
  `certifi` project, shipped as a plain file rather than a pip dependency
  XPPython3 may not be able to install) and loading it explicitly via
  `ssl.create_default_context(cafile=...)` for every HTTPS call
  `updater.py` makes -- so certificate verification no longer depends on
  whatever trust store (if any) the host Python happens to have.
  Deliberately does NOT fall back to disabling verification (that would
  make `apply()` -- which downloads and installs executable Python code --
  trust literally anything on the network, a real MITM risk); it only
  falls back to the interpreter's own default context if the vendored
  file is somehow missing. Re-verified end-to-end (real network, real
  manifest, real zip) on the exact Python installation that originally
  reproduced the failure. Being a vendored snapshot, it will eventually
  need refreshing as root CAs rotate -- see SPEC.md for how.
- **The Weather panel's plugin-takes-control mechanism is unconfirmed
  against a live sim.** `weather.py` writes `sim/weather/region/*`
  datarefs and relies on X-Plane 12's documented behavior that doing so
  automatically flips `sim/weather/region/weather_source` to Plugin (3) --
  that dataref is marked read-only from a plugin's side, so there's no way
  to set it directly and verify the switch happened other than watching it
  in DataRefEditor. If a preset appears to do nothing, check that first.
  Only cloud layer 0 (of 3) is set. Cloud changes normally fade in over
  ~60s; `apply()` fires the `sim/operation/regen_weather` command right
  after writing the cloud arrays, which X-Plane's own weather-dataref docs
  say forces an immediate refresh instead -- but that combination hasn't
  been confirmed live either, so if a preset's clouds are slow to appear,
  that's the first thing to check.
- **The inter-task Ready gate has no timeout of its own.** If you forget
  to press Ready (or don't notice the prompt), the session simply waits --
  forever, if need be -- rather than silently starting to grade you. This
  is deliberate (pilot-paced, like a real DPE), but means a distracted
  pilot could sit "between tasks" indefinitely without realizing it; the
  progress strip still shows the next task as current/highlighted either
  way. It also only gates flight-data arm conditions (`Task.update()`); a
  multiple-choice quiz's answer buttons stay clickable immediately, since
  answering a knowledge question doesn't have the same "residual state
  from the last maneuver" problem.
- **Stall recognition** is approximated as "stall warning sounds
  continuously for >= 2s", not actual angle-of-attack / aerodynamic stall.
- **Steep Turns finishes on rollout, not on an exact 360.0° running sum.**
  Judging rollout by eye against the entry heading (like a real DPE) means
  landing a few degrees short of, or past, a literal 360° is normal -- the
  original implementation required the net signed heading sum to reach
  exactly >=360° before it would finish, so rolling out a bit early (a
  completely normal way to fly it) left the heading no longer changing and
  the task waiting for a sum that would never arrive, until it timed out at
  90s (user-reported as the turn "never ending"). It now also finishes as
  soon as you roll back out of the bank (`ARM_BANK_DEG`) once at least 300°
  of net turn has been made -- short of that floor, rolling level is still
  graded as bailing out early, not as a legitimate rollout.
- **The real root cause of "the turn never ends" turned out to be which
  heading dataref was being read, not just the rollout logic above** (the
  rollout fix alone didn't stop the same report from recurring). Heading
  used to come from `sim/cockpit/misc/compass_indicated` -- X-Plane's
  simulation of the panel's actual wet magnetic compass, which realistically
  models that instrument's real-world turning/dip errors (a related
  dataref's own DataRefs.txt description says outright that a
  magnetometer-derived heading is "only accurate in straight and level
  flight"). That makes it least accurate exactly while banked -- the one
  moment every cumulative-turn task (Steep Turns, Chandelle, Lazy Eight,
  Turns Around a Point, Traffic Pattern, Holding Procedure) needs it most,
  and could keep the running total from ever reaching even the 300° floor
  above. `datarefs.py` now reads `sim/flightmodel/position/psi` instead --
  the aircraft's actual orientation, with no simulated instrument error,
  equivalent to a real gyroscopic heading indicator/DG (what pilots
  actually fly a maneuver by, and what a DPE actually grades against, not
  the wet compass). This is a pure dataref-source change -- no task logic
  moved -- so the offline test suite, which feeds heading values directly
  and never touches datarefs.py, could never have caught it; it only
  surfaced against the real simulator.
- **Slow Flight arms off a registered target airspeed (Aircraft Settings),
  not off the stall-warning horn having already sounded.** An earlier
  version required the horn to have already chirped before the graded hold
  would even start, which on some aircraft (whose horn onset AoA doesn't
  line up with a safely-controllable slow-flight speed) made the task
  borderline impossible to start at all (user-reported). A second version
  armed off 1.2 x `acf_Vso` automatically instead, but a flight school's
  actual target MCA speed can differ from any fixed multiplier of Vso, so
  this is now a **mandatory** registered value (user-requested) -- the task
  won't start at all without one, same policy as Short-Field Takeoff's
  Vx/Vy below. The horn is still tracked through the hold and noted -- as
  advisory only, since its onset is genuinely aircraft-dependent -- if it
  never sounded during an otherwise-clean hold.
- **Turns Around a Point** radius is estimated from GPS position against an
  assumed center point (offset a nominal 1/2 nm from where the turn was
  entered) -- not a real chosen ground reference. Reported as an advisory
  deviation, not a hard bust.
- **Turns Around a Point never finished in live testing** because its
  completion timeout was too short for the maneuver's own geometry, not
  because of a logic bug. Two full circles at the nominal 1/2nm radius is
  ~6.28nm of ground track, which takes 225-285s at a normal 80-100kt
  training speed alone -- but the old code reused a single 150s timeout for
  both arming the turn and completing both circles (less time than
  `holding.py` gives a single 360° circuit). Split into `ARM_TIMEOUT_S`
  (150s, unchanged) and `TURN_TIMEOUT_S` in `tasks/ground_reference.py`.
  Like the heading-dataref fix below, this only changed a timing constant,
  not task logic, so the offline test suite (which advances the required
  turn in ~60 simulated seconds) never exercised real-world timing and
  couldn't have caught it.
- **Turns Around a Point requires one circle, not two.** The Airplane Flying
  Handbook describes the training maneuver as "two or more complete
  circles," and this app originally graded that (720° of net turn). Per
  real-world DPE/flight-school feedback, though, the practical test only
  checks one circle, so completion now requires 360° (`COMPLETION_TURN_DEG`
  in `tasks/ground_reference.py`), with `TURN_TIMEOUT_S` shortened to 240s
  to match the shorter distance.
- **Emergency Descent** doesn't verify the bank angle precisely against the
  "yellow arc" (that's POH-specific and not modeled here); it hard-busts a
  real overspeed past the aircraft's actual max structural cruising speed
  (`state.vno_kt`, from `acf_Vno`) on top of its pre-existing (and
  correctly self-referential -- the ACS lets the pilot pick their own
  descent speed) entry-speed hold check.
- Every task assumes **wings-level entries** (no turning stalls) and does
  not check configuration (flaps, mixture, carb heat) beyond throttle
  position for the stall tasks.
- **Maximum Performance Takeoff is not implemented** -- it's a distinct
  ACS task from Short-Field, not built out separately (Normal, Soft-Field,
  and Short-Field takeoffs/landings, Go-Around, and Traffic Pattern all are
  -- see below and Aircraft Settings above).
- **Soft-Field Takeoff/Landing's back-elevator-pressure check is a generic
  control-input reading, not a real "weight off the nosewheel" sensor.**
  `state.yoke_pitch_ratio` (`sim/cockpit2/controls/yoke_pitch_ratio`) is
  the pilot's raw elevator input, which is a solid proxy for "are you
  holding the yoke back" but doesn't confirm the nosewheel is actually
  light on a given aircraft's specific handling characteristics. The
  check requires at least 3s of cumulative (not necessarily continuous)
  time above a modest input threshold somewhere during the roll/rollout --
  generous enough to allow the real technique of holding firmly at first
  then gradually relaxing, but it can't detect a token, barely-there tap.
- **Go-Around doesn't verify you were actually established on an approach
  first** -- it just watches for the throttle to cross a "go-around power
  applied" threshold while airborne, so it can be armed from level flight
  too, not only from a genuine descending approach configuration.
- **Traffic Pattern can't grade against a real runway** -- X-Plane exposes
  no runway-heading dataref, and the plugin navigation API's airport
  lookup (`airports.py`) only reports airport reference points, not
  individual runways. It grades a self-referenced downwind-to-final turn
  instead (same "no real ground reference" treatment as Turns Around a
  Point), holding pattern altitude/airspeed (the one number the ACS itself
  gives) and checking rollout against your own downwind heading rather
  than an actual runway centerline.
- **Ground-phase tasks are procedural, not ACS-numeric.** The FAA grades
  Preflight Procedures and Airport Operations qualitatively (correct
  checklist use, correct phraseology) -- nothing a flight-data plugin can
  verify. So:
  - **Contact Ground / Contact Tower** are multiple-choice questions (a
    scenario plus 4 phraseology options, one correct, per AIM standard
    format), not flight-data checks -- there's no dataref for "did the
    pilot say the right words" on an open mic, so this tests the knowledge
    instead of guessing at speech content. Each has 2 random variants per
    facility (`tasks/quiz.py`) so a restart doesn't always ask the same
    thing. This *does* hard-fail on a wrong answer, unlike the other
    ground-phase checkpoints.
  - **Run-Up** confirms you set elevated RPM, held it >= 10s, and brought it
    back to idle, and flags if oil pressure dipped below 10 psi during the
    hold. It does **not** check magneto drop/split or carb-heat RPM drop --
    there's no reliable generic dataref for magneto switch position across
    aircraft -- so keep doing those checks yourself.
  - **Taxi** only reports max taxi speed as an advisory note; the ACS sets
    no hard numeric taxi-speed limit.
- The airborne tasks now require `not state.on_ground` (or similar) to arm,
  fixing a real bug: previously, if you loaded a saved situation sitting at
  the gate with the engine off, Straight-and-Level's arm condition
  (`|VS| < 150fpm and |bank| < 10deg`) was trivially true while parked, and
  it would silently start (and pass) a 30-second hold with the plane not
  moving at all.
- **Practice Mode's location picker is a list, not a visual map.** X-Plane's
  plugin map API (`XPLMMap`) can draw markers/labels on X-Plane's own map
  but has no way to report a click back to a plugin, so there's no way to
  tap a point and get a lat/lon from it -- `airports.py` lists nearby
  airports (from the loaded nav database) sorted by distance instead.
- **Practice Mode's pitch slider sets a one-time attitude/velocity
  component on teleport, not trim.** The aircraft isn't held at that pitch
  afterward, so on a pitched-up/down start it may drift back toward level
  on its own before you take control.
- **The reposition is a hard cut for the flight model**, not a smooth
  transition -- a sudden position/velocity/attitude change on any of these
  teleports (default or custom) can occasionally produce a rough first
  physics frame.
- **IR tasks are VOR/localizer/glideslope (NAV1) only** -- no GPS/RNAV
  course tracking, vertical guidance, or DME arcs.
- **CDI/glideslope full-scale is assumed to be +/-2.0 dots**
  (`nav1_hdef_dots_pilot` / `nav1_vdef_dots_pilot`), the standard CDI/HSI
  convention -- this wasn't confirmed against a live gauge in the sim, so
  if IR grading looks off, check this first (`datarefs.py`).
- **Neither approach task knows the real published procedure** (FAF, MDA,
  DA, missed approach track) -- they infer the "final segment" from your
  flight profile instead (a sustained descent for the NPA, glideslope
  capture for the ILS -- see `tasks/approaches.py` for the exact
  heuristics), and Missed Approach just grades holding a heading/airspeed
  after a go-around, not compliance with the specific published track.
- **Circling Approach and Landing from an Instrument Approach are not
  implemented** -- both need runway/ground-proximity data this build
  doesn't read yet, same as PPL's takeoffs/landings.
- The Instrument Rating syllabus doesn't include Preflight Preparation,
  Preflight Procedures, Departure/En Route/Arrival Operations, or any of
  Area VII (Emergency Operations: loss of comms, engine-out for AMEL/AMES,
  partial panel) -- v1 covers the ATC/navigation/approach core only.
- **Chandelle grading approximates "just above stall" as the stall warning
  having sounded for >= 1s at some point before rollout, then cleared** --
  same AoA-vs-stall-warning approximation the wings-level stall tasks use,
  applied to a climbing turn instead.
- **Chandelle and Accelerated Stall don't grade bank angle** (~30° and 45°
  respectively) -- the ACS gives no numeric tolerance for either, so only
  what *is* numeric (rollout heading for Chandelle; the AGL floor and a
  prompt recovery for Accelerated Stall) is graded.
- **Lazy Eight and Holding are both simplified to one repetition** (one
  180° half for Lazy Eight, one 360° circuit for Holding) rather than the
  multiple "symmetrical loops" / full pattern a real examiner might ask for.
- **Steep Spiral and Eights on Pylons are not implemented.** Both need a
  ground-reference-point estimate (like PPL's Turns Around a Point, itself
  already an approximation), and Eights on Pylons has no numeric altitude/
  airspeed tolerance in the ACS at all -- it's graded purely by how well
  you visually hold the pylon via pivotal altitude, which isn't something
  flight data alone can verify.
- **Commercial's Power-Off 180 Accuracy Approach and Landing is not
  implemented** -- same reason as PPL's takeoffs/landings (needs runway/
  touchdown-point proximity data this build doesn't read).
- The Commercial syllabus doesn't include Preflight Preparation/Procedures,
  Airport Operations, Navigation, High-Altitude Operations, most of
  Emergency Operations (only Emergency Descent is covered), or any
  Multiengine Operations task -- v1 covers the performance-maneuver and
  slow-flight/stall core only.
- **Which engine is "left" vs "right" is assumed from index order**
  (`throttle_ratio` = engine 1 = left, `throttle2_ratio` = engine 2 =
  right) -- true for a conventional twin, not for a centerline-thrust
  design (where "bank toward the operating engine" in VMC Demonstration
  wouldn't even apply the same way).
- **VMC Demonstration doesn't grade the ~1kt/sec airspeed-reduction rate.**
  Its recovery airspeed check IS hard-graded against a real number, though:
  the registered `vmc_recovery_kt` Aircraft Setting (e.g. Vyse) --
  **mandatory**, same policy as Short-Field Takeoff's Vx/Vy, since X-Plane
  has no Vsse/Vyse dataref and the real POH number can vary by flight
  school. An earlier version compared against whatever airspeed was
  captured the instant recovery began instead, which never actually
  verified compliance with a real target and was always advisory-only.
- **Engine Failure During Takeoff Before VMC is not implemented** (a
  takeoff-roll task -- same reason as every other takeoff/landing task),
  nor is **Instrument Approach and Landing with an Inoperative Engine**
  (Commercial-only; needs both real approach-procedure awareness like the
  IR tasks already approximate, and landing data neither rating has yet).
- **"Maneuvering with One Engine Inoperative" covers both the ACS's visual
  and instrument/hood-on task codes** (X.A and X.C) since they share
  identical numeric tolerances and this build can't detect hood use.
- **Short-Field Takeoff/Landing's touchdown-distance standard (200ft for
  Private, 100ft for Commercial) is not graded**, for the same reason as
  the helicopter autorotation/approach tasks below: there's no way for the
  plugin to know which specific point on the runway the pilot aimed for.
- **Short-Field Takeoff's climb-speed check (Vx/Vy) requires the aircraft's
  real numbers to be registered in Settings -- the task won't start at all
  otherwise.** The ACS names specific speeds here, but unlike Vso,
  X-Plane has no dataref anywhere for Vx/Vy (confirmed against this
  machine's DataRefs.txt -- only Vso/Vs/Vfe/Vno/Vne exist, all
  structural/stall limits, not climb-performance speeds), and the real
  numbers can vary by flight school on top of that. An earlier version
  fell back to capturing "whatever speed you were flying at liftoff/50ft
  AGL" as a stand-in target when unregistered, downgraded to an
  advisory-only note -- but that never actually verified Vx/Vy compliance,
  only that a speed was held steady, so this is now a hard requirement
  instead (user-requested; `Task.blocking_reason()` shows a "SETTINGS
  REQUIRED" banner with an Open Settings shortcut right on the task
  screen). Once registered, this is a real, hard-graded ±10/-5kt (Private)
  or ±5kt (Commercial) check. Flap configuration/timing
  (`state.flap_ratio`) and directional control are hard-graded either way.
- **Short-Field Approach and Landing's approach-speed check IS a real,
  hard-graded number even without any Settings entry**: 1.3 x the
  aircraft's actual stall speed (`state.vso_kt`, from
  `sim/aircraft/view/acf_Vso`, its own Plane Maker performance data),
  matching the ACS's own fallback formula exactly. A registered published
  approach speed (Settings) takes priority over that formula, per the ACS.
  If an aircraft doesn't report Vso (reads 0) and nothing is registered,
  this falls back to the same self-referential/advisory-only treatment as
  the takeoff task's climb speed. Full flaps by touchdown is still graded
  via `state.flap_ratio` regardless.
- **Holding the yoke/elevator full aft is a Soft-Field technique, not
  Short-Field.** The ACS's Short-Field Takeoff and Landing skills don't
  actually call for sustained back-pressure (that's the Soft-Field tasks,
  neither of which is implemented) -- so these tasks only check flap
  timing/configuration, not control-column input.
- **Helicopter main rotor RPM's "normal" tolerance (±10%) is this plugin's
  own heuristic, not an ACS number.** The ACS just says "main rotor (Nr)
  within normal limits" -- the actual normal range is entirely POH/type
  specific (a Robinson R22's is nothing like a Bell 206's), so tasks
  capture whatever RPM was reading right before the simulated engine chop
  and grade relative to that.
- **Autorotation's "terminate within 200 ft of a designated point" is not
  graded at all.** There's no way for the plugin to know which point on the
  ground the pilot picked as their landing spot, and estimating one (the
  way `ground_reference.py` does for Turns Around a Point) would be
  actively misleading for a maneuver whose entire purpose is precision
  landing at a chosen spot. Self-assess your touchdown accuracy.
- **"Arrive within 4 ft of the termination point"** (Vertical Takeoff and
  Landing's landing phase, Normal/Steep Approach) is graded the same way:
  as "came to a genuinely stable stop, not still drifting" within a small
  radius of wherever the helicopter first slowed down and got low, rather
  than a distance from a point only the pilot actually intended.
- **Reposition-to-hover in Practice Mode can show an unrealistic rotor RPM
  number.** `reposition.py`'s force-start writes the same generic
  `engine_rpm` (default 2300, sized for a fixed-wing direct-drive
  propeller) to both the engine and the "point"/rotor shaft. A helicopter's
  actual main rotor runs far slower (geared down, typically 300-500 RPM
  depending on type), so 2300 is obviously wrong at a glance -- but since
  autorotation grading is relative to whatever RPM was captured right
  before the chop (not that absolute number), this doesn't affect grading,
  only the on-screen number's realism.
- **PPL/Helicopter has no ground-phase tasks besides rotor engagement** --
  no taxi/ATC-quiz equivalent yet, unlike the airplane ratings.
- **Settings' speed sliders cap out at 120kt (160kt for VMC recovery
  speed)**, sized for typical trainers -- a turboprop or other faster
  aircraft's real numbers may not fit. The sliders are also imprecise for
  typing an exact POH figure; nothing currently stops you from entering an
  approximate value.
- **The Slow Flight target slider suggests 1.2 x the aircraft's last-seen
  Vso as a starting point when unregistered**, purely as a convenience so
  the slider isn't a bare 0 -- it's just a suggestion, not validated
  against anything, and still has to be explicitly saved to actually
  register (an unsaved suggestion still blocks the task).
- **Aircraft settings are keyed by `.acf` file name only, not full path.**
  Two different add-ons that happen to share an identical file name (not
  something you'd expect, but possible) would collide and share settings.
  The full path is available (`xp.getNthAircraftModel(0)`) but deliberately
  not used as the key, so the same add-on is still recognized after moving
  its folder.
- **[Partially fixed] License activation is a local checksum against a
  secret embedded in plain Python source (`license.py`), not server-side
  key validation.** Still true, and still stops a mistyped/guessed key
  from validating, not someone willing to open the file and read the
  secret; there's also no expiry or revocation once a key is activated.
  What *is* now server-backed: which *device* a given key is allowed to
  run on -- `activation.py` calls a small hosted server once at Activate
  time to enforce one license per device (see License activation above
  and `/server/README.md`), closing the "1台に1ライセンス" gap a purely
  local checksum could never close by itself. This does not extend to
  forged keys (the server can't tell a forged key from a real one) or to
  copying the whole `license.json` file rather than just the key text --
  both remain open, deliberately, so the plugin still works fully offline
  day-to-day and only the initial activation needs a network connection.
  `tools/generate_license_key.py` (which mints new keys) is a
  developer-only script, kept out of the customer-facing zip by
  `package.sh`.

## Next steps (not started)

- Maximum Performance Takeoff (Normal, Soft-Field, Short-Field
  takeoffs/landings, Go-Around, and Traffic Pattern are now implemented --
  see Aircraft Settings above and Known limitations)
- A way to grade Short-Field/autorotation touchdown-distance standards
  properly: let the pilot pick a real target point (e.g. from the same
  nearby-airport list Practice Mode's location picker already has) before
  the task starts, rather than leaving that part self-assessed
- IR: Circling Approach, Landing from an Instrument Approach, GPS/RNAV
  approaches, Departure/En Route/Arrival Operations, Loss of Communications
- CPL: Steep Spiral, Eights on Pylons, Power-Off 180 Accuracy Approach and
  Landing
- AMEL: Engine Failure During Takeoff Before VMC, Instrument Approach and
  Landing with an Inoperative Engine (Commercial only)
- PPL/Helicopter: Slope Operations, Confined Area Operations, Pinnacle
  Operations (mostly site-selection/reconnaissance judgment, not numeric
  standards), Go-Around, Maximum Performance Takeoff, all of Area VIII
  (Vortex Ring State, Low Rotor RPM Recognition, Antitorque System Failure,
  Dynamic Rollover, Ground Resonance -- unsafe to provoke via a teleport/
  setup screen and graded on recognition/recovery judgment anyway), ground
  ops beyond rotor engagement, Commercial Pilot - Helicopter (FAA-S-ACS-16),
  Instrument Rating - Helicopter
- CFI task set -- will need to lean mostly on the MultipleChoiceTask/quiz
  pattern, since a practical test built around teaching ability isn't
  something flight data can grade the way a maneuver's tolerances can
- Bind pilot-facing "ready" signal via a real cockpit command instead of
  auto-arming heuristics, for tasks where auto-detection is unreliable
- A real visual map for the location picker (would need drawing aerial/
  chart tiles inside the ImGui window, or an X-Plane version that adds
  click-through map API for plugins)
- More Settings fields (e.g. the actual recommended short-field takeoff
  flap setting, not just the timing of when it's raised)
- Replace the Settings sliders with real numeric text entry (ImGui
  `input_float`) so an exact POH figure can be typed rather than dragged,
  and so aircraft faster than the current 120kt slider cap are supported
