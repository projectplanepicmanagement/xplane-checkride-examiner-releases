"""XPPython3 entry point for the PPL/ASEL Checkride Examiner plugin.

Acts as a virtual DPE: calls out one FAA ACS task at a time, waits for the
pilot to fly it, and grades the result against the numeric ACS tolerances
implemented in checkride_examiner/tasks/. Two modes (see
checkride_examiner/controller.py): the full ordered Checkride Mode (score
hidden until the end), and Practice Mode (pick one task, immediate
feedback, retry freely -- airborne tasks reposition you into the air).

Discoverable controls live under Plugins > Checkride Examiner in X-Plane's
menu bar, and the same actions are also available as buttons directly in
the overlay window. For a key/joystick binding instead, X-Plane > Settings
> Keyboard exposes the underlying commands:
  checkride/examiner/skip_task        -- give up on / skip the current task
  checkride/examiner/restart          -- restart the whole session from Task 1
  checkride/examiner/ready            -- mark ready for the next task, once
                                          you've had a moment to get set up
                                          (Checkride Mode only -- see
                                          ExaminerSession.is_waiting_for_ready)
  checkride/examiner/answer_a .. _d   -- answer a multiple-choice question
                                          (e.g. an ATC radio call quiz)
"""
import os

from XPPython3 import xp

from checkride_examiner.aircraft_settings import AircraftSettingsStore
from checkride_examiner.controller import AppController, MODE_CHECKRIDE, MODE_PRACTICE
from checkride_examiner.datarefs import DataRefReader
from checkride_examiner.license import LicenseStore
from checkride_examiner.overlay import ExaminerOverlay
from checkride_examiner.reposition import Repositioner
from checkride_examiner.updater import UpdateChecker
from checkride_examiner._version import PLUGIN_VERSION
from checkride_examiner.weather import WeatherController

SETTINGS_FILE_NAME = "Checkride Examiner Aircraft Settings.json"
LICENSE_FILE_NAME = "Checkride Examiner License.json"

FLIGHT_LOOP_INTERVAL_S = -1.0  # run every sim frame


class PythonInterface:
    def XPluginStart(self):
        self.Name = "Checkride Examiner (PPL/ASEL)"
        self.Sig = "checkrideexaminer.tools.local"
        self.Desc = "Virtual DPE: calls out ACS tasks and grades your flying against FAA ACS tolerances."

        self.reader = None
        self.repositioner = None
        self.weather_controller = None
        self.update_checker = None
        self.controller = None
        self.overlay = None

        self.skip_cmd = xp.createCommand("checkride/examiner/skip_task", "Skip current checkride task")
        self.restart_cmd = xp.createCommand("checkride/examiner/restart", "Restart checkride session")
        self.ready_cmd = xp.createCommand("checkride/examiner/ready", "Mark ready for the next checkride task")
        xp.registerCommandHandler(self.skip_cmd, self._on_skip, 1, None)
        xp.registerCommandHandler(self.restart_cmd, self._on_restart, 1, None)
        xp.registerCommandHandler(self.ready_cmd, self._on_ready, 1, None)

        self.answer_cmds = []  # list of (commandRef, handler) so XPluginStop can unregister them
        for i, letter in enumerate("abcd"):
            cmd = xp.createCommand(f"checkride/examiner/answer_{letter}", f"Answer option {letter.upper()} on a checkride quiz question")
            handler = self._make_answer_handler(i)
            xp.registerCommandHandler(cmd, handler, 1, None)
            self.answer_cmds.append((cmd, handler))

        self._menu_container = xp.appendMenuItem(xp.findPluginsMenu(), "Checkride Examiner", None)
        self.menu = xp.createMenu("Checkride Examiner", xp.findPluginsMenu(), self._menu_container, self._on_menu, None)
        xp.appendMenuItem(self.menu, "Show/Hide Window", "toggle")
        xp.appendMenuItem(self.menu, "Skip Current Task", "skip")
        xp.appendMenuItem(self.menu, "Ready for Next Task", "ready")
        xp.appendMenuItem(self.menu, "Restart Session", "restart")
        xp.appendMenuItem(self.menu, "Switch to Checkride Mode", "mode_checkride")
        xp.appendMenuItem(self.menu, "Switch to Practice Mode", "mode_practice")

        return self.Name, self.Sig, self.Desc

    def XPluginEnable(self):
        self.reader = DataRefReader()
        self.repositioner = Repositioner()
        self.weather_controller = WeatherController()
        # __file__ is PythonPlugins/PI_CheckrideExaminer.py itself, so its
        # dirname is the PythonPlugins folder -- the parent of
        # checkride_examiner/ that updater.py needs to know where to
        # replace files (see updater.py's own docstring).
        plugins_root = os.path.dirname(os.path.abspath(__file__))
        self.update_checker = UpdateChecker(plugins_root, PLUGIN_VERSION)
        settings_store = self._make_settings_store()
        license_store = self._make_license_store()
        self.controller = AppController(
            self.repositioner, settings_store, license_store, self.weather_controller, self.update_checker,
        )
        self.overlay = ExaminerOverlay(self.controller)
        xp.registerFlightLoopCallback(self._on_flight_loop, FLIGHT_LOOP_INTERVAL_S, None)
        return 1

    def XPluginDisable(self):
        xp.unregisterFlightLoopCallback(self._on_flight_loop, None)
        if self.overlay is not None:
            self.overlay.destroy()
            self.overlay = None

    def XPluginStop(self):
        xp.unregisterCommandHandler(self.skip_cmd, self._on_skip, 1, None)
        xp.unregisterCommandHandler(self.restart_cmd, self._on_restart, 1, None)
        xp.unregisterCommandHandler(self.ready_cmd, self._on_ready, 1, None)
        for cmd, handler in self.answer_cmds:
            xp.unregisterCommandHandler(cmd, handler, 1, None)
        xp.destroyMenu(self.menu)

    def XPluginReceiveMessage(self, inFromWho, inMessage, inParam):
        pass

    def _make_settings_store(self):
        """X-Plane's preferences folder (not the plugin's own folder,
        which INSTALL.txt has users overwrite wholesale on every update)."""
        try:
            prefs_dir = os.path.dirname(xp.getPrefsPath())
            return AircraftSettingsStore(os.path.join(prefs_dir, SETTINGS_FILE_NAME))
        except Exception as exc:  # pragma: no cover - defensive; settings just won't persist
            xp.log(f"[CheckrideExaminer] could not resolve a settings file path, aircraft settings won't be saved: {exc!r}")
            return AircraftSettingsStore(None)

    def _make_license_store(self):
        """Same preferences folder as _make_settings_store(), so activation
        survives a plugin update the same way as the aircraft settings do."""
        try:
            prefs_dir = os.path.dirname(xp.getPrefsPath())
            return LicenseStore(os.path.join(prefs_dir, LICENSE_FILE_NAME))
        except Exception as exc:  # pragma: no cover - defensive; activation just won't persist
            xp.log(f"[CheckrideExaminer] could not resolve a license file path, activation won't be saved: {exc!r}")
            return LicenseStore(None)

    def _on_flight_loop(self, elapsedMe, elapsedSim, counter, refCon):
        state = self.reader.snapshot(xp.getElapsedTime())
        self.controller.tick(state)
        return FLIGHT_LOOP_INTERVAL_S

    def _on_skip(self, commandRef, phase, refCon):
        if phase == xp.CommandBegin:
            self.controller.skip_current()
        return 0

    def _on_restart(self, commandRef, phase, refCon):
        if phase == xp.CommandBegin:
            self.controller.restart()
        return 0

    def _on_ready(self, commandRef, phase, refCon):
        if phase == xp.CommandBegin:
            self.controller.mark_ready()
        return 0

    def _make_answer_handler(self, index):
        def handler(commandRef, phase, refCon):
            if phase == xp.CommandBegin:
                self.controller.submit_answer(index)
            return 0
        return handler

    def _on_menu(self, menuRef, itemRef):
        if itemRef == "toggle":
            self.overlay.toggle_visible()
        elif itemRef == "skip":
            self.controller.skip_current()
        elif itemRef == "ready":
            self.controller.mark_ready()
        elif itemRef == "restart":
            self.controller.restart()
        elif itemRef == "mode_checkride":
            self.controller.set_mode(MODE_CHECKRIDE)
        elif itemRef == "mode_practice":
            self.controller.set_mode(MODE_PRACTICE)
