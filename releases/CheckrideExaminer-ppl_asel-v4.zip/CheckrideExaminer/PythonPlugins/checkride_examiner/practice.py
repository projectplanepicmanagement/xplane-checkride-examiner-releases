"""Practice mode: pick a single task from the catalog, get immediate
pass/fail feedback, and retry as many times as you like. Unlike the full
checkride session (`sequence.ExaminerSession`), nothing here is ordered,
hidden, or one-shot.

Airborne tasks are repositioned into the air first (see `reposition.py`) so
practicing, say, steep turns doesn't require climbing out from the ramp
every time. Ground tasks (ATC quiz, taxi, run-up) are practiced in place --
repositioning to a runway/ramp reliably isn't implemented, so if you're
airborne when you pick one it just runs from wherever you are.

`PracticeSession` also imposes a short `SETTLE_S` pause after an airborne
reposition before the task's `update()` is called at all -- the teleport
itself can leave the flight model momentarily unsettled, and since the
catalog's default start conditions are deliberately chosen to already
satisfy most tasks' arm conditions, without this pause that settling
transient was getting graded as if it were the first moment of the
maneuver itself.
"""
from dataclasses import dataclass
from typing import Callable, List, Optional, Tuple

from .grading import TaskResult
from .state import FlightState
from .tasks.accelerated_stall import AcceleratedStallTask
from .tasks.approaches import NonprecisionApproachTask, PrecisionApproachTask
from .tasks.base import Task
from .tasks.basic_instrument import (
    ConstantAirspeedClimbTask,
    ConstantAirspeedDescentTask,
    StraightAndLevelTask,
    TurnsToHeadingTask,
)
from .tasks.chandelle import ChandelleTask
from .tasks.emergency_descent import EmergencyDescentTask
from .tasks.go_around import GoAroundTask
from .tasks.ground_ops import RunUpTask, TaxiTask
from .tasks.ground_reference import TurnsAroundAPointTask
from .tasks.heli_hovering import HoverTaxiTask, RotorEngagementTask, VerticalTakeoffLandingTask
from .tasks.heli_performance import AutorotationTask, RapidDecelerationTask
from .tasks.heli_takeoff_landing import NormalApproachTask, NormalTakeoffClimbTask, SteepApproachTask
from .tasks.holding import HoldingTask
from .tasks.lazy_eight import LazyEightTask
from .tasks.missed_approach import MissedApproachTask
from .tasks.multiengine import EngineFailureAfterLiftoffTask, ManeuveringOneEngineInoperativeTask
from .tasks.nav_tracking import NavTrackingTask
from .tasks.normal_landing import NormalLandingTask, NormalTakeoffTask
from .tasks.short_field import ShortFieldApproachLandingTask, ShortFieldTakeoffTask
from .tasks.soft_field import SoftFieldLandingTask, SoftFieldTakeoffTask
from .tasks.traffic_pattern import TrafficPatternTask
from .tasks.quiz import (
    random_clearance_question_task,
    random_ground_question_task,
    random_tower_question_task,
)
from .tasks.slow_flight import CommercialSlowFlightTask, SlowFlightTask
from .tasks.stalls import (
    CommercialPowerOffStallTask,
    CommercialPowerOnStallTask,
    PowerOffStallTask,
    PowerOnStallTask,
)
from .tasks.steep_turns import SteepTurnTask
from .tasks.vmc_demo import VmcDemonstrationTask


# A hard teleport (reposition_airborne) can leave the flight model
# unsettled for a frame or few -- a brief attitude/velocity transient as
# X-Plane's physics reconciles the instant position/velocity change. Tasks
# often arm immediately after an airborne reposition (the catalog's
# defaults are deliberately chosen to already satisfy most tasks' arm
# conditions), so without this pause, that transient itself was getting
# swept into the very first moment of grading -- the "distance travelled by
# the teleport" effectively counted as part of the maneuver. Simply not
# calling task.update() at all during this window (rather than, say,
# special-casing it inside every task) keeps every task's own clock from
# starting until the aircraft has actually settled.
SETTLE_S = 1.0


@dataclass
class PracticeEntry:
    key: str
    label: str
    factory: Callable[[], Task]
    airborne_agl_ft: Optional[float]  # None => ground task, never repositioned
    airborne_ias_kt: float = 90.0
    ratings: Tuple[str, ...] = ("ppl_asel",)  # which rating filters show this entry


# PPL/ASEL's 15 tasks also show up under "ppl_amel" -- a real AMEL checkride
# in a twin covers all of these plus the 3 multiengine-only tasks below.
_PPL_ASEL = ("ppl_asel", "ppl_amel")
_CPL = ("cpl", "cpl_amel")

PRACTICE_CATALOG: List[PracticeEntry] = [
    # --- PPL / ASEL (also shown under PPL / AMEL) ---
    PracticeEntry("radio_ground", "Contact Ground (ATC quiz)", random_ground_question_task, None, ratings=_PPL_ASEL),
    PracticeEntry("taxi", "Taxi", TaxiTask, None, ratings=_PPL_ASEL),
    PracticeEntry("runup", "Before-Takeoff Run-Up", RunUpTask, None, ratings=_PPL_ASEL),
    PracticeEntry("radio_tower", "Contact Tower (ATC quiz)", random_tower_question_task, None, ratings=_PPL_ASEL),
    PracticeEntry("short_field_takeoff", "Short-Field Takeoff and Maximum Performance Climb", ShortFieldTakeoffTask, None, ratings=_PPL_ASEL),
    PracticeEntry("straight_level", "Straight-and-Level Flight", StraightAndLevelTask, 3000.0, 100.0, ratings=_PPL_ASEL),
    PracticeEntry("climb", "Constant Airspeed Climb", ConstantAirspeedClimbTask, 3000.0, 90.0, ratings=_PPL_ASEL),
    PracticeEntry("descent", "Constant Airspeed Descent", ConstantAirspeedDescentTask, 4500.0, 100.0, ratings=_PPL_ASEL),
    PracticeEntry("turns_heading", "Turns to Headings", TurnsToHeadingTask, 3000.0, 100.0, ratings=_PPL_ASEL),
    PracticeEntry("steep_left", "Steep Turn (Left, 45deg)", lambda: SteepTurnTask("left"), 4000.0, 100.0, ratings=_PPL_ASEL),
    PracticeEntry("steep_right", "Steep Turn (Right, 45deg)", lambda: SteepTurnTask("right"), 4000.0, 100.0, ratings=_PPL_ASEL),
    PracticeEntry("slow_flight", "Maneuvering During Slow Flight", SlowFlightTask, 3000.0, 90.0, ratings=_PPL_ASEL),
    PracticeEntry("power_off_stall", "Power-Off Stall", PowerOffStallTask, 3500.0, 90.0, ratings=_PPL_ASEL),
    PracticeEntry("power_on_stall", "Power-On Stall", PowerOnStallTask, 3500.0, 90.0, ratings=_PPL_ASEL),
    PracticeEntry("turns_around_point", "Turns Around a Point", TurnsAroundAPointTask, 900.0, 90.0, ratings=_PPL_ASEL),
    PracticeEntry("emergency_descent", "Emergency Descent", EmergencyDescentTask, 4500.0, 100.0, ratings=_PPL_ASEL),
    PracticeEntry("traffic_pattern", "Traffic Pattern", TrafficPatternTask, 1000.0, 90.0, ratings=_PPL_ASEL),
    PracticeEntry("go_around", "Go-Around/Rejected Landing", GoAroundTask, 1000.0, 70.0, ratings=_PPL_ASEL),
    PracticeEntry("normal_landing", "Normal Approach and Landing", NormalLandingTask, 1000.0, 70.0, ratings=_PPL_ASEL),
    PracticeEntry("normal_takeoff", "Normal Takeoff and Climb", NormalTakeoffTask, None, ratings=_PPL_ASEL),
    PracticeEntry("soft_field_landing", "Soft-Field Approach and Landing", SoftFieldLandingTask, 1000.0, 70.0, ratings=_PPL_ASEL),
    PracticeEntry("soft_field_takeoff", "Soft-Field Takeoff and Climb", SoftFieldTakeoffTask, None, ratings=_PPL_ASEL),
    PracticeEntry("short_field_landing", "Short-Field Approach and Landing", ShortFieldApproachLandingTask, 1000.0, 70.0, ratings=_PPL_ASEL),

    # --- Instrument Rating ---
    PracticeEntry("ir_clearance", "Compliance with ATC Clearances (quiz)", random_clearance_question_task, None, ratings=("ir",)),
    PracticeEntry("nav_tracking", "Intercepting and Tracking a Nav Course", NavTrackingTask, 4000.0, 110.0, ratings=("ir",)),
    PracticeEntry("holding", "Holding Procedure", HoldingTask, 4000.0, 110.0, ratings=("ir",)),
    PracticeEntry("nonprecision_approach", "Non-precision Approach", NonprecisionApproachTask, 4000.0, 100.0, ratings=("ir",)),
    PracticeEntry("precision_approach", "Precision Approach (ILS)", PrecisionApproachTask, 4000.0, 110.0, ratings=("ir",)),
    PracticeEntry("missed_approach", "Missed Approach", MissedApproachTask, 2500.0, 90.0, ratings=("ir",)),

    # --- Commercial Pilot (also shown under Commercial Pilot / AMEL) ---
    PracticeEntry("cpl_short_field_takeoff", "Short-Field Takeoff and Maximum Performance Climb (Commercial)", lambda: ShortFieldTakeoffTask(acs_ref="CA.IV.E", tolerance_low=-5.0, tolerance_high=5.0), None, ratings=_CPL),
    PracticeEntry("cpl_steep_left", "Steep Turn (Left, 50deg)", lambda: SteepTurnTask("left", target_bank=50.0, acs_ref="CA.V.A"), 4000.0, 100.0, ratings=_CPL),
    PracticeEntry("cpl_steep_right", "Steep Turn (Right, 50deg)", lambda: SteepTurnTask("right", target_bank=50.0, acs_ref="CA.V.A"), 4000.0, 100.0, ratings=_CPL),
    PracticeEntry("chandelle_left", "Chandelle (Left)", lambda: ChandelleTask("left"), 3500.0, 100.0, ratings=_CPL),
    PracticeEntry("chandelle_right", "Chandelle (Right)", lambda: ChandelleTask("right"), 3500.0, 100.0, ratings=_CPL),
    PracticeEntry("lazy_eight_left", "Lazy Eight (Left)", lambda: LazyEightTask("left"), 3500.0, 100.0, ratings=_CPL),
    PracticeEntry("lazy_eight_right", "Lazy Eight (Right)", lambda: LazyEightTask("right"), 3500.0, 100.0, ratings=_CPL),
    PracticeEntry("commercial_slow_flight", "Maneuvering During Slow Flight (Commercial)", CommercialSlowFlightTask, 3000.0, 90.0, ratings=_CPL),
    PracticeEntry("commercial_power_off_stall", "Power-Off Stall (Commercial)", CommercialPowerOffStallTask, 3500.0, 90.0, ratings=_CPL),
    PracticeEntry("commercial_power_on_stall", "Power-On Stall (Commercial)", CommercialPowerOnStallTask, 3500.0, 90.0, ratings=_CPL),
    PracticeEntry("accelerated_stall", "Accelerated Stall", lambda: AcceleratedStallTask("left"), 4000.0, 100.0, ratings=_CPL),
    PracticeEntry("cpl_emergency_descent", "Emergency Descent (Commercial)", lambda: EmergencyDescentTask(acs_ref="CA.IX.A", bank_required=True), 4500.0, 100.0, ratings=_CPL),
    PracticeEntry("cpl_traffic_pattern", "Traffic Pattern (Commercial)", lambda: TrafficPatternTask(acs_ref="CA.III.B"), 1000.0, 90.0, ratings=_CPL),
    PracticeEntry("cpl_go_around", "Go-Around/Rejected Landing (Commercial)", lambda: GoAroundTask(acs_ref="CA.IV.N", tolerance_low=-5.0, tolerance_high=5.0), 1000.0, 70.0, ratings=_CPL),
    PracticeEntry("cpl_normal_landing", "Normal Approach and Landing (Commercial)", lambda: NormalLandingTask(acs_ref="CA.IV.B", tolerance_low=-5.0, tolerance_high=5.0, touchdown_distance_ft=200.0), 1000.0, 70.0, ratings=_CPL),
    PracticeEntry("cpl_normal_takeoff", "Normal Takeoff and Climb (Commercial)", lambda: NormalTakeoffTask(acs_ref="CA.IV.A", tolerance_low=-5.0, tolerance_high=5.0), None, ratings=_CPL),
    PracticeEntry("cpl_soft_field_landing", "Soft-Field Approach and Landing (Commercial)", lambda: SoftFieldLandingTask(acs_ref="CA.IV.D", tolerance_low=-5.0, tolerance_high=5.0), 1000.0, 70.0, ratings=_CPL),
    PracticeEntry("cpl_soft_field_takeoff", "Soft-Field Takeoff and Climb (Commercial)", lambda: SoftFieldTakeoffTask(acs_ref="CA.IV.C", tolerance_low=-5.0, tolerance_high=5.0), None, ratings=_CPL),
    PracticeEntry("cpl_short_field_landing", "Short-Field Approach and Landing (Commercial)", lambda: ShortFieldApproachLandingTask(acs_ref="CA.IV.F", tolerance_low=-5.0, tolerance_high=5.0, touchdown_distance_ft=100.0), 1000.0, 70.0, ratings=_CPL),

    # --- AMEL: Private-flavored (PPL/AMEL) and Commercial-flavored (Commercial Pilot/AMEL) ---
    PracticeEntry("ppl_engine_failure_after_liftoff", "Engine Failure After Liftoff", lambda: EngineFailureAfterLiftoffTask(acs_ref="PA.IX.F"), 3000.0, 100.0, ratings=("ppl_amel",)),
    PracticeEntry("ppl_maneuvering_one_engine_inop", "Maneuvering with One Engine Inoperative", lambda: ManeuveringOneEngineInoperativeTask(acs_ref="PA.X.A / PA.X.C"), 4000.0, 100.0, ratings=("ppl_amel",)),
    PracticeEntry("ppl_vmc_demo", "VMC Demonstration", lambda: VmcDemonstrationTask(acs_ref="PA.X.B", recovery_low=-5.0, recovery_high=10.0), 4500.0, 100.0, ratings=("ppl_amel",)),
    PracticeEntry("cpl_engine_failure_after_liftoff", "Engine Failure After Liftoff", lambda: EngineFailureAfterLiftoffTask(acs_ref="CA.IX.F"), 3000.0, 100.0, ratings=("cpl_amel",)),
    PracticeEntry("cpl_maneuvering_one_engine_inop", "Maneuvering with One Engine Inoperative", lambda: ManeuveringOneEngineInoperativeTask(acs_ref="CA.X.A / CA.X.C"), 4000.0, 100.0, ratings=("cpl_amel",)),
    PracticeEntry("cpl_vmc_demo", "VMC Demonstration", lambda: VmcDemonstrationTask(acs_ref="CA.X.B", recovery_low=-5.0, recovery_high=5.0), 4500.0, 100.0, ratings=("cpl_amel",)),

    # --- PPL / Helicopter ---
    PracticeEntry("heli_rotor_engagement", "Powerplant Starting and Rotor Engagement", RotorEngagementTask, None, ratings=("ppl_helicopter",)),
    PracticeEntry("heli_vertical_takeoff_landing", "Vertical Takeoff and Landing", VerticalTakeoffLandingTask, 5.0, 0.0, ratings=("ppl_helicopter",)),
    PracticeEntry("heli_hover_taxi", "Hover Taxi", HoverTaxiTask, 5.0, 5.0, ratings=("ppl_helicopter",)),
    PracticeEntry("heli_normal_takeoff_climb", "Normal Takeoff and Climb", NormalTakeoffClimbTask, 50.0, 40.0, ratings=("ppl_helicopter",)),
    PracticeEntry("heli_normal_approach", "Normal and Crosswind Approach", NormalApproachTask, 300.0, 50.0, ratings=("ppl_helicopter",)),
    PracticeEntry("heli_steep_approach", "Steep Approach", SteepApproachTask, 300.0, 50.0, ratings=("ppl_helicopter",)),
    PracticeEntry("heli_quick_stop", "Rapid Deceleration / Quick Stop", RapidDecelerationTask, 50.0, 40.0, ratings=("ppl_helicopter",)),
    PracticeEntry("heli_autorotation", "Straight-In Autorotation", lambda: AutorotationTask(require_turn=False, acs_ref="PH.VI.B"), 1000.0, 60.0, ratings=("ppl_helicopter",)),
    PracticeEntry("heli_autorotation_turns", "Autorotation with Turns", lambda: AutorotationTask(require_turn=True, acs_ref="PH.VI.C"), 1500.0, 60.0, ratings=("ppl_helicopter",)),
]


class PracticeSession:
    def __init__(self, repositioner=None):
        self._repositioner = repositioner
        self.entry: Optional[PracticeEntry] = None
        self.task: Optional[Task] = None
        self.last_result: Optional[TaskResult] = None
        self._last_t: Optional[float] = None
        self._last_overrides: dict = {}
        self._settle_remaining_s: float = 0.0

    @property
    def active(self) -> bool:
        return self.task is not None

    def start(self, entry: PracticeEntry, **overrides) -> None:
        """`overrides` (all optional) let the setup screen customize an
        airborne reposition beyond the catalog defaults: agl_ft, ias_kt,
        pitch_deg, lat, lon, ground_elevation_m -- see
        Repositioner.reposition_airborne for what each does. Ignored for
        ground entries (airborne_agl_ft is None)."""
        self.entry = entry
        self.task = entry.factory()
        self.last_result = None
        self._last_t = None
        self._last_overrides = overrides
        self._settle_remaining_s = 0.0
        if entry.airborne_agl_ft is not None and self._repositioner is not None:
            self._repositioner.reposition_airborne(
                overrides.get("agl_ft", entry.airborne_agl_ft),
                overrides.get("ias_kt", entry.airborne_ias_kt),
                pitch_deg=overrides.get("pitch_deg", 0.0),
                lat=overrides.get("lat"),
                lon=overrides.get("lon"),
                ground_elevation_m=overrides.get("ground_elevation_m"),
            )
            self._settle_remaining_s = SETTLE_S

    def retry(self) -> None:
        if self.entry is not None:
            self.start(self.entry, **self._last_overrides)

    def stop(self) -> None:
        self.entry = None
        self.task = None
        self.last_result = None
        self._last_t = None
        self._last_overrides = {}
        self._settle_remaining_s = 0.0

    def submit_answer(self, index: int) -> None:
        if self.task is None or self.last_result is not None:
            return
        answer = getattr(self.task, "answer", None)
        if answer is None:
            return
        result = answer(index)
        if result is not None:
            self.last_result = result

    def tick(self, state: FlightState) -> None:
        if self.task is None or self.last_result is not None:
            return
        if self._last_t is None:
            self._last_t = state.t
        dt = max(0.0, min(state.t - self._last_t, 1.0))
        self._last_t = state.t
        if self._settle_remaining_s > 0.0:
            self._settle_remaining_s -= dt
            return  # let the flight model settle after the teleport before the task sees any data
        result = self.task.update(state, dt)
        if result is not None:
            self.last_result = result
