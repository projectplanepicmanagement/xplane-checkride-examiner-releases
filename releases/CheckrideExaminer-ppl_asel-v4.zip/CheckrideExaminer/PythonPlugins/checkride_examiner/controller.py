"""Top-level controller: owns both the full checkride session and the
practice-mode session, and routes flight-loop ticks / UI actions to
whichever is active. Switching modes never resets the other mode's state --
you can leave a checkride mid-session, practice a task, and come back to
find the checkride exactly where you left it.

Also owns the per-aircraft settings store (aircraft_settings.py) -- values
like Vx/Vy that X-Plane has no dataref for, entered once per add-on via the
overlay's Settings screen. `tick()` watches `state.aircraft_key` and, on any
change (including the very first tick), re-applies that aircraft's saved
settings to every currently-relevant task via `Task.configure_from_settings`
so a task built before the aircraft was known (or before its settings were
last edited) still picks them up. Several of those settings are mandatory
for their task (`Task.blocking_reason()` is non-None until entered) rather
than optional/advisory, since a real target speed can vary by flight
school/aircraft and there's no sound default to assume otherwise.

Also owns the serial-key license store (license.py). Neither `start()` nor
`start_practice()` will flip `started` to True unless `is_licensed` -- so an
unactivated copy can't begin grading no matter what the overlay does, even
if a future UI change forgot to check first.

Also owns the weather controller (weather.py), same optional-injection
pattern as `repositioner` -- `None` in the offline test suite (nothing here
imports `xp`), a real `WeatherController` from PI_CheckrideExaminer.py at
runtime. `apply_weather_preset()` is a thin pass-through: weather is
presentation only, so the controller doesn't track which preset is active
or apply it to any task.

Also owns an optional `updater.UpdateChecker` (self-hosted update
check/install -- see updater.py's own module docstring for why this
exists instead of using SkunkCrafts Updater). Unlike `repositioner`/
`weather_controller`, `updater.py` imports no `xp` at all, so it's safe to
import directly here rather than needing a pure/impure module split.
`check_for_update()`/`apply_update()` both catch every exception and
return it as a plain string instead of raising, matching this class's
existing no-raise-across-the-boundary convention (see e.g.
`activate_license`) -- a network failure is an expected, displayable
outcome here, not a bug.
"""
from typing import List, Optional, Tuple

from .aircraft_settings import AircraftSettings, AircraftSettingsStore
from .license import LicenseStore
from .practice import PRACTICE_CATALOG, PracticeEntry, PracticeSession
from .sequence import ExaminerSession
from .state import FlightState
from .updater import UpdateInfo
from .weather_presets import PRESETS_BY_KEY

MODE_CHECKRIDE = "checkride"
MODE_PRACTICE = "practice"


class AppController:
    def __init__(
        self,
        repositioner=None,
        settings_store: Optional[AircraftSettingsStore] = None,
        license_store: Optional[LicenseStore] = None,
        weather_controller=None,
        update_checker=None,
    ):
        self.checkride = ExaminerSession()
        self.practice = PracticeSession(repositioner)
        self._weather_controller = weather_controller
        self._update_checker = update_checker
        self.mode = MODE_CHECKRIDE
        # Nothing is graded until the home screen's Start button is used --
        # otherwise a checkride would silently begin tracking Straight-and-
        # -Level the instant the plugin loads, before the pilot has even
        # picked a mode or rating.
        self.started = False
        self._settings_store = settings_store or AircraftSettingsStore(None)
        self._license_store = license_store or LicenseStore(None)
        self.aircraft_key: Optional[str] = None
        self.last_vso_kt: float = 0.0  # tracked so the Settings screen can suggest a Slow Flight target (1.2x this)

    @property
    def is_licensed(self) -> bool:
        return self._license_store.is_activated

    @property
    def licensed_ratings(self) -> Optional[Tuple[str, ...]]:
        """None means the activated key carries no rating restriction of
        its own (e.g. a legacy key) -- see LicenseStore.licensed_ratings /
        edition.visible_ratings(), which this feeds directly."""
        return self._license_store.licensed_ratings

    def license_key_display(self) -> str:
        return self._license_store.formatted_key

    @property
    def license_activation_error(self) -> Optional[str]:
        """A pilot-safe reason for the most recent failed activate_license()
        call (invalid key, already activated on another device, couldn't
        reach the license server, ...) -- see LicenseStore.activate()."""
        return self._license_store.last_activation_error

    def activate_license(self, raw_key: str) -> bool:
        return self._license_store.activate(raw_key)

    def start(self) -> None:
        if not self.is_licensed:
            return
        self.started = True

    def set_mode(self, mode: str) -> None:
        assert mode in (MODE_CHECKRIDE, MODE_PRACTICE)
        self.mode = mode

    def set_checkride_rating(self, rating: str) -> None:
        """Switching ratings starts a fresh session for that rating --
        unlike set_mode(), this does discard in-progress checkride state,
        since picking a different rating means starting a different exam."""
        if rating != self.checkride.rating:
            self.checkride = ExaminerSession(rating)
            self._apply_settings()

    def current_settings(self) -> AircraftSettings:
        if not self.aircraft_key:
            return AircraftSettings()
        return self._settings_store.get(self.aircraft_key)

    def is_current_aircraft_registered(self) -> bool:
        return bool(self.aircraft_key) and self._settings_store.is_registered(self.aircraft_key)

    def checkride_blocking_reasons(self) -> List[str]:
        """Every distinct Task.blocking_reason() across the current
        checkride session's full syllabus, in task order -- used by the
        overlay's pre-flight check (shown between "Start Checkride Mode"
        and the session actually starting) to surface every mandatory
        Aircraft Setting this rating needs up front, rather than a pilot
        discovering one is missing only when that specific task's turn
        comes up mid-session (user-reported: a tester was surprised by a
        "SETTINGS REQUIRED" banner appearing right before a maneuver)."""
        reasons: List[str] = []
        for task in self.checkride.tasks:
            reason = task.blocking_reason()
            if reason is not None and reason not in reasons:
                reasons.append(reason)
        return reasons

    def practice_blocking_reasons(self, rating: str) -> List[str]:
        """Same idea as checkride_blocking_reasons(), but for Practice
        Mode's pre-flight check: every distinct blocking reason across
        every PRACTICE_CATALOG entry available under `rating`, not just
        whichever single task a pilot happens to pick. Practice entries
        aren't pre-built Task instances the way a checkride session's are
        (PracticeEntry.factory() only creates one when a pilot actually
        starts it), so this builds a throwaway instance per entry purely
        to query blocking_reason() after configuring it from the current
        aircraft's settings -- none of these instances are kept, started,
        or used for grading."""
        settings = self.current_settings()
        reasons: List[str] = []
        for entry in PRACTICE_CATALOG:
            if rating not in entry.ratings:
                continue
            task = entry.factory()
            task.configure_from_settings(settings)
            reason = task.blocking_reason()
            if reason is not None and reason not in reasons:
                reasons.append(reason)
        return reasons

    def save_aircraft_settings(self, settings: AircraftSettings) -> None:
        if not self.aircraft_key:
            return
        self._settings_store.set(self.aircraft_key, settings)
        self._apply_settings()

    def _apply_settings(self) -> None:
        settings = self.current_settings()
        for task in self.checkride.tasks:
            task.configure_from_settings(settings)
        if self.practice.task is not None:
            self.practice.task.configure_from_settings(settings)

    def tick(self, state: FlightState) -> None:
        if state.aircraft_key and state.aircraft_key != self.aircraft_key:
            self.aircraft_key = state.aircraft_key
            self._apply_settings()
        self.last_vso_kt = state.vso_kt
        if not self.started:
            return
        if self.mode == MODE_CHECKRIDE:
            self.checkride.tick(state)
        else:
            self.practice.tick(state)

    def skip_current(self) -> None:
        if self.mode == MODE_CHECKRIDE:
            self.checkride.skip_current()

    def mark_ready(self) -> None:
        if self.mode == MODE_CHECKRIDE:
            self.checkride.ready()

    def restart(self) -> None:
        if self.mode == MODE_CHECKRIDE:
            self.checkride.restart()
            self._apply_settings()

    def submit_answer(self, index: int) -> None:
        if self.mode == MODE_CHECKRIDE:
            self.checkride.submit_answer(index)
        else:
            self.practice.submit_answer(index)

    def start_practice(self, entry: PracticeEntry) -> None:
        if not self.is_licensed:
            return
        self.started = True
        self.mode = MODE_PRACTICE
        self.practice.start(entry)
        self._apply_settings()

    def retry_practice(self) -> None:
        self.practice.retry()
        self._apply_settings()

    def stop_practice(self) -> None:
        self.practice.stop()

    def apply_weather_preset(self, key: str) -> None:
        """No-op if no WeatherController was injected (offline tests,
        or a future backend that doesn't wire one up) or the key isn't a
        known preset -- weather is presentation only, so silently doing
        nothing is safe either way."""
        if self._weather_controller is None:
            return
        preset = PRESETS_BY_KEY.get(key)
        if preset is None:
            return
        self._weather_controller.apply(preset)

    def check_for_update(self):
        """Returns (info, error) -- exactly one is non-None. `info` is an
        UpdateInfo if a newer version is available, or None if already up
        to date or the checker isn't configured. `error` is a
        human-readable string on failure (network, malformed manifest),
        never a raised exception."""
        if self._update_checker is None:
            return None, "no update checker configured"
        try:
            return self._update_checker.check(), None
        except Exception as exc:
            return None, str(exc)

    def apply_update(self, info: UpdateInfo) -> Optional[str]:
        """Returns None on success, or a human-readable error string on
        failure. Never raises."""
        if self._update_checker is None:
            return "no update checker configured"
        try:
            self._update_checker.apply(info)
            return None
        except Exception as exc:
            return str(exc)
