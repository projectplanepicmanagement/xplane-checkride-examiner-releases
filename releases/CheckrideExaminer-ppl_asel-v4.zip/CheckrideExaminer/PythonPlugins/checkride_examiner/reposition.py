"""Teleports the aircraft into the air for practice mode: a chosen height
above the ground, a chosen pitch, wings-level on the current heading, at a
chosen airspeed. Defaults to straight up from the current position, but can
also target a specific lat/lon (e.g. a nearby airport from `airports.py`)
-- still not "fly me to a training area" as a smooth transition, just a cut
to a different starting point.

Standard XPLM reposition technique: convert world (lat, lon, MSL-altitude)
to local OpenGL coordinates with worldToLocal(), write local_x/y/z directly
(all writable doubles), then set attitude (phi/theta/psi) and velocity
(local_vx/vy/vz) so the aircraft doesn't start in an unusual attitude or
tumble on the first physics frame.

When no lat/lon is given, target altitude is derived from the current
geometric elevation minus current AGL (i.e. current terrain elevation) plus
the requested AGL, so no terrain-probe API is needed. When a lat/lon *is*
given, the caller must supply `ground_elevation_m` too (e.g. a
NearbyAirport's `elevation_m`) since there's no cheap way to probe terrain
height at an arbitrary point from here.

Also force-starts engine 1 so you don't end up gliding after a reposition
from a cold-and-dark ramp start, or right after shutting the engine down
practicing something else. `ENGN_running` alone turned out NOT to be
enough: it's a status flag the flight model reports, not one that drives
it -- flipping it true doesn't spin the crankshaft/prop up from a
standstill, so the "engine" stayed lit but produced no thrust (RPM stuck
near 0). The actual fix is to also write the physically-simulated rotation
speed directly: `ENGN_tacrad` (engine) and `POINT_tacrad` (prop), both in
rad/sec, both writable. Setting those to a cruise-ish RPM gives the engine
model something already spinning to sustain combustion against, instead of
starting from 0.

Caveats: velocity magnitude is treated as indicated airspeed (ignores wind,
negligible at these altitudes/speeds); pitch sets a climb/descent-angle
velocity component but doesn't touch trim, so the aircraft may pitch itself
back toward level after the first physics frame unless the pilot holds it;
this whole engine force-start is the standard "instant relight" trick
plugins use, but a study-level aircraft with its own start/engine modeling
may not accept it the same way the default aircraft does.
"""
import math
from typing import Optional

from XPPython3 import xp

_FT_TO_M = 0.3048
_KT_TO_MPS = 0.514444
_RPM_TO_RAD_SEC = math.pi / 30.0  # 2*pi/60
DEFAULT_THROTTLE = 0.65
DEFAULT_ENGINE_RPM = 2300.0


class Repositioner:
    def __init__(self):
        self._lat = xp.findDataRef("sim/flightmodel/position/latitude")
        self._lon = xp.findDataRef("sim/flightmodel/position/longitude")
        self._elevation = xp.findDataRef("sim/flightmodel/position/elevation")
        self._agl_m = xp.findDataRef("sim/flightmodel/position/y_agl")
        self._local_x = xp.findDataRef("sim/flightmodel/position/local_x")
        self._local_y = xp.findDataRef("sim/flightmodel/position/local_y")
        self._local_z = xp.findDataRef("sim/flightmodel/position/local_z")
        self._local_vx = xp.findDataRef("sim/flightmodel/position/local_vx")
        self._local_vy = xp.findDataRef("sim/flightmodel/position/local_vy")
        self._local_vz = xp.findDataRef("sim/flightmodel/position/local_vz")
        self._psi = xp.findDataRef("sim/flightmodel/position/psi")
        self._theta = xp.findDataRef("sim/flightmodel/position/theta")
        self._phi = xp.findDataRef("sim/flightmodel/position/phi")
        self._thr = xp.findDataRef("sim/flightmodel/engine/ENGN_thro")
        self._running = xp.findDataRef("sim/flightmodel/engine/ENGN_running")
        self._mixture = xp.findDataRef("sim/cockpit2/engine/actuators/mixture_ratio")
        self._ignition = xp.findDataRef("sim/cockpit2/engine/actuators/ignition_on")
        self._fuel_pump = xp.findDataRef("sim/cockpit2/engine/actuators/fuel_pump_on")
        self._prop_mode = xp.findDataRef("sim/cockpit2/engine/actuators/prop_mode")
        self._engn_tacrad = xp.findDataRef("sim/flightmodel/engine/ENGN_tacrad")
        self._point_tacrad = xp.findDataRef("sim/flightmodel/engine/POINT_tacrad")

    def reposition_airborne(
        self,
        agl_ft: float,
        ias_kt: float,
        pitch_deg: float = 0.0,
        lat: Optional[float] = None,
        lon: Optional[float] = None,
        ground_elevation_m: Optional[float] = None,
        throttle_ratio: float = DEFAULT_THROTTLE,
        engine_rpm: float = DEFAULT_ENGINE_RPM,
    ) -> None:
        if lat is None or lon is None:
            lat = xp.getDatad(self._lat)
            lon = xp.getDatad(self._lon)
            elevation_m = xp.getDatad(self._elevation)
            agl_m_now = xp.getDataf(self._agl_m)
            ground_m = elevation_m - agl_m_now
        else:
            ground_m = ground_elevation_m if ground_elevation_m is not None else 0.0

        target_elevation_m = ground_m + agl_ft * _FT_TO_M
        heading_deg = xp.getDataf(self._psi)

        x, y, z = xp.worldToLocal(lat, lon, target_elevation_m)
        xp.setDatad(self._local_x, x)
        xp.setDatad(self._local_y, y)
        xp.setDatad(self._local_z, z)

        xp.setDataf(self._phi, 0.0)
        xp.setDataf(self._theta, pitch_deg)
        xp.setDataf(self._psi, heading_deg)

        hdg_rad = math.radians(heading_deg)
        pitch_rad = math.radians(pitch_deg)
        speed_mps = ias_kt * _KT_TO_MPS
        horizontal_mps = speed_mps * math.cos(pitch_rad)
        vertical_mps = speed_mps * math.sin(pitch_rad)
        xp.setDataf(self._local_vx, horizontal_mps * math.sin(hdg_rad))
        xp.setDataf(self._local_vy, vertical_mps)
        xp.setDataf(self._local_vz, -horizontal_mps * math.cos(hdg_rad))

        xp.setDatavf(self._thr, [throttle_ratio], 0, 1)
        xp.setDatavf(self._mixture, [1.0], 0, 1)
        xp.setDatavi(self._ignition, [3], 0, 1)
        xp.setDatavi(self._fuel_pump, [1], 0, 1)
        xp.setDatavi(self._prop_mode, [1], 0, 1)
        xp.setDatavi(self._running, [1], 0, 1)

        rad_sec = engine_rpm * _RPM_TO_RAD_SEC
        xp.setDatavf(self._engn_tacrad, [rad_sec], 0, 1)
        xp.setDatavf(self._point_tacrad, [rad_sec], 0, 1)
