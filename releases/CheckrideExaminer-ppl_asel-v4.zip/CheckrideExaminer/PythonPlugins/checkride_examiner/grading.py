"""ACS-style tolerance tracking shared by all examiner tasks.

Tolerance numbers used throughout this package come from the FAA Private
Pilot - Airplane ACS (FAA-S-ACS-6 / -6B), as tabulated by
OregonFlightSchool.com (Nov 2018, based on ACS-6B) and the AirTrekNorth
Cessna 172 ACS settings summary (based on ACS-6, June 2016). Where the ACS
gives an asymmetric range (e.g. "+10/-0 knots") pass asymmetric low/high
bounds to ToleranceSpec instead of using `symmetric()`.

A tracker only "busts" a task after being out of tolerance continuously for
longer than `grace_seconds` -- this mirrors how a real examiner tolerates a
brief excursion but flags a sustained deviation.

`gate_until_captured=True` adds a second layer on top of that: the
grace-period clock doesn't start running at all until the tracked value
has entered tolerance at least once. This exists for values that start
the task's grading window already out of tolerance by construction, not
by pilot error -- e.g. an approach's target airspeed tracker arms the
instant descent begins (often still on downwind, near cruise speed) and a
takeoff's Vx/Vy tracker arms at liftoff/obstacle-clear (before the
aircraft has had time to accelerate to that speed). Without this, the
tracker's few-seconds grace period -- generous for a brief excursion once
established -- isn't nearly enough time to physically decelerate/
accelerate from an arbitrary starting speed to the target, so the task
could bust in its very first moments purely for not having gotten there
yet (user-reported for both approach and takeoff tasks -- see
tasks/short_field.py's, tasks/normal_landing.py's and tasks/soft_field.py's
module docstrings for the full writeups). Once captured, behavior is
identical to the ungated case -- destabilizing after being established
still busts normally. `captured` is exposed so a caller can add an
advisory (non-hard) note if the value never got there at all before the
task finished grading.
"""
from dataclasses import dataclass
from typing import Callable, List, Optional


def _default_diff(value: float, target: float) -> float:
    return value - target


@dataclass
class ToleranceSpec:
    label: str
    unit: str
    target: float
    low: float
    high: float
    grace_seconds: float = 3.0

    @classmethod
    def symmetric(cls, label: str, unit: str, target: float, tolerance: float, grace_seconds: float = 3.0):
        return cls(label, unit, target, -tolerance, tolerance, grace_seconds)


class ToleranceTracker:
    def __init__(
        self,
        spec: ToleranceSpec,
        diff_fn: Optional[Callable[[float, float], float]] = None,
        gate_until_captured: bool = False,
    ):
        self.spec = spec
        self._diff_fn = diff_fn or _default_diff
        self._consecutive_bad = 0.0
        self.max_dev = 0.0
        self.busted = False
        self.bust_reason: Optional[str] = None
        self.last_dev = 0.0
        self.captured = not gate_until_captured

    def update(self, value: float, dt: float) -> None:
        dev = self._diff_fn(value, self.spec.target)
        self.last_dev = dev
        if abs(dev) > abs(self.max_dev):
            self.max_dev = dev
        in_tolerance = self.spec.low <= dev <= self.spec.high
        if not self.captured:
            if in_tolerance:
                self.captured = True
            else:
                return  # not yet captured -- see module docstring, never counts against the pilot
        if not in_tolerance:
            self._consecutive_bad += dt
            if self._consecutive_bad > self.spec.grace_seconds and not self.busted:
                self.busted = True
                self.bust_reason = (
                    f"{self.spec.label} {dev:+.1f}{self.spec.unit} out of tolerance "
                    f"for {self._consecutive_bad:.1f}s"
                )
        else:
            self._consecutive_bad = 0.0


@dataclass
class TaskResult:
    task_id: str
    title: str
    passed: bool
    notes: List[str]

    def summary_line(self) -> str:
        status = "SATISFACTORY" if self.passed else "UNSATISFACTORY"
        head = f"[{status}] {self.title}"
        return head + (" - " + "; ".join(self.notes) if self.notes else "")
