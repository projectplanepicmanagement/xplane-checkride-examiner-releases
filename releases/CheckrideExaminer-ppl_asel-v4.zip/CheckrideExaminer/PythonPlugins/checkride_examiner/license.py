"""Serial-key format, crypto, and local persistence.

A key is a random payload plus a keyed checksum (HMAC-SHA256, truncated)
computed against a secret embedded in this file; `is_valid_key()`
recomputes the checksum and compares it, so any key this module didn't
mint (typos, guesses, keys for a different product) fails. This part is,
and stays, fully offline -- X-Plane add-ons are expected to keep working
with no internet connection day-to-day, and nothing here needs to change
that.

**Activation itself now makes one online call.** A self-contained
key/checksum, by design, validates identically no matter how many
machines it's typed into -- nothing offline can enforce "one license, one
device." `LicenseStore.activate()` closes that gap by calling
`activation.verify_device()` (see that module's docstring for the full
design and its trade-offs), which the small hosted server in `/server/`
either accepts (first device to present this key, or the same device
re-activating) or rejects (`already_activated_elsewhere`). This is a
one-time gate at activation only -- once it succeeds, `is_activated` goes
straight back to being a purely local check, so the plugin still runs
fully offline the rest of the time; only pressing "Activate" needs
connectivity.

Honest limitation: this file ships as plain, readable Python source inside
the distributed plugin (see INSTALL.txt) -- there's no compiled binary to
hide the secret behind, unlike a compiled desktop app's license scheme.
Anyone willing to open license.py can read `_SECRET` and mint their own
valid-looking keys with `generate_key()`, and the activation server in
`/server/` has no way to tell such a forged key apart from a real one --
it only ever tracks device binding for whatever key string it's handed,
never re-derives or checks the checksum itself. Device binding stops
casual sharing of a *legitimately issued* key (the realistic threat: one
customer handing their own key to someone else); it does nothing against
a determined person reading the source and minting their own. See
README's Known Limitations.

`generate_key()` is for `tools/generate_license_key.py`, a developer-only
script that mints keys to hand out to customers; that script (unlike this
module) is deliberately excluded from the customer-facing dist zip by
package.sh, so customers never receive a copy of the generator itself.

**Keys can bind to a specific set of ratings, independent of the build.**
`edition.py`'s `SHIPPED_RATINGS` restricts which ratings a *build* exposes,
but a key that doesn't itself know which ratings it's allowed to unlock
gives no protection if a build more permissive than what a customer paid
for ever becomes reachable -- which is exactly what happened once already
(a full, all-ratings build was accidentally pushed to the public
distribution repo while only a PPL/ASEL edition had been sold; anyone
holding a valid PPL/ASEL key could have installed that build and unlocked
every rating with their own legitimate key, since the key itself carried
no restriction -- see SPEC.md's incident writeup). `generate_key(ratings=
...)` encodes which ratings a key authorizes directly into the key itself
(HMAC-covered, so it can't be edited without invalidating the checksum);
`decode_licensed_ratings()` recovers it at activation time. The effective
set of selectable ratings is the *intersection* of the build's
`SHIPPED_RATINGS` and the activated key's encoded ratings (see
`edition.visible_ratings()`) -- so even if a more permissive build ever
leaks again, a customer's own key still caps them at what they bought,
regardless of which zip they happen to be running.

Backward compatible by construction: `generate_key(ratings=None)` (the
default, and the only form that existed before this) produces a "legacy"
key that explicitly marks itself as carrying no rating restriction (bit 7
of the first payload byte cleared) -- `decode_licensed_ratings()` returns
None for these, meaning "no additional restriction beyond the build's
own," exactly the old behavior. Every key issued before this feature
existed decodes this way, so nothing already activated needs reissuing.
"""
import hashlib
import hmac
import json
import os
import secrets
from typing import Callable, Iterable, Optional, Tuple

from . import activation

# Not a real secret (see module docstring) -- just enough that a random or
# hand-typed string fails validation instead of accidentally passing.
_SECRET = b"CheckrideExaminer-License-Secret-v1-8f3c1a9d2e6b47f0a5d1"

_PAYLOAD_BYTES = 6
_CHECKSUM_BYTES = 4
_TOTAL_BYTES = _PAYLOAD_BYTES + _CHECKSUM_BYTES  # 10 bytes = 80 bits = 16 base32 chars, exactly
_KEY_CHARS = (_TOTAL_BYTES * 8) // 5
GROUP_SIZE = 4

# Bit layout of payload[0]: bit 7 marks "this key encodes a ratings
# restriction" (bits 0-5 below); clear means a legacy/unrestricted key.
# Bit 6 is reserved (always 0) for future use. This order, once shipped,
# must never change -- it's baked into every key already issued. Mirrors
# sequence.RATINGS' keys; kept as its own tuple rather than importing
# sequence.py (which would pull in the entire task suite as a side effect
# of importing this otherwise-minimal module) -- tests/test_license.py
# cross-checks the two stay in sync.
_RATING_BITS: Tuple[str, ...] = ("ppl_asel", "ppl_amel", "ir", "cpl", "cpl_amel", "ppl_helicopter")
_NEW_FORMAT_FLAG = 0x80
_RATINGS_MASK = 0x3F  # bits 0-5

# Crockford-style base32: drops I, L, O, U so a misread/mistyped character
# can't silently turn one valid-looking key into another.
_ALPHABET = "0123456789ABCDEFGHJKMNPQRSTVWXYZ"
_ALPHABET_INDEX = {c: i for i, c in enumerate(_ALPHABET)}


def _checksum(payload: bytes) -> bytes:
    return hmac.new(_SECRET, payload, hashlib.sha256).digest()[:_CHECKSUM_BYTES]


def _bytes_to_base32(data: bytes) -> str:
    bits = "".join(f"{b:08b}" for b in data)
    pad = (-len(bits)) % 5
    bits += "0" * pad
    return "".join(_ALPHABET[int(bits[i:i + 5], 2)] for i in range(0, len(bits), 5))


def _base32_to_bytes(chars: str, expected_bytes: int) -> Optional[bytes]:
    try:
        bits = "".join(f"{_ALPHABET_INDEX[c]:05b}" for c in chars)
    except KeyError:
        return None
    total_bits = expected_bytes * 8
    if len(bits) < total_bits:
        return None
    data = bytearray()
    for i in range(0, total_bits, 8):
        data.append(int(bits[i:i + 8], 2))
    return bytes(data)


def normalize_key(raw: str) -> str:
    """Strip formatting the pilot might type -- dashes, spaces, lowercase --
    back to the bare character stream format_key() produces."""
    return "".join(ch for ch in raw.upper() if ch in _ALPHABET_INDEX)


def format_key(chars: str) -> str:
    return "-".join(chars[i:i + GROUP_SIZE] for i in range(0, len(chars), GROUP_SIZE))


def _encode_ratings_bits(ratings: Iterable[str]) -> int:
    ratings = set(ratings)
    unknown = ratings - set(_RATING_BITS)
    if unknown:
        raise ValueError(f"unknown rating key(s): {sorted(unknown)}")
    bits = 0
    for i, key in enumerate(_RATING_BITS):
        if key in ratings:
            bits |= 1 << i
    return bits


def _decode_ratings_bits(bits: int) -> Tuple[str, ...]:
    return tuple(key for i, key in enumerate(_RATING_BITS) if bits & (1 << i))


def generate_key(ratings: Optional[Iterable[str]] = None) -> str:
    """Mint a new, valid serial key. Developer-only -- see module docstring.

    `ratings=None` (the default): a legacy-style key with no encoded
    restriction -- `decode_licensed_ratings()` returns None for it, same
    as every key issued before this feature existed.
    `ratings=(...)`: encodes exactly those RATINGS keys into the key
    itself (raises ValueError on an unrecognized key) -- the pilot will
    only ever be able to select ratings in *both* this set and whatever
    the installed build's own `edition.SHIPPED_RATINGS` exposes."""
    payload = bytearray(secrets.token_bytes(_PAYLOAD_BYTES))
    if ratings is None:
        payload[0] &= ~_NEW_FORMAT_FLAG & 0xFF
    else:
        payload[0] = _NEW_FORMAT_FLAG | _encode_ratings_bits(ratings)
    payload = bytes(payload)
    chars = _bytes_to_base32(payload + _checksum(payload))
    return format_key(chars)


def _verified_payload(raw: str) -> Optional[bytes]:
    """None if the key is malformed or its checksum doesn't match; the
    raw 6-byte payload otherwise. Shared by is_valid_key() and
    decode_licensed_ratings() so there's exactly one place that verifies
    the checksum."""
    chars = normalize_key(raw or "")
    if len(chars) != _KEY_CHARS:
        return None
    data = _base32_to_bytes(chars, _TOTAL_BYTES)
    if data is None:
        return None
    payload, checksum = data[:_PAYLOAD_BYTES], data[_PAYLOAD_BYTES:]
    if not hmac.compare_digest(_checksum(payload), checksum):
        return None
    return payload


def is_valid_key(raw: str) -> bool:
    return _verified_payload(raw) is not None


def decode_licensed_ratings(raw: str) -> Optional[Tuple[str, ...]]:
    """None means either the key is invalid, OR it's valid but carries no
    encoded restriction (a legacy key, or one deliberately minted with
    `ratings=None`) -- in both cases, no additional restriction beyond
    whatever the build's own `edition.SHIPPED_RATINGS` exposes. Callers
    that need "invalid" and "legacy, unrestricted" told apart should
    check `is_valid_key()` first."""
    payload = _verified_payload(raw)
    if payload is None:
        return None
    if not (payload[0] & _NEW_FORMAT_FLAG):
        return None
    return _decode_ratings_bits(payload[0] & _RATINGS_MASK)


class LicenseStore:
    """Persists the activated serial key (and its bound device_id, see
    below) to a small JSON file (same atomic-write, corrupt-tolerant
    pattern as aircraft_settings.AircraftSettingsStore) so the pilot only
    enters it once. `is_activated` re-validates the stored key against
    `is_valid_key()` on every check rather than trusting a saved flag --
    cheap, and means a hand-edited or corrupted file can never get stuck
    claiming a bad key is fine. This check is, deliberately, purely local
    -- see `activate()` below for the one place this class does touch the
    network.

    `path=None` runs fully in-memory (tests, and a harmless fallback if
    resolving a real path ever fails) -- activation just doesn't persist.

    `verify_device` is injected (same DI pattern as updater.UpdateChecker's
    `fetch_json`/`download`) so every test constructs a LicenseStore with a
    fake that never makes a real network call; production code (see
    PI_CheckrideExaminer.py) leaves it unset and gets the real
    `activation.verify_device`.
    """

    def __init__(
        self,
        path: Optional[str],
        verify_device: Optional[Callable[[str, str], Tuple[bool, Optional[str]]]] = None,
    ):
        self._path = path
        self._key = ""
        self._device_id = ""
        self._verify_device = verify_device or activation.verify_device
        # Set by a failed activate() to a message safe to show the pilot
        # as-is (invalid key, already-activated-elsewhere, network error,
        # ...) -- see overlay.py's license gate screen.
        self.last_activation_error: Optional[str] = None
        self._load()

    def _load(self) -> None:
        if not self._path or not os.path.exists(self._path):
            return
        try:
            with open(self._path, "r", encoding="utf-8") as f:
                raw = json.load(f)
            if isinstance(raw, dict):
                self._key = str(raw.get("key") or "")
                self._device_id = str(raw.get("device_id") or "")
        except (OSError, ValueError, TypeError):
            self._key = ""
            self._device_id = ""

    def _save(self) -> None:
        if not self._path:
            return
        directory = os.path.dirname(self._path)
        if directory:
            os.makedirs(directory, exist_ok=True)
        tmp_path = self._path + ".tmp"
        with open(tmp_path, "w", encoding="utf-8") as f:
            json.dump({"key": self._key, "device_id": self._device_id}, f, indent=2)
        os.replace(tmp_path, self._path)

    @property
    def is_activated(self) -> bool:
        return is_valid_key(self._key)

    @property
    def formatted_key(self) -> str:
        return format_key(self._key) if self._key else ""

    @property
    def licensed_ratings(self) -> Optional[Tuple[str, ...]]:
        """None means "no key-level restriction" -- either nothing is
        activated, or the activated key is a legacy one predating this
        feature. See decode_licensed_ratings()/edition.visible_ratings()."""
        if not self.is_activated:
            return None
        return decode_licensed_ratings(self._key)

    def activate(self, raw_key: str) -> bool:
        """Validates the key's own checksum (offline, instant), then makes
        one online call to bind this install to it (see activation.py) --
        rejected if a *different* device already claimed this key.
        Re-activating the same already-bound key on the same device (e.g.
        after a reinstall that preserved this file) succeeds again rather
        than erroring. On any failure, `last_activation_error` holds a
        pilot-safe reason and this returns False without touching the
        persisted key/device_id."""
        self.last_activation_error = None
        normalized = normalize_key(raw_key)
        if not is_valid_key(normalized):
            self.last_activation_error = "That key isn't valid -- check for typos."
            return False
        device_id = self._device_id or activation.new_device_id()
        ok, error = self._verify_device(normalized, device_id)
        if not ok:
            self.last_activation_error = error or "Activation failed."
            return False
        self._key = normalized
        self._device_id = device_id
        self._save()
        return True
