"""IR.VI.A Non-precision Approach, IR.VI.B Precision Approach.

VOR/localizer + glideslope (NAV1) only -- no GPS/RNAV vertical guidance in
this build (see README/SPEC known limitations). Neither task knows the
actual published FAF/MDA/DA for the approach you loaded (the plugin can't
read the procedure you briefed), so the "final segment" for each is
triggered heuristically instead:
  - NPA: a sustained descent (VS < -300fpm) is treated as starting the
    final descent; leveling back off (|VS| < 200fpm, held 3s) is treated
    as reaching MDA, whose altitude becomes the ACS's +100/-0 reference
    for the rest of the task.
  - PA: glideslope capture (centered within 0.5 dot, established descent)
    is treated as the start of the final approach segment; descending
    500ft from there is treated as reaching DA.
Neither task can tell whether the runway environment is actually in sight,
so "land or go missed" is left as an instruction, not something graded.

Trackers are only ever appended to `self.trackers`, never replaced --
otherwise a bust from an earlier phase (e.g. altitude drifting before
glideslope capture) would silently disappear from grading once that
tracker stopped being the "current" one. `status_lines()` inherited from
Task will show a stale reading for a retired tracker after a phase change,
which is a minor display quirk in exchange for never hiding a bust.
"""
from ..grading import ToleranceSpec, ToleranceTracker
from .base import Task

CDI_TOLERANCE_DOTS = 1.5
DESCENT_ARM_FPM = -300.0
LEVEL_OFF_FPM = 200.0
LEVEL_OFF_HOLD_S = 3.0
FINAL_SEGMENT_S = 30.0
GS_CAPTURE_DOTS = 0.5
GS_DESCENT_ARM_FPM = -200.0
DA_DESCENT_FT = 500.0
TIMEOUT_S = 240.0


class NonprecisionApproachTask(Task):
    task_id = "nonprecision_approach"
    title = "Non-precision Approach"
    acs_ref = "IR.VI.A"

    def __init__(self):
        super().__init__()
        self._phase = "enroute"  # enroute -> descending -> final
        self._started_at = None
        self._level_streak = 0.0
        self._mda_alt = None
        self._final_started_at = None
        self._cdi_t = None
        self._ias_t = None
        self._alt_t = None

    def instructions(self):
        if self._phase == "enroute":
            return "Track the approach course inbound. Begin your descent when established."
        if self._phase == "descending":
            return "Descending to MDA. Track the course and hold airspeed."
        return f"At MDA ({self._mda_alt:.0f} ft). Track the course to the MAP, then land or go missed."

    def update(self, state, dt):
        if self._started_at is None:
            self._started_at = state.t
            self._cdi_t = ToleranceTracker(ToleranceSpec.symmetric("CDI", "dots", 0.0, CDI_TOLERANCE_DOTS))
            self._ias_t = ToleranceTracker(ToleranceSpec.symmetric("Airspeed", "kt", state.ias_kt, 10.0))
            self.trackers = [self._cdi_t, self._ias_t]

        if state.t - self._started_at > TIMEOUT_S:
            return self._finish(False, ["did not complete the approach in time"])

        self._cdi_t.update(state.nav1_hdef_dots, dt)
        self._ias_t.update(state.ias_kt, dt)

        if self._phase == "enroute":
            if state.vs_fpm < DESCENT_ARM_FPM:
                self._phase = "descending"
            return None

        if self._phase == "descending":
            if abs(state.vs_fpm) < LEVEL_OFF_FPM:
                self._level_streak += dt
                if self._level_streak >= LEVEL_OFF_HOLD_S:
                    self._mda_alt = state.indicated_alt_ft
                    self._alt_t = ToleranceTracker(ToleranceSpec("Altitude", "ft", self._mda_alt, 0.0, 100.0))
                    self.trackers.append(self._alt_t)
                    self._phase = "final"
                    self._final_started_at = state.t
            else:
                self._level_streak = 0.0
            return None

        # phase == final
        self._alt_t.update(state.indicated_alt_ft, dt)
        if state.t - self._final_started_at > FINAL_SEGMENT_S:
            return self._finish(True, [f"MDA held at {self._mda_alt:.0f} ft"])
        return None


class PrecisionApproachTask(Task):
    task_id = "precision_approach"
    title = "Precision Approach (ILS)"
    acs_ref = "IR.VI.B"

    def __init__(self):
        super().__init__()
        self._phase = "enroute"  # enroute -> final
        self._started_at = None
        self._capture_alt = None
        self._alt_t = None
        self._hcdi_t = None
        self._ias_t = None
        self._vcdi_t = None

    def instructions(self):
        if self._phase == "enroute":
            return "Intercept the localizer and glideslope. Track the course and hold altitude/airspeed."
        return "On the glideslope -- hold the needles centered to DA, then land or go missed."

    def update(self, state, dt):
        if self._started_at is None:
            self._started_at = state.t
            self._alt_t = ToleranceTracker(ToleranceSpec.symmetric("Altitude", "ft", state.indicated_alt_ft, 100.0))
            self._hcdi_t = ToleranceTracker(ToleranceSpec.symmetric("Localizer", "dots", 0.0, CDI_TOLERANCE_DOTS))
            self._ias_t = ToleranceTracker(ToleranceSpec.symmetric("Airspeed", "kt", state.ias_kt, 10.0))
            self.trackers = [self._alt_t, self._hcdi_t, self._ias_t]

        if state.t - self._started_at > TIMEOUT_S:
            return self._finish(False, ["did not complete the approach in time"])

        self._hcdi_t.update(state.nav1_hdef_dots, dt)
        self._ias_t.update(state.ias_kt, dt)

        if self._phase == "enroute":
            self._alt_t.update(state.indicated_alt_ft, dt)
            gs_captured = (
                abs(state.nav1_vdef_dots) < GS_CAPTURE_DOTS
                and abs(state.nav1_hdef_dots) < CDI_TOLERANCE_DOTS
                and state.vs_fpm < GS_DESCENT_ARM_FPM
            )
            if gs_captured:
                self._capture_alt = state.indicated_alt_ft
                self._vcdi_t = ToleranceTracker(ToleranceSpec.symmetric("Glideslope", "dots", 0.0, CDI_TOLERANCE_DOTS))
                self.trackers.append(self._vcdi_t)
                self._phase = "final"
            return None

        # phase == final
        self._vcdi_t.update(state.nav1_vdef_dots, dt)
        if self._capture_alt - state.indicated_alt_ft >= DA_DESCENT_FT:
            return self._finish(True, ["reached DA"])
        return None
