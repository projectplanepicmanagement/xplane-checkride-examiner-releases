"""Multiple-choice knowledge checks.

Radio phraseology and clearance compliance can't be graded from flight data
-- X-Plane has no dataref for "did the pilot say the right words" -- so
instead of trying to infer correctness from COM1 tuning alone, these are
asked as multiple-choice questions (like a DPE's oral quiz), using standard
phraseology from the AIM. This directly tests the PA.III.A (PPL Airport
Operations: Communications) and IR.III.A (Compliance with ATC Clearances)
knowledge elements in a way that's actually gradable: pick the right answer
or don't.

A `MultipleChoiceTask` never completes on its own from `update()` -- it
waits for `answer(index)` to be called (from a button click in the overlay,
or from the checkride/examiner/answer_a..d commands), so `ExaminerSession`
needs a `submit_answer()` entry point distinct from the normal flight-data
`tick()`.
"""
import random
from dataclasses import dataclass
from typing import List

from .base import Task


@dataclass
class MultipleChoiceQuestion:
    prompt: str
    options: List[str]
    correct_index: int
    explanation: str = ""


class MultipleChoiceTask(Task):
    def __init__(self, task_id: str, title: str, acs_ref: str, question: MultipleChoiceQuestion):
        super().__init__()
        self.task_id = task_id
        self.title = title
        self.acs_ref = acs_ref
        self.question = question
        self._answered = False

    def instructions(self) -> str:
        return self.question.prompt

    def update(self, state, dt):
        return None  # only answer() can finish this task

    def answer(self, index: int):
        if self._answered or self.finished:
            return None
        self._answered = True
        correct = index == self.question.correct_index
        notes = []
        if not correct and 0 <= index < len(self.question.options):
            notes.append(f'you chose "{self.question.options[index]}"')
        notes.append(f'correct answer: "{self.question.options[self.question.correct_index]}"')
        if self.question.explanation:
            notes.append(self.question.explanation)
        return self._finish(correct, notes)


_GROUND_QUESTIONS = [
    MultipleChoiceQuestion(
        prompt=(
            "You're ready to taxi from parking with ATIS information Bravo, planning "
            "a VFR departure to the practice area. What do you say to Ground?"
        ),
        options=[
            "\"Ground, Cessna one two three four five, ready to taxi.\"",
            "\"Cessna one two three four five, request taxi.\"",
            "\"Ground, Cessna one two three four five, at the ramp, ready to taxi, "
            "VFR departure to the practice area, with information Bravo.\"",
            "\"Tower, Cessna one two three four five, ready for takeoff.\"",
        ],
        correct_index=2,
        explanation=(
            "Standard format: who you're calling, who you are, where you are, "
            "what you want, and the ATIS code -- and taxi/departure clearance "
            "is Ground's job, not Tower's."
        ),
    ),
    MultipleChoiceQuestion(
        prompt=(
            "You're at the FBO ramp with information Charlie, and want progressive "
            "taxi instructions to Runway 9 because you're unfamiliar with the airport. "
            "What do you say to Ground?"
        ),
        options=[
            "\"Ground, Cessna six seven eight nine zero, at the FBO ramp, request "
            "progressive taxi to runway nine, with Charlie.\"",
            "\"Cessna six seven eight nine zero is taxiing to runway nine.\"",
            "\"Tower, Cessna six seven eight nine zero, request taxi instructions.\"",
            "\"Ground, requesting a taxi route.\" (no callsign or position given)",
        ],
        correct_index=0,
        explanation=(
            "Ask Ground (not Tower) for taxi, and always include your full "
            "callsign and position -- \"progressive taxi\" is the standard way "
            "to ask for turn-by-turn instructions when unfamiliar."
        ),
    ),
]

_TOWER_QUESTIONS = [
    MultipleChoiceQuestion(
        prompt=(
            "You've completed your run-up and are holding short of Runway 27, ready "
            "for departure. What do you say to Tower?"
        ),
        options=[
            "\"[Airport] Tower, Cessna one two three four five, holding short runway "
            "two seven, ready for departure.\"",
            "\"Ground, Cessna one two three four five, ready for takeoff.\"",
            "\"Cessna one two three four five is taking runway two seven.\"",
            "\"[Airport] Tower, Cessna one two three four five, requesting taxi to "
            "runway two seven.\"",
        ],
        correct_index=0,
        explanation=(
            "Takeoff clearance is Tower's job. Announce your position (holding "
            "short) and intention (ready for departure) -- never state you're "
            "taking the runway before Tower clears you."
        ),
    ),
    MultipleChoiceQuestion(
        prompt=(
            "Tower calls: \"Cessna three four five, traffic is a Skyhawk on a "
            "three-mile final, runway two seven, cleared for takeoff.\" What is the "
            "correct readback?"
        ),
        options=[
            "\"Cleared for takeoff, three four five.\"",
            "\"Roger.\"",
            "\"Three four five, cleared for takeoff, looking for the traffic.\"",
            "You don't need to reply -- Tower will assume you heard it.",
        ],
        correct_index=2,
        explanation=(
            "A takeoff clearance should be read back with your callsign, and "
            "acknowledging the traffic call-out shows you have it in mind -- a "
            "bare \"roger\" doesn't confirm you understood the clearance itself."
        ),
    ),
]


def random_ground_question_task() -> MultipleChoiceTask:
    return MultipleChoiceTask("radio_call_ground", "Contact Ground", "PA.III.A", random.choice(_GROUND_QUESTIONS))


def random_tower_question_task() -> MultipleChoiceTask:
    return MultipleChoiceTask("radio_call_tower", "Contact Tower", "PA.III.A", random.choice(_TOWER_QUESTIONS))


_CLEARANCE_QUESTIONS = [
    MultipleChoiceQuestion(
        prompt=(
            "ATC issues: \"Cessna three four X-ray, cleared to Springfield Airport "
            "via radar vectors Victor 12, then as filed. Climb and maintain 5,000. "
            "Expect 8,000 10 minutes after departure. Departure frequency 124.5, "
            "squawk 4523.\" What's the correct readback?"
        ),
        options=[
            "\"Cleared as filed, three four X-ray.\"",
            "\"Cessna three four X-ray, cleared to Springfield via radar vectors "
            "Victor 12, then as filed, climb and maintain 5,000, expect 8,000 in "
            "10 minutes, departure 124.5, squawk 4523.\"",
            "\"Roger, three four X-ray.\"",
            "\"Three four X-ray copies.\"",
        ],
        correct_index=1,
        explanation=(
            "A full IFR clearance is read back element by element with your "
            "callsign -- route, altitude, expect-altitude time, departure "
            "frequency, and squawk -- not just acknowledged."
        ),
    ),
    MultipleChoiceQuestion(
        prompt=(
            "ATC issues: \"Cessna five alpha bravo, clearance void if not off by "
            "1450 Zulu. If not off by 1450, advise Denver Clearance within 30 "
            "minutes.\" You are not able to depart by 1450Z. What must you do?"
        ),
        options=[
            "Depart a few minutes late anyway -- the void time is just a guideline.",
            "Call Denver Clearance within 30 minutes of 1450Z to cancel or get an "
            "amended clearance.",
            "Wait and try the same clearance again later without telling ATC.",
            "Switch to Tower and depart whenever ready, IFR or not.",
        ],
        correct_index=1,
        explanation=(
            "Missing a void time cancels your IFR clearance -- other traffic may "
            "be sequenced around your \"on time\" departure, so you must contact "
            "ATC within the stated window or you're not covered by any clearance."
        ),
    ),
]


def random_clearance_question_task() -> MultipleChoiceTask:
    return MultipleChoiceTask("atc_clearance", "Compliance with ATC Clearances", "IR.III.A", random.choice(_CLEARANCE_QUESTIONS))
