"""PA.IX.A Basic Instrument Maneuvers -- Straight-and-Level, Constant
Airspeed Climbs/Descents, Turns to Headings.

ACS: altitude +/-200ft, heading +/-20deg, airspeed +/-10kt for S&L/climb/
descent (AirTrekNorth Cessna 172 ACS settings summary); Turns to Headings
uses a tighter +/-10deg on the assigned rollout heading, standard rate turn
(OregonFlightSchool.com summary, ACS-6B).
"""
import random

from ..grading import ToleranceSpec, ToleranceTracker
from ..util import heading_diff
from .base import HoldTask, Task


class StraightAndLevelTask(HoldTask):
    task_id = "basic_instrument_straight_level"
    title = "Straight-and-Level Flight"
    acs_ref = "PA.IX.A"
    HOLD_SECONDS = 30.0

    def instructions(self):
        return "Fly straight-and-level. Hold altitude, heading, and airspeed."

    def _arm_condition(self, state):
        return not state.on_ground and abs(state.vs_fpm) < 150.0 and abs(state.bank_deg) < 10.0

    def _on_arm(self, state):
        alt_t = ToleranceTracker(ToleranceSpec.symmetric("Altitude", "ft", state.indicated_alt_ft, 200.0))
        hdg_t = ToleranceTracker(ToleranceSpec.symmetric("Heading", "deg", state.heading_deg, 20.0), diff_fn=heading_diff)
        ias_t = ToleranceTracker(ToleranceSpec.symmetric("Airspeed", "kt", state.ias_kt, 10.0))
        self.tracked = [
            (alt_t, lambda s: s.indicated_alt_ft),
            (hdg_t, lambda s: s.heading_deg),
            (ias_t, lambda s: s.ias_kt),
        ]


class ConstantAirspeedClimbTask(HoldTask):
    task_id = "basic_instrument_climb"
    title = "Constant Airspeed Climb"
    acs_ref = "PA.IX.A"
    HOLD_SECONDS = 25.0
    ARM_TIMEOUT_S = 90.0

    def instructions(self):
        return "Establish a climb and hold a constant airspeed and heading."

    def _arm_condition(self, state):
        return state.vs_fpm > 200.0

    def _on_arm(self, state):
        hdg_t = ToleranceTracker(ToleranceSpec.symmetric("Heading", "deg", state.heading_deg, 20.0), diff_fn=heading_diff)
        ias_t = ToleranceTracker(ToleranceSpec.symmetric("Airspeed", "kt", state.ias_kt, 10.0))
        self.tracked = [
            (hdg_t, lambda s: s.heading_deg),
            (ias_t, lambda s: s.ias_kt),
        ]


class ConstantAirspeedDescentTask(HoldTask):
    task_id = "basic_instrument_descent"
    title = "Constant Airspeed Descent"
    acs_ref = "PA.IX.A"
    HOLD_SECONDS = 25.0
    ARM_TIMEOUT_S = 90.0

    def instructions(self):
        return "Establish a descent and hold a constant airspeed and heading."

    def _arm_condition(self, state):
        return state.vs_fpm < -200.0

    def _on_arm(self, state):
        hdg_t = ToleranceTracker(ToleranceSpec.symmetric("Heading", "deg", state.heading_deg, 20.0), diff_fn=heading_diff)
        ias_t = ToleranceTracker(ToleranceSpec.symmetric("Airspeed", "kt", state.ias_kt, 10.0))
        self.tracked = [
            (hdg_t, lambda s: s.heading_deg),
            (ias_t, lambda s: s.ias_kt),
        ]


class TurnsToHeadingTask(Task):
    task_id = "basic_instrument_turns"
    title = "Turns to Headings"
    acs_ref = "PA.IX.A"
    TIMEOUT_S = 90.0
    _OFFSETS = (90.0, -90.0, 120.0, -120.0)

    def __init__(self):
        super().__init__()
        self._target_heading = None
        self._started_at = None
        self._alt_t = None
        self._ias_t = None

    def instructions(self):
        if self._target_heading is None:
            return "Standard-rate turn to the assigned heading."
        return f"Standard-rate turn to heading {self._target_heading:03.0f}deg, holding altitude and airspeed."

    def update(self, state, dt):
        if self._started_at is None:
            self._started_at = state.t
            self._target_heading = (state.heading_deg + random.choice(self._OFFSETS)) % 360.0
            self._alt_t = ToleranceTracker(ToleranceSpec.symmetric("Altitude", "ft", state.indicated_alt_ft, 200.0))
            self._ias_t = ToleranceTracker(ToleranceSpec.symmetric("Airspeed", "kt", state.ias_kt, 10.0))
            self.trackers = [self._alt_t, self._ias_t]
            return None

        self._alt_t.update(state.indicated_alt_ft, dt)
        self._ias_t.update(state.ias_kt, dt)

        if state.t - self._started_at > self.TIMEOUT_S:
            return self._finish(False, ["did not roll out on the assigned heading in time"])

        on_heading = abs(heading_diff(state.heading_deg, self._target_heading)) < 10.0
        level = abs(state.bank_deg) < 10.0
        if on_heading and level and (state.t - self._started_at) > 5.0:
            rollout_dev = heading_diff(state.heading_deg, self._target_heading)
            return self._finish(True, [f"rolled out {rollout_dev:+.0f}deg from assigned heading {self._target_heading:03.0f}deg"])
        return None
