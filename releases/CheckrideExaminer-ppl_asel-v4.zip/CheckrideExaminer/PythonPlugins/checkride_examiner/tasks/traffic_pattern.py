"""PA.III.B (Private) / CA.III.B (Commercial) Traffic Patterns.

ACS (FAA-S-ACS-6C, Area III Task B -- fetched and confirmed directly, since
the usual secondary-source summary tables used elsewhere in this package
don't cover Area III): only one skill has an explicit number,
PA.III.B.S6, "maintain traffic pattern altitude, +/-100 feet, and the
appropriate airspeed, +/-10 knots" -- identical for Private and Commercial
(not tightened, unlike almost every other Commercial task here). The rest
of the task's skills (comply with pattern procedures, correct for wind
drift, maintain orientation with the runway, maintain spacing from other
traffic) are procedural/situational judgment calls a real DPE watches for,
not something with its own numeric standard to check against flight data
alone.

X-Plane has no reliable way to read an arbitrary runway's heading/position
from a plugin (confirmed: DataRefs.txt has no runway-geometry dataref, and
the XPLM navigation API's airport lookup -- see airports.py -- only
reports airport reference points, not individual runway headings), so like
Turns Around a Point (ground_reference.py), this can't grade against a
real runway. Instead the pattern's own entry heading (whatever heading the
pilot is on when the task starts, i.e. "downwind") stands in for "the
runway", and the task grades a self-referenced downwind -> base -> final
turn (a continuous ~180deg turn in one direction, same "grade on rollout,
not on an exact cumulative-degrees threshold" fix as Steep Turns --
tasks/steep_turns.py -- since a pilot judges the turn by eye against where
they started, not by an instrument's running sum) while holding pattern
altitude/airspeed throughout -- the one thing the ACS does give a real
number for.
"""
from ..grading import ToleranceSpec, ToleranceTracker
from ..util import heading_diff, wrap360
from .base import Task

ALT_TOL_FT = 100.0
IAS_TOL_KT = 10.0
STABILIZED_VS_FPM = 300.0  # arm gate -- lenient vs. Straight-and-Level's 150, pattern altitude changes are common
TURN_ARM_DEG = 75.0  # how far into the turn-to-base counts as "committed" -- real turns aren't flown to the exact degree
ROLLOUT_TURN_FLOOR_DEG = 150.0  # most of the 180 done before honoring an early rollout
LEVEL_BANK_DEG = 10.0
ROLLOUT_TOL_DEG = 10.0
TIMEOUT_S = 180.0


class TrafficPatternTask(Task):
    task_id = "traffic_pattern"
    title = "Traffic Pattern"

    def __init__(self, direction: str = "left", acs_ref: str = "PA.III.B"):
        super().__init__()
        assert direction in ("left", "right")
        self.direction = direction
        self.acs_ref = acs_ref
        self._sign = -1.0 if direction == "left" else 1.0
        self._phase = "armed"  # armed -> downwind -> turning
        self._armed_at = None
        self._started_turn_at = None
        self._entry_heading = None
        self._last_heading = None
        self._cumulative_turn = 0.0
        self._alt_t = None
        self._ias_t = None

    def instructions(self):
        if self._phase == "armed":
            return f"Establish {self.direction} downwind at pattern altitude and airspeed."
        if self._phase == "downwind":
            return "Hold downwind, then turn base and final on your own call."
        return "Turning through base to final -- hold pattern altitude and airspeed to rollout."

    def update(self, state, dt):
        if self._phase == "armed":
            if self._armed_at is None:
                self._armed_at = state.t
            if state.t - self._armed_at > TIMEOUT_S:
                return self._finish(False, ["never established a stabilized downwind"])
            if not state.on_ground and abs(state.vs_fpm) < STABILIZED_VS_FPM:
                self._entry_heading = state.heading_deg
                self._last_heading = state.heading_deg
                self._alt_t = ToleranceTracker(ToleranceSpec.symmetric("Altitude", "ft", state.indicated_alt_ft, ALT_TOL_FT))
                self._ias_t = ToleranceTracker(ToleranceSpec.symmetric("Airspeed", "kt", state.ias_kt, IAS_TOL_KT))
                self.trackers = [self._alt_t, self._ias_t]
                self._phase = "downwind"
                self._started_turn_at = state.t  # reused below as the overall post-arm timeout clock
            return None

        if state.t - self._started_turn_at > TIMEOUT_S:
            return self._finish(False, ["did not complete the pattern in time"])

        self._alt_t.update(state.indicated_alt_ft, dt)
        self._ias_t.update(state.ias_kt, dt)

        d = heading_diff(state.heading_deg, self._last_heading)
        self._cumulative_turn += d
        self._last_heading = state.heading_deg
        turned = self._sign * self._cumulative_turn  # positive once turned the correct (pattern-side) direction

        if self._phase == "downwind":
            if turned >= TURN_ARM_DEG:
                self._phase = "turning"
            return None

        # phase == "turning": grade on rollout, same early-vs-exact-360 fix as SteepTurnTask
        completed_full = turned >= 180.0
        rolled_out_early = turned >= ROLLOUT_TURN_FLOOR_DEG and abs(state.bank_deg) < LEVEL_BANK_DEG
        if completed_full or rolled_out_early:
            target_heading = wrap360(self._entry_heading + 180.0)
            rollout_dev = heading_diff(state.heading_deg, target_heading)
            notes = []
            passed = True
            if abs(rollout_dev) > ROLLOUT_TOL_DEG:
                passed = False
                notes.append(f"rolled out {rollout_dev:+.0f}deg off the extended runway centerline (limit +/-{ROLLOUT_TOL_DEG:.0f}deg)")
            return self._finish(passed, notes)
        return None
