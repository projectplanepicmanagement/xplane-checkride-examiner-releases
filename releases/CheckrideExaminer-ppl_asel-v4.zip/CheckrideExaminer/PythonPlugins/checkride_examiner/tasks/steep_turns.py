"""PA.V.A (Private) / CA.V.A (Commercial) Steep Turns.

ACS: 360deg turn, altitude +/-100 ft, bank +/-5deg, rollout heading
+/-10deg, airspeed +/-10kt. Private uses ~45deg bank (FAA-S-ACS-6);
Commercial uses ~50deg bank (FAA-S-ACS-7B) -- same tolerances otherwise,
so `target_bank`/`acs_ref` are constructor params rather than two classes.
"""
from ..grading import ToleranceSpec, ToleranceTracker
from ..util import heading_diff
from .base import Task

ARM_BANK_DEG = 25.0
DEFAULT_TARGET_BANK = 45.0
TIMEOUT_S = 90.0
# A real pilot judges rollout by eye (looking for the entry heading on the
# gauge), not by an exact net-360.00 sum of every sampled heading delta --
# rolling out a few degrees short (or continuing a few past) is normal and
# is exactly what the +/-10deg rollout tolerance below is for. Requiring
# the cumulative sum to reach literally >=360.0 before finishing meant a
# pilot who rolled level a bit early left the task waiting forever (heading
# no longer changing once wings are level, so the sum simply stops
# advancing) until it times out at TIMEOUT_S -- reported as the turn "never
# ending". So once most of the turn is done, rolling out of the bank ends
# the maneuver right there and grades whatever heading that landed on,
# same as continuing all the way to an exact 360 does.
EARLY_ROLLOUT_TURN_FLOOR_DEG = 300.0


class SteepTurnTask(Task):
    def __init__(self, direction: str, target_bank: float = DEFAULT_TARGET_BANK, acs_ref: str = "PA.V.A"):
        super().__init__()
        assert direction in ("left", "right")
        self.direction = direction
        self.acs_ref = acs_ref
        self._sign = -1.0 if direction == "left" else 1.0
        self._target_bank = target_bank
        self.task_id = f"steep_turn_{direction}"
        self.title = f"Steep Turn ({direction.title()}, {target_bank:.0f}deg Bank)"

        self._phase = "armed"
        self._armed_at = None
        self._turn_started_at = None
        self._entry_heading = None
        self._last_heading = None
        self._cumulative_turn = 0.0
        self._alt_t = None
        self._ias_t = None
        self._bank_t = None

    def instructions(self):
        return (
            f"Roll into a {self._target_bank:.0f}deg bank turn to the {self.direction}. "
            "Hold through a full 360deg, maintaining altitude and airspeed."
        )

    def update(self, state, dt):
        if self._phase == "armed":
            if self._armed_at is None:
                self._armed_at = state.t
            if state.t - self._armed_at > TIMEOUT_S:
                return self._finish(False, [f"never established a {self.direction} steep turn"])
            if self._sign * state.bank_deg > ARM_BANK_DEG:
                self._entry_heading = state.heading_deg
                self._last_heading = state.heading_deg
                self._cumulative_turn = 0.0
                self._alt_t = ToleranceTracker(ToleranceSpec.symmetric("Altitude", "ft", state.indicated_alt_ft, 100.0))
                self._ias_t = ToleranceTracker(ToleranceSpec.symmetric("Airspeed", "kt", state.ias_kt, 10.0))
                self._bank_t = ToleranceTracker(ToleranceSpec.symmetric("Bank", "deg", self._sign * self._target_bank, 5.0))
                self.trackers = [self._alt_t, self._ias_t, self._bank_t]
                self._phase = "turning"
                self._turn_started_at = state.t
            return None

        d = heading_diff(state.heading_deg, self._last_heading)
        self._cumulative_turn += d
        self._last_heading = state.heading_deg
        self._alt_t.update(state.indicated_alt_ft, dt)
        self._ias_t.update(state.ias_kt, dt)
        self._bank_t.update(state.bank_deg, dt)

        if state.t - self._turn_started_at > TIMEOUT_S:
            return self._finish(False, ["did not complete a full 360deg turn in time"])

        turned_enough = abs(self._cumulative_turn) >= EARLY_ROLLOUT_TURN_FLOOR_DEG
        completed_full_circle = abs(self._cumulative_turn) >= 360.0
        rolled_out_of_bank = self._sign * state.bank_deg < ARM_BANK_DEG
        if completed_full_circle or (turned_enough and rolled_out_of_bank):
            rollout_dev = heading_diff(state.heading_deg, self._entry_heading)
            notes = []
            passed = True
            if abs(rollout_dev) > 10.0:
                passed = False
                notes.append(f"rolled out {rollout_dev:+.0f}deg off entry heading (limit +/-10deg)")
            return self._finish(passed, notes)
        return None
