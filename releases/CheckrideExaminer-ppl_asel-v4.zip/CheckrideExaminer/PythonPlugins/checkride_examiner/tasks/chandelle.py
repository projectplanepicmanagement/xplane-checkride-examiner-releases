"""CA.V.C Chandelles.

ACS (FAA-S-ACS-7B): complete no lower than 1,500 ft AGL (CA.V.C.S2); ~30deg
bank established for the climbing turn to the 90deg point, continuously
decreasing airspeed (S4/S5); constant-rate rollout from 90deg to 180deg,
maintaining power and pitch attitude (S6); complete rollout at the 180deg
point, "+/-10deg just above a stall airspeed, maintaining that airspeed
momentarily avoiding a stall" (S7).

That S7 wording is read here as: rollout heading +/-10deg of the reciprocal
of the entry heading, and airspeed at rollout should have decayed to just
above stall (approximated, like the stall tasks, as the stall warning
being active) without an actual aerodynamic stall (no continuous full
stall warning through the rollout). The ACS gives no numeric bank
tolerance for the ~30deg entry, so bank isn't tracked as a hard bust here
-- only the 1,500ft AGL floor, the 180deg heading, and "got slow without
stalling" are graded.
"""
from ..util import heading_diff
from .base import Task

MIN_AGL_FT = 1500.0
ARM_BANK_DEG = 20.0
ARM_VS_FPM = 200.0
TIMEOUT_S = 90.0
ROLLOUT_HEADING_TOL_DEG = 10.0


class ChandelleTask(Task):
    task_id = "chandelle"
    title = "Chandelle"
    acs_ref = "CA.V.C"

    def __init__(self, direction: str = "left"):
        super().__init__()
        assert direction in ("left", "right")
        self.direction = direction
        self._sign = -1.0 if direction == "left" else 1.0
        self._phase = "armed"  # armed -> climbing -> rollout(after 90deg, still climbing) -> done
        self._armed_at = None
        self._started_at = None
        self._entry_heading = None
        self._last_heading = None
        self._cumulative_turn = 0.0
        self._stall_warning_seen = False
        self._max_stall_streak = 0.0

    def instructions(self):
        return (
            f"Establish a {self.direction} climbing turn, ~30deg bank, applying power and "
            "pitch to the 90deg point. Constant-rate rollout from 90deg to 180deg, arriving "
            "just above stall airspeed on the reciprocal heading."
        )

    def update(self, state, dt):
        if self._armed_at is None:
            self._armed_at = state.t

        if self._phase == "armed":
            if state.t - self._armed_at > TIMEOUT_S:
                return self._finish(False, [f"never established a {self.direction} chandelle"])
            if self._sign * state.bank_deg > ARM_BANK_DEG and state.vs_fpm > ARM_VS_FPM:
                self._entry_heading = state.heading_deg
                self._last_heading = state.heading_deg
                self._cumulative_turn = 0.0
                self._started_at = state.t
                self._phase = "climbing"
            return None

        if state.agl_ft < MIN_AGL_FT:
            return self._finish(False, [f"descended below the 1,500 ft AGL floor ({state.agl_ft:.0f} ft AGL)"])

        d = heading_diff(state.heading_deg, self._last_heading)
        self._cumulative_turn += d
        self._last_heading = state.heading_deg

        if state.stall_warning:
            self._max_stall_streak += dt
            if self._max_stall_streak > 1.0:
                self._stall_warning_seen = True
        else:
            self._max_stall_streak = 0.0

        if state.t - self._started_at > TIMEOUT_S:
            return self._finish(False, ["did not complete the rollout in time"])

        if abs(self._cumulative_turn) >= 180.0:
            target_heading = (self._entry_heading + 180.0) % 360.0
            rollout_dev = heading_diff(state.heading_deg, target_heading)
            notes = [f"rolled out {rollout_dev:+.0f}deg from the reciprocal heading (limit +/-10deg)"]
            passed = abs(rollout_dev) <= ROLLOUT_HEADING_TOL_DEG
            if not self._stall_warning_seen:
                notes.append("never got down near stall airspeed by rollout -- ACS wants you close to a stall, not just slow")
                passed = False
            if self._max_stall_streak > 1.0:
                notes.append("stall warning was still sounding at rollout -- you need to arrive just above stall, not stalled")
                passed = False
            return self._finish(passed, notes)
        return None
