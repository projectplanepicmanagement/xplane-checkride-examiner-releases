"""Shared plumbing for examiner Tasks.

`Task` is the root type: it owns a list of ToleranceTrackers and knows how to
turn them into a TaskResult. `HoldTask` adds the common "wait for the pilot
to establish a configuration, then hold reference values within tolerance
for a grading window" pattern used by several tasks (straight-and-level,
climbs, descents, slow flight). Tasks with a more unusual shape (steep
turns, stalls, turns to headings, ground reference, emergency descent)
subclass `Task` directly and implement their own state machine.
"""
from typing import Callable, List, Optional, Tuple

from ..grading import TaskResult, ToleranceTracker
from ..state import FlightState


class Task:
    task_id = "base"
    title = "Base Task"
    acs_ref = ""

    def __init__(self):
        self.trackers: List[ToleranceTracker] = []
        self.finished = False

    def instructions(self) -> str:
        """Examiner instruction shown while the task is active."""
        return ""

    def configure_from_settings(self, settings) -> None:
        """Hook for tasks that use manually-entered per-aircraft values
        X-Plane has no dataref for (e.g. Vx/Vy -- see
        tasks/short_field.py and aircraft_settings.py). No-op by default;
        AppController calls this on every task whenever the loaded
        aircraft (or its saved settings) changes, so it must be safe to
        call at any point in the task's life, not just before it starts."""
        pass

    def blocking_reason(self) -> Optional[str]:
        """Non-None if a required per-aircraft setting (Settings screen)
        hasn't been entered yet, so this task cannot arm/start at all. A
        task that overrides this must also check it at the top of
        `update()` and return None without touching any of its own
        timers/timeouts while blocked -- being stuck on missing
        configuration is never a flying failure, so it must never be able
        to run out an arm-timeout clock. No-op by default; see
        tasks/short_field.py, tasks/vmc_demo.py, tasks/slow_flight.py."""
        return None

    def status_lines(self) -> List[str]:
        """Live per-parameter deviation readouts for the overlay."""
        return [f"{t.spec.label}: {t.last_dev:+.1f}{t.spec.unit}" for t in self.trackers]

    def update(self, state: FlightState, dt: float) -> Optional[TaskResult]:
        raise NotImplementedError

    def _finish(self, passed: bool, extra_notes: Optional[List[str]] = None) -> TaskResult:
        self.finished = True
        notes = [t.bust_reason for t in self.trackers if t.busted and t.bust_reason]
        if extra_notes:
            notes.extend(extra_notes)
        overall = passed and not any(t.busted for t in self.trackers)
        return TaskResult(self.task_id, self.title, overall, notes)


class HoldTask(Task):
    """Wait for `_arm_condition`, capture reference values via `_on_arm`,
    then hold them within tolerance for HOLD_SECONDS before grading."""

    ARM_TIMEOUT_S = 60.0
    HOLD_SECONDS = 25.0

    def __init__(self):
        super().__init__()
        self._phase = "armed"
        self._armed_at: Optional[float] = None
        self._hold_started_at: Optional[float] = None
        self.tracked: List[Tuple[ToleranceTracker, Callable[[FlightState], float]]] = []

    def _arm_condition(self, state: FlightState) -> bool:
        raise NotImplementedError

    def _on_arm(self, state: FlightState) -> None:
        """Populate self.tracked with (tracker, getter) pairs."""
        raise NotImplementedError

    def _tick_extra(self, state: FlightState, dt: float) -> Optional[TaskResult]:
        """Hook for a hard safety check run every tick. Return a TaskResult
        to force-finish the task (e.g. an ACS floor was busted), else None."""
        return None

    def _extra_finish_notes(self, state: FlightState) -> List[str]:
        return []

    def update(self, state: FlightState, dt: float) -> Optional[TaskResult]:
        forced = self._tick_extra(state, dt)
        if forced is not None:
            return forced

        if self._phase == "armed":
            if self.blocking_reason() is not None:
                return None  # waiting on Settings -- the arm-timeout clock must not run
            if self._armed_at is None:
                self._armed_at = state.t
            if state.t - self._armed_at > self.ARM_TIMEOUT_S:
                return self._finish(False, ["did not establish the required setup in time"])
            if self._arm_condition(state):
                self._on_arm(state)
                self.trackers = [t for t, _ in self.tracked]
                self._phase = "holding"
                self._hold_started_at = state.t
            return None

        for tracker, getter in self.tracked:
            tracker.update(getter(state), dt)

        if state.t - self._hold_started_at >= self.HOLD_SECONDS:
            return self._finish(True, self._extra_finish_notes(state))
        return None
