"""PA.VIII.B/C (Private) / CA.VII.B/C (Commercial) Power-Off and Power-On
Stalls (wings-level entries).

ACS: complete no lower than 1,500 ft AGL; heading +/-10deg; recovers after
a full stall. Private (FAA-S-ACS-6) bank tolerance is +/-10deg; Commercial
(FAA-S-ACS-7B) is tighter, +/-5deg, and requires power-on stall setup at
>=65% power specifically (Private just says "at or below 65%" as a
config hint, not a graded threshold) -- `_StallTaskBase` holds the shared
state machine, the Commercial subclasses override `BANK_TOL_DEG` and
`_config_ok`.

A "full stall" is approximated here as the stall warning sounding
continuously for >= 2 seconds (rather than modeling angle-of-attack /
critical AoA directly, which would need aircraft-specific data). Altitude
lost during recovery is reported for the pilot's awareness; neither ACS
codifies a specific numeric loss limit here, so it is advisory rather than
a hard bust.
"""
from ..grading import ToleranceSpec, ToleranceTracker
from ..util import heading_diff
from .base import Task

MIN_AGL_FT = 1500.0
SUSTAINED_WARNING_S = 2.0
RECOVERY_CLEAR_S = 2.0
ARM_TIMEOUT_S = 150.0
ADVISORY_LOSS_FT = 300.0


class _StallTaskBase(Task):
    BANK_TOL_DEG = 10.0

    def __init__(self):
        super().__init__()
        self._phase = "setup"  # setup -> recovering
        self._warning_streak = 0.0
        self._clear_streak = 0.0
        self._entry_heading = None
        self._stall_alt = None
        self._min_alt_seen = None
        self._setup_started_at = None

    def _config_ok(self, state) -> bool:
        raise NotImplementedError

    def _config_hint(self) -> str:
        raise NotImplementedError

    def instructions(self):
        return (
            f"{self._config_hint()} Hold heading through the break, then recover "
            "promptly: reduce angle of attack, add power, level the wings, climb back."
        )

    def update(self, state, dt):
        if self._setup_started_at is None:
            self._setup_started_at = state.t

        if state.agl_ft < MIN_AGL_FT:
            return self._finish(False, [f"descended below the 1,500 ft AGL floor ({state.agl_ft:.0f} ft AGL)"])

        if self._phase == "setup":
            if state.t - self._setup_started_at > ARM_TIMEOUT_S:
                return self._finish(False, ["did not reach a full stall in the required configuration"])
            if state.stall_warning:
                self._warning_streak += dt
            else:
                self._warning_streak = 0.0
            if self._warning_streak >= SUSTAINED_WARNING_S and self._config_ok(state):
                self._entry_heading = state.heading_deg
                self._stall_alt = state.indicated_alt_ft
                self._min_alt_seen = state.indicated_alt_ft
                hdg_t = ToleranceTracker(ToleranceSpec.symmetric("Heading", "deg", self._entry_heading, 10.0), diff_fn=heading_diff)
                bank_t = ToleranceTracker(ToleranceSpec.symmetric("Bank", "deg", 0.0, self.BANK_TOL_DEG))
                self.trackers = [hdg_t, bank_t]
                self._phase = "recovering"
            return None

        self._min_alt_seen = min(self._min_alt_seen, state.indicated_alt_ft)
        self.trackers[0].update(state.heading_deg, dt)
        self.trackers[1].update(state.bank_deg, dt)

        if not state.stall_warning:
            self._clear_streak += dt
        else:
            self._clear_streak = 0.0

        recovered = (
            self._clear_streak >= RECOVERY_CLEAR_S
            and state.vs_fpm > 0.0
            and abs(state.bank_deg) < 15.0
        )
        if recovered:
            loss = self._stall_alt - self._min_alt_seen
            notes = [f"altitude lost during recovery: {loss:.0f} ft"]
            if loss > ADVISORY_LOSS_FT:
                notes.append("that loss is on the high side for a prompt recovery -- review technique with your instructor")
            return self._finish(True, notes)
        return None


class PowerOffStallTask(_StallTaskBase):
    task_id = "power_off_stall"
    title = "Power-Off Stall"
    acs_ref = "PA.VIII.B"

    def _config_ok(self, state):
        return state.throttle_ratio < 0.15

    def _config_hint(self):
        return "Configure for a power-off stall: idle power, flaps as briefed, stabilized descent."


class PowerOnStallTask(_StallTaskBase):
    task_id = "power_on_stall"
    title = "Power-On Stall"
    acs_ref = "PA.VIII.C"

    def _config_ok(self, state):
        return state.throttle_ratio > 0.5

    def _config_hint(self):
        return "Configure for a power-on stall: takeoff/departure config, power at or below 65% as briefed."


class CommercialPowerOffStallTask(PowerOffStallTask):
    task_id = "commercial_power_off_stall"
    title = "Power-Off Stall (Commercial)"
    acs_ref = "CA.VII.B"
    BANK_TOL_DEG = 5.0


class CommercialPowerOnStallTask(_StallTaskBase):
    task_id = "commercial_power_on_stall"
    title = "Power-On Stall (Commercial)"
    acs_ref = "CA.VII.C"
    BANK_TOL_DEG = 5.0

    def _config_ok(self, state):
        return state.throttle_ratio >= 0.65

    def _config_hint(self):
        return "Configure for a power-on stall: takeoff/departure config, power at no less than 65%."
