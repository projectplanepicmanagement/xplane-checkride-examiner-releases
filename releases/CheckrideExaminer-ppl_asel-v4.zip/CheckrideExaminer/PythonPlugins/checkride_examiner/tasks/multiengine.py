"""PA.IX.F / CA.IX.F Engine Failure After Liftoff (Simulated), and
PA.X.A+C / CA.X.A+C Maneuvering (incl. solely by reference to instruments)
with One Engine Inoperative (AMEL, AMES).

ACS: identical numbers for Private (FAA-S-ACS-6) and Commercial
(FAA-S-ACS-7B) on both tasks, so one parameterized class serves both
ratings rather than duplicating the state machine (only `acs_ref` differs).

- Engine Failure After Liftoff (.IX.F.S9): heading +/-10deg, airspeed
  +/-5kt of the speed established once stabilized after the failure (the
  ACS wants Vyse specifically, but that's an aircraft-specific POH number
  this build doesn't know -- like the other "established speed" tasks,
  whatever the pilot settles on a few seconds after simulating the failure
  becomes the target).
- Maneuvering with One Engine Inoperative (.X.A.S7 / .X.C.S7, identical):
  altitude +/-100ft (or minimum sink rate, not graded here), airspeed
  +/-10kt, selected headings +/-10deg. The ACS splits this into a visual
  task (X.A) and an instrument (hood-on) task (X.C) with the SAME numeric
  standard -- this build can't detect hood use, so one task covers both.

Both tasks arm on asymmetric power: one engine's throttle near idle while
the other is producing meaningful power, i.e. a simulated engine failure
(or an actual feathered/shut-down engine). `throttle2_ratio` is 0 on a
single-engine aircraft, so neither task can ever arm there.
"""
from ..grading import ToleranceSpec, ToleranceTracker
from ..util import heading_diff
from .base import HoldTask, Task

IDLE_THROTTLE = 0.15
OPERATING_THROTTLE = 0.5
STABILIZE_S = 5.0
TIMEOUT_S = 150.0


def _asymmetric_power(state) -> bool:
    lo, hi = sorted((state.throttle_ratio, state.throttle2_ratio))
    return lo < IDLE_THROTTLE and hi > OPERATING_THROTTLE


class EngineFailureAfterLiftoffTask(Task):
    task_id = "engine_failure_after_liftoff"
    title = "Engine Failure After Liftoff"

    def __init__(self, acs_ref: str = "PA.IX.F"):
        super().__init__()
        self.acs_ref = acs_ref
        self._phase = "armed"  # armed -> stabilizing -> holding
        self._armed_at = None
        self._stabilize_started_at = None
        self._hold_started_at = None
        self._entry_heading = None
        self._hdg_t = None
        self._ias_t = None

    def instructions(self):
        if self._phase == "holding":
            return "Single-engine climb established. Hold heading and airspeed."
        return (
            "Simulated engine failure after liftoff: identify the dead engine, "
            "feather (simulated), clean up drag, and establish a single-engine "
            "climb attitude."
        )

    def update(self, state, dt):
        if self._armed_at is None:
            self._armed_at = state.t
        if state.t - self._armed_at > TIMEOUT_S:
            return self._finish(False, ["never established a single-engine climb after the simulated failure"])

        if self._phase == "armed":
            if _asymmetric_power(state):
                self._entry_heading = state.heading_deg
                self._stabilize_started_at = state.t
                self._phase = "stabilizing"
            return None

        if not _asymmetric_power(state):
            # engine "restored" before we finished grading -- back to armed
            self._phase = "armed"
            self._armed_at = state.t
            return None

        if self._phase == "stabilizing":
            if state.t - self._stabilize_started_at >= STABILIZE_S:
                self._hdg_t = ToleranceTracker(ToleranceSpec.symmetric("Heading", "deg", self._entry_heading, 10.0), diff_fn=heading_diff)
                self._ias_t = ToleranceTracker(ToleranceSpec.symmetric("Airspeed", "kt", state.ias_kt, 5.0))
                self.trackers = [self._hdg_t, self._ias_t]
                self._hold_started_at = state.t
                self._phase = "holding"
            return None

        self._hdg_t.update(state.heading_deg, dt)
        self._ias_t.update(state.ias_kt, dt)
        if state.t - self._hold_started_at >= 20.0:
            return self._finish(True, [])
        return None


class ManeuveringOneEngineInoperativeTask(HoldTask):
    task_id = "maneuvering_one_engine_inoperative"
    title = "Maneuvering with One Engine Inoperative"
    HOLD_SECONDS = 25.0
    ARM_TIMEOUT_S = TIMEOUT_S

    def __init__(self, acs_ref: str = "PA.X.A"):
        super().__init__()
        self.acs_ref = acs_ref

    def instructions(self):
        return (
            "With one engine simulated inoperative (feathered), maintain "
            "altitude, airspeed, and heading."
        )

    def _arm_condition(self, state):
        return _asymmetric_power(state) and abs(state.vs_fpm) < 200.0 and abs(state.bank_deg) < 20.0

    def _on_arm(self, state):
        alt_t = ToleranceTracker(ToleranceSpec.symmetric("Altitude", "ft", state.indicated_alt_ft, 100.0))
        ias_t = ToleranceTracker(ToleranceSpec.symmetric("Airspeed", "kt", state.ias_kt, 10.0))
        hdg_t = ToleranceTracker(ToleranceSpec.symmetric("Heading", "deg", state.heading_deg, 10.0), diff_fn=heading_diff)
        self.tracked = [
            (alt_t, lambda s: s.indicated_alt_ft),
            (ias_t, lambda s: s.ias_kt),
            (hdg_t, lambda s: s.heading_deg),
        ]
