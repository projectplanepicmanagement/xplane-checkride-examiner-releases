"""Ground-phase checkpoints: taxi, before-takeoff run-up.

Neither is a numeric ACS task the way Steep Turns or a stall are -- the ACS
grades Preflight Procedures qualitatively (correct checklist/procedure
use), which isn't something a flight-data plugin can verify. (ATC calls are
handled separately, as multiple-choice questions -- see tasks/quiz.py --
since there's no dataref for "did the pilot say the right words".) These
are honest best-effort substitutes:

- TaxiTask tracks max taxi speed as an advisory note (the ACS sets no hard
  numeric taxi speed limit).
- RunUpTask confirms run-up power was set and returned to idle, and flags
  low oil pressure during the hold. It does NOT verify magneto drop/split or
  carb-heat RPM drop -- there's no reliable generic dataref for magneto
  switch position across aircraft, so keep doing those checks yourself.
"""
from .base import Task

TAXI_ARM_SPEED_KT = 2.0
TAXI_STOP_SPEED_KT = 1.0
TAXI_STOP_HOLD_S = 3.0
TAXI_FAST_KT = 25.0
TAXI_TIMEOUT_S = 600.0

RUNUP_ARM_RPM = 1500.0
RUNUP_IDLE_RPM = 1000.0
RUNUP_HOLD_S = 10.0
RUNUP_MIN_OIL_PRESS_PSI = 10.0
RUNUP_TIMEOUT_S = 300.0


class TaxiTask(Task):
    task_id = "taxi"
    title = "Taxi"
    acs_ref = "PA.III (procedural)"

    def __init__(self):
        super().__init__()
        self._started_at = None
        self._moving = False
        self._stopped_streak = 0.0
        self._max_speed = 0.0

    def instructions(self):
        return "Taxi to the runway (or run-up area), controlling speed and direction with brakes and rudder."

    def update(self, state, dt):
        if self._started_at is None:
            self._started_at = state.t
        if not state.on_ground:
            return self._finish(True, ["became airborne before completing this checkpoint"])
        if state.t - self._started_at > TAXI_TIMEOUT_S:
            return self._finish(True, ["taxi not observed in time -- skipping"])

        if not self._moving:
            if state.groundspeed_kt > TAXI_ARM_SPEED_KT:
                self._moving = True
            return None

        self._max_speed = max(self._max_speed, state.groundspeed_kt)
        if state.groundspeed_kt < TAXI_STOP_SPEED_KT:
            self._stopped_streak += dt
        else:
            self._stopped_streak = 0.0

        if self._stopped_streak >= TAXI_STOP_HOLD_S:
            notes = [f"max taxi speed: {self._max_speed:.0f} kt"]
            if self._max_speed > TAXI_FAST_KT:
                notes.append("that's brisk for a taxi -- aim for walking pace, slower still in turns")
            return self._finish(True, notes)
        return None


class RunUpTask(Task):
    task_id = "before_takeoff_runup"
    title = "Before-Takeoff Run-Up"
    acs_ref = "PA.II (procedural)"

    def __init__(self):
        super().__init__()
        self._phase = "setup"
        self._started_at = None
        self._elevated_time = 0.0
        self._low_oil_seen = False

    def instructions(self):
        return (
            "Hold the brakes, set ~1,700 RPM, and run through your check: "
            "magnetos (drop and split within limits), carb heat, engine "
            "instruments in the green, then back to idle."
        )

    def update(self, state, dt):
        if self._started_at is None:
            self._started_at = state.t
        if state.t - self._started_at > RUNUP_TIMEOUT_S:
            return self._finish(True, ["run-up not observed in time -- skipping"])

        if self._phase == "setup":
            if state.on_ground and state.engine_rpm > RUNUP_ARM_RPM:
                self._phase = "holding"
                self._elevated_time = 0.0
                self._low_oil_seen = False
            return None

        if state.engine_rpm > RUNUP_ARM_RPM:
            self._elevated_time += dt
            if state.oil_press_psi < RUNUP_MIN_OIL_PRESS_PSI:
                self._low_oil_seen = True

        if state.engine_rpm < RUNUP_IDLE_RPM:
            if self._elevated_time >= RUNUP_HOLD_S:
                notes = []
                if self._low_oil_seen:
                    notes.append(f"oil pressure dropped below {RUNUP_MIN_OIL_PRESS_PSI:.0f} psi during the run-up -- check before flight")
                return self._finish(True, notes or ["run-up power set and returned to idle"])
            self._phase = "setup"  # backed off before holding long enough; wait to try again
        return None
