"""IR.III.B Holding Procedures.

ACS (FAA-S-ACS-8C, IR.III.B.S4): airspeed +/-10kt, altitude +/-100ft,
selected headings +/-10deg, track within 3/4-scale CDI deflection.

Modeled as one complete holding circuit (360deg of net heading change)
around the tuned station, tracking altitude/airspeed/CDI throughout.
Entry-procedure type (direct/teardrop/parallel) and leg timing aren't
graded -- neither is directly observable from flight data alone -- and
heading isn't tracked against a fixed target since it necessarily changes
across the inbound leg, the turn, and the outbound leg of a real pattern.
"""
from ..grading import ToleranceSpec, ToleranceTracker
from ..util import heading_diff
from .base import Task

ARM_BANK_DEG = 20.0
CDI_TOLERANCE_DOTS = 1.5
TIMEOUT_S = 360.0


class HoldingTask(Task):
    task_id = "holding"
    title = "Holding Procedure"
    acs_ref = "IR.III.B"

    def __init__(self):
        super().__init__()
        self._phase = "armed"
        self._armed_at = None
        self._started_at = None
        self._last_heading = None
        self._cumulative_turn = 0.0
        self._alt_t = None
        self._ias_t = None
        self._cdi_t = None

    def instructions(self):
        return (
            "Enter and fly the holding pattern at the selected fix. Maintain "
            "altitude and airspeed, and track the inbound course."
        )

    def update(self, state, dt):
        if self._armed_at is None:
            self._armed_at = state.t

        if self._phase == "armed":
            if state.t - self._armed_at > TIMEOUT_S:
                return self._finish(False, ["never established in the holding pattern"])
            if abs(state.bank_deg) > ARM_BANK_DEG:
                self._last_heading = state.heading_deg
                self._cumulative_turn = 0.0
                self._started_at = state.t
                self._alt_t = ToleranceTracker(ToleranceSpec.symmetric("Altitude", "ft", state.indicated_alt_ft, 100.0))
                self._ias_t = ToleranceTracker(ToleranceSpec.symmetric("Airspeed", "kt", state.ias_kt, 10.0))
                self._cdi_t = ToleranceTracker(ToleranceSpec.symmetric("CDI", "dots", 0.0, CDI_TOLERANCE_DOTS))
                self.trackers = [self._alt_t, self._ias_t, self._cdi_t]
                self._phase = "holding"
            return None

        d = heading_diff(state.heading_deg, self._last_heading)
        self._cumulative_turn += d
        self._last_heading = state.heading_deg
        self._alt_t.update(state.indicated_alt_ft, dt)
        self._ias_t.update(state.ias_kt, dt)
        self._cdi_t.update(state.nav1_hdef_dots, dt)

        if state.t - self._started_at > TIMEOUT_S:
            return self._finish(False, ["did not complete a full holding circuit in time"])

        if abs(self._cumulative_turn) >= 360.0:
            return self._finish(True, [])
        return None
