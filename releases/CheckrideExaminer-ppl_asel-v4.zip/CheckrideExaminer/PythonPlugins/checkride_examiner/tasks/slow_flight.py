"""PA.VIII.A (Private) / CA.VII.A (Commercial) Maneuvering During Slow Flight.

ACS: >1,500 ft AGL throughout; airspeed established just above stall
warning. Private (FAA-S-ACS-6): altitude +/-100 ft; heading +/-10deg;
airspeed +10/-0kt; bank +/-10deg. Commercial (FAA-S-ACS-7B) is tighter:
altitude +/-50 ft; heading +/-10deg; airspeed +5/-0kt; bank +/-5deg --
`SlowFlightTask` holds the shared state machine, `CommercialSlowFlightTask`
just overrides the tolerance class attributes.

The HOLD tolerance is correctly self-referential (ACS: "+10/-0kt" *of the
speed you establish*, same as Straight-and-Level's altitude/heading) --
that doesn't need a real number from anywhere. What used to be missing was
a way to tell "you've actually gotten slow enough to start" from "you're
just flying level at cruise speed": X-Plane has no MCA dataref (same gap as
Vx/Vy -- see short_field.py), and gating on the stall-warning horn having
already sounded (an earlier version of this task) made it borderline
impossible to even arm on some aircraft, since different add-ons model the
horn's onset AoA differently. A Vso-based heuristic replaced that, but a
flight school's actual target MCA speed can differ from any fixed
multiplier of Vso -- so this now requires a real per-aircraft target speed
entered in Settings (`configure_from_settings`) and refuses to arm at all
without one (`blocking_reason`), same policy as short_field.py's Vx/Vy.
"""
from ..grading import ToleranceSpec, ToleranceTracker
from ..util import heading_diff
from .base import HoldTask

MIN_AGL_FT = 1500.0


class SlowFlightTask(HoldTask):
    task_id = "slow_flight"
    title = "Maneuvering During Slow Flight"
    acs_ref = "PA.VIII.A"
    ARM_TIMEOUT_S = 150.0
    HOLD_SECONDS = 30.0

    ALT_TOL_FT = 100.0
    HDG_TOL_DEG = 10.0
    IAS_HIGH_KT = 10.0
    BANK_TOL_DEG = 10.0

    def __init__(self):
        super().__init__()
        self._target_kt = 0.0  # 0 = not registered for this aircraft
        self._heard_stall_warning = False

    def configure_from_settings(self, settings) -> None:
        self._target_kt = settings.slow_flight_kt

    def blocking_reason(self):
        if self._target_kt <= 0.0:
            return (
                "This aircraft's Slow Flight target airspeed isn't set yet. Open "
                "Settings and enter it (an MCA speed just above stall, per your "
                "flight school/POH) before starting."
            )
        return None

    def instructions(self):
        return (
            f"Slow to about {self._target_kt:.0f}kt (just above stall warning, horn "
            "intermittent). Stay above 1,500 ft AGL and hold altitude, heading, and bank."
        )

    def _tick_extra(self, state, dt):
        if state.agl_ft < MIN_AGL_FT:
            return self._finish(False, [f"descended below the 1,500 ft AGL floor ({state.agl_ft:.0f} ft AGL)"])
        if state.stall_warning:
            self._heard_stall_warning = True
        return None

    def _arm_condition(self, state):
        stabilized = abs(state.vs_fpm) < 150.0 and abs(state.bank_deg) < 15.0
        return stabilized and state.ias_kt <= self._target_kt

    def _on_arm(self, state):
        alt_t = ToleranceTracker(ToleranceSpec.symmetric("Altitude", "ft", state.indicated_alt_ft, self.ALT_TOL_FT))
        hdg_t = ToleranceTracker(ToleranceSpec.symmetric("Heading", "deg", state.heading_deg, self.HDG_TOL_DEG), diff_fn=heading_diff)
        ias_t = ToleranceTracker(ToleranceSpec("Airspeed", "kt", state.ias_kt, 0.0, self.IAS_HIGH_KT))
        bank_t = ToleranceTracker(ToleranceSpec.symmetric("Bank", "deg", 0.0, self.BANK_TOL_DEG))
        self.tracked = [
            (alt_t, lambda s: s.indicated_alt_ft),
            (hdg_t, lambda s: s.heading_deg),
            (ias_t, lambda s: s.ias_kt),
            (bank_t, lambda s: s.bank_deg),
        ]

    def _extra_finish_notes(self, state):
        if not self._heard_stall_warning:
            return [
                "stall warning horn never sounded during this attempt -- flown a "
                "touch fast for true slow flight (advisory only: this aircraft's "
                "warning onset may not line up with the registered target speed)"
            ]
        return []


class CommercialSlowFlightTask(SlowFlightTask):
    task_id = "commercial_slow_flight"
    title = "Maneuvering During Slow Flight (Commercial)"
    acs_ref = "CA.VII.A"

    ALT_TOL_FT = 50.0
    IAS_HIGH_KT = 5.0
    BANK_TOL_DEG = 5.0
