"""IR.VI.C Missed Approach.

ACS (FAA-S-ACS-8C, IR.VI.C.S3/S7): airspeed +/-10kt (accelerating to it
after the go-around), heading/course/bearing +/-10deg, altitude(s) +/-100ft
during the procedure. This build doesn't know the published missed-approach
procedure or its step-up altitudes, so it grades holding a heading and an
airspeed after a go-around is initiated (full power + positive climb), not
compliance with a specific published track.
"""
from ..grading import ToleranceSpec, ToleranceTracker
from ..util import heading_diff
from .base import HoldTask

ARM_THROTTLE = 0.85
ARM_VS_FPM = 200.0


class MissedApproachTask(HoldTask):
    task_id = "missed_approach"
    title = "Missed Approach"
    acs_ref = "IR.VI.C"
    HOLD_SECONDS = 25.0
    ARM_TIMEOUT_S = 120.0

    def instructions(self):
        return "Go around: full power, positive rate, configure, and climb on the missed approach heading."

    def _arm_condition(self, state):
        return state.throttle_ratio > ARM_THROTTLE and state.vs_fpm > ARM_VS_FPM

    def _on_arm(self, state):
        hdg_t = ToleranceTracker(ToleranceSpec.symmetric("Heading", "deg", state.heading_deg, 10.0), diff_fn=heading_diff)
        ias_t = ToleranceTracker(ToleranceSpec.symmetric("Airspeed", "kt", state.ias_kt, 10.0))
        self.tracked = [
            (hdg_t, lambda s: s.heading_deg),
            (ias_t, lambda s: s.ias_kt),
        ]
