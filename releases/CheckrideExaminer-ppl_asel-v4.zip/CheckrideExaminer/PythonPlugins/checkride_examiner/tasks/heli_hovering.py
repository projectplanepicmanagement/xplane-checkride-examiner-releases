"""PH.II.C Powerplant Starting and Rotor Engagement (ground-phase procedural
checkpoint) and PH.IV.A/B Hovering Maneuvers (Vertical Takeoff and Landing,
Hover Taxi).

ACS numbers (FAA-S-ACS-15): hovering altitude tolerance is +/-1/2 of the
recommended hovering altitude within 10 ft of the surface, or a flat +/-5 ft
above that (PH.IV.A.S5, PH.IV.B.S7); position within 4 ft of a designated
point or ground track (PH.IV.A.S6/S7, PH.IV.B.S6); heading +/-10 deg
(PH.IV.A.S8). Rotor engagement itself (PH.II.C) is graded qualitatively by
the ACS, not numerically -- same "best-effort procedural substitute" caveat
as tasks/ground_ops.py's Taxi/Run-Up tasks.
"""
import math

from ..grading import ToleranceSpec, ToleranceTracker
from ..util import heading_diff, local_xy_ft
from .base import Task

# Real main rotor operating RPMs vary widely by type (Robinson R22 ~530,
# R44 ~453, Bell 206 ~394) and there's no generic "normal" number, so this
# just confirms the rotor is spinning at an operating speed, not stopped or
# barely turning over.
ROTOR_ENGAGED_RPM = 200.0
ROTOR_ENGAGE_HOLD_S = 5.0
ROTOR_ENGAGE_TIMEOUT_S = 300.0

HOVER_ARM_MAX_AGL_FT = 25.0
HOVER_ARM_MAX_GS_KT = 3.0
HOVER_ARM_MAX_VS_FPM = 100.0
HOVER_HOLD_S = 15.0
HOVER_TIMEOUT_S = 60.0
HOVER_POSITION_TOL_FT = 4.0
HOVER_HEADING_TOL_DEG = 10.0
LANDING_TIMEOUT_S = 60.0
LANDING_POSITION_TOL_FT = 4.0

HOVER_TAXI_MAX_GS_KT = 20.0
HOVER_TAXI_MIN_GS_KT = 1.0
HOVER_TAXI_TRACK_TOL_FT = 4.0
HOVER_TAXI_HOLD_S = 20.0
HOVER_TAXI_TIMEOUT_S = 60.0


def _hover_alt_tolerance(reference_ft: float) -> float:
    """ACS: +/-1/2 the recommended hovering altitude within 10 ft of the
    surface, or a flat +/-5 ft above that."""
    if reference_ft <= 10.0:
        return max(0.5 * reference_ft, 1.0)
    return 5.0


class RotorEngagementTask(Task):
    task_id = "heli_rotor_engagement"
    title = "Powerplant Starting and Rotor Engagement"
    acs_ref = "PH.II.C (procedural)"

    def __init__(self):
        super().__init__()
        self._started_at = None
        self._engaged_streak = 0.0

    def instructions(self):
        return "Start the engine and engage the rotor system, bringing main rotor RPM up to a normal operating speed."

    def update(self, state, dt):
        if self._started_at is None:
            self._started_at = state.t
        if state.t - self._started_at > ROTOR_ENGAGE_TIMEOUT_S:
            return self._finish(True, ["rotor engagement not observed in time -- skipping"])

        if state.rotor_rpm > ROTOR_ENGAGED_RPM:
            self._engaged_streak += dt
        else:
            self._engaged_streak = 0.0

        if self._engaged_streak >= ROTOR_ENGAGE_HOLD_S:
            return self._finish(True, [f"main rotor up and stable above {ROTOR_ENGAGED_RPM:.0f} RPM"])
        return None


class VerticalTakeoffLandingTask(Task):
    task_id = "heli_vertical_takeoff_landing"
    title = "Vertical Takeoff and Landing"
    acs_ref = "PH.IV.A"

    def __init__(self):
        super().__init__()
        self._phase = "armed"
        self._armed_at = None
        self._hold_started_at = None
        self._ref_lat = None
        self._ref_lon = None
        self._ref_alt = None
        self._alt_tol = None
        self._landing_started_at = None

    def instructions(self):
        if self._phase == "armed":
            return "Make a vertical takeoff to a stationary hover at a normal hovering altitude."
        if self._phase == "hover":
            return "Hold your hover: position, altitude, and heading."
        return "Descend vertically back to your takeoff point."

    def update(self, state, dt):
        if self._phase == "armed":
            if self._armed_at is None:
                self._armed_at = state.t
            if state.t - self._armed_at > HOVER_TIMEOUT_S:
                return self._finish(False, ["never established a stationary hover"])
            established = (
                not state.on_ground
                and state.agl_ft < HOVER_ARM_MAX_AGL_FT
                and state.groundspeed_kt < HOVER_ARM_MAX_GS_KT
                and abs(state.vs_fpm) < HOVER_ARM_MAX_VS_FPM
            )
            if established:
                self._ref_lat, self._ref_lon = state.lat, state.lon
                self._ref_alt = state.agl_ft
                self._alt_tol = _hover_alt_tolerance(self._ref_alt)
                pos_t = ToleranceTracker(ToleranceSpec("Position", "ft", 0.0, -HOVER_POSITION_TOL_FT, HOVER_POSITION_TOL_FT))
                alt_t = ToleranceTracker(ToleranceSpec("Altitude", "ft", self._ref_alt, -self._alt_tol, self._alt_tol))
                hdg_t = ToleranceTracker(
                    ToleranceSpec.symmetric("Heading", "deg", state.heading_deg, HOVER_HEADING_TOL_DEG),
                    diff_fn=heading_diff,
                )
                self.trackers = [pos_t, alt_t, hdg_t]
                self._phase = "hover"
                self._hold_started_at = state.t
            return None

        if self._phase == "hover":
            x, y = local_xy_ft(state.lat, state.lon, self._ref_lat, self._ref_lon)
            self.trackers[0].update(math.hypot(x, y), dt)
            self.trackers[1].update(state.agl_ft, dt)
            self.trackers[2].update(state.heading_deg, dt)
            if state.t - self._hold_started_at >= HOVER_HOLD_S:
                self._phase = "landing"
                self._landing_started_at = state.t
            return None

        # phase == "landing"
        if state.t - self._landing_started_at > LANDING_TIMEOUT_S:
            return self._finish(False, ["did not complete the vertical landing in time"])
        if state.on_ground:
            x, y = local_xy_ft(state.lat, state.lon, self._ref_lat, self._ref_lon)
            radius = math.hypot(x, y)
            passed = radius <= LANDING_POSITION_TOL_FT
            notes = [f"touched down {radius:.0f} ft from the takeoff point (limit {LANDING_POSITION_TOL_FT:.0f} ft)"]
            return self._finish(passed, notes)
        return None


class HoverTaxiTask(Task):
    task_id = "heli_hover_taxi"
    title = "Hover Taxi"
    acs_ref = "PH.IV.B"

    def __init__(self):
        super().__init__()
        self._armed_at = None
        self._started_at = None
        self._ref_lat = None
        self._ref_lon = None
        self._ref_heading = None
        self._ref_alt = None
        self._alt_tol = None

    def instructions(self):
        return "Hover-taxi in a straight line, maintaining ground track, altitude, and heading."

    def update(self, state, dt):
        if self._armed_at is None:
            self._armed_at = state.t

        if self._started_at is None:
            if state.t - self._armed_at > HOVER_TAXI_TIMEOUT_S:
                return self._finish(False, ["never established a hover taxi"])
            if (
                not state.on_ground
                and state.agl_ft < HOVER_ARM_MAX_AGL_FT
                and HOVER_TAXI_MIN_GS_KT <= state.groundspeed_kt <= HOVER_TAXI_MAX_GS_KT
            ):
                self._ref_lat, self._ref_lon = state.lat, state.lon
                self._ref_heading = state.heading_deg
                self._ref_alt = state.agl_ft
                self._alt_tol = _hover_alt_tolerance(self._ref_alt)
                track_t = ToleranceTracker(ToleranceSpec("Ground track", "ft", 0.0, -HOVER_TAXI_TRACK_TOL_FT, HOVER_TAXI_TRACK_TOL_FT))
                alt_t = ToleranceTracker(ToleranceSpec("Altitude", "ft", self._ref_alt, -self._alt_tol, self._alt_tol))
                hdg_t = ToleranceTracker(
                    ToleranceSpec.symmetric("Heading", "deg", self._ref_heading, HOVER_HEADING_TOL_DEG),
                    diff_fn=heading_diff,
                )
                self.trackers = [track_t, alt_t, hdg_t]
                self._started_at = state.t
            return None

        if state.on_ground:
            return self._finish(False, ["touched down before completing the hover taxi"])

        x, y = local_xy_ft(state.lat, state.lon, self._ref_lat, self._ref_lon)
        hdg_rad = math.radians(self._ref_heading)
        lateral = x * math.cos(hdg_rad) - y * math.sin(hdg_rad)
        self.trackers[0].update(lateral, dt)
        self.trackers[1].update(state.agl_ft, dt)
        self.trackers[2].update(state.heading_deg, dt)

        if state.t - self._started_at >= HOVER_TAXI_HOLD_S:
            return self._finish(True)
        return None
