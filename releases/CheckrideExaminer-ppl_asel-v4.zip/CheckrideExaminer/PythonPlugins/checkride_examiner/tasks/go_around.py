"""PA.IV.N (Private) / CA.IV.N (Commercial) Go-Around/Rejected Landing.

ACS: from an approach configuration, apply full power promptly, establish
a climb at Vx or Vy and maintain it (+10/-5kt Private, +/-5kt Commercial --
confirmed via cfi.treklog.com's task-by-task ACS summary and a second,
independent WebSearch-verified excerpt; one earlier secondary-source
comparison table had Commercial's Go-Around left un-tightened at +10/-5,
but two other sources agree it IS tightened to +/-5kt, matching the
Commercial-tightens-almost-everything pattern used throughout this
package, so that table's row is treated as the outlier), and maintain
runway heading or as assigned. This build always targets Vy (reusing
AircraftSettings.vy_kt, mandatory -- same reasoning as every other
takeoff/climb task here, see tasks/normal_landing.py / tasks/soft_field.py
/ tasks/short_field.py) since the ACS lets the examiner pick either.

Unlike every other Area IV task, this one needs no runway/landing-point
data at all -- it's graded entirely on the power-up/climb transition and
the resulting airspeed/heading hold, so there's none of the "not
implemented, needs ground-proximity data" limitation the full
takeoff/landing tasks have for touchdown-point accuracy.

**The Vy airspeed check is capture-gated** (`ToleranceTracker(...,
gate_until_captured=True)`, grading.py), same fix applied to every other
takeoff/climb task's Vx/Vy tracker (see tasks/short_field.py's module
docstring for the full writeup) -- arming happens at approach speed (by
definition slower than Vy), and accelerating up to Vy during the climb
isn't instant, so grading from the moment of arming could bust before the
aircraft had a chance to get there. `update()` only counts deviation time
once IAS has actually entered the Vy band at least once.
"""
from ..grading import ToleranceSpec, ToleranceTracker
from ..util import heading_diff
from .base import Task

APPROACH_ARM_VS_FPM = -100.0
GO_AROUND_POWER_THRESHOLD = 0.7  # throttle_ratio -- "the go-around decision has been made"
HDG_TOL_DEG = 10.0
CLIMB_HOLD_S = 15.0
TIMEOUT_S = 90.0


class GoAroundTask(Task):
    task_id = "go_around"
    title = "Go-Around/Rejected Landing"

    def __init__(self, acs_ref: str = "PA.IV.N", tolerance_low: float = -5.0, tolerance_high: float = 10.0):
        super().__init__()
        self.acs_ref = acs_ref
        self._tol_low = tolerance_low
        self._tol_high = tolerance_high
        self._vy_kt = 0.0  # 0 = not registered for this aircraft
        self._phase = "approach"
        self._started_at = None
        self._hdg_t = None
        self._vy_t = None
        self._climb_started_at = None

    def configure_from_settings(self, settings) -> None:
        self._vy_kt = settings.vy_kt

    def blocking_reason(self):
        if self._vy_kt <= 0.0:
            return "This aircraft's Vy isn't set yet. Open Settings and enter it before starting Go-Around."
        return None

    def instructions(self):
        if self._phase == "approach":
            return "Simulated rejected landing: on approach, decide to go around and apply full power promptly."
        return f"Climb at Vy ({self._vy_kt:.0f}kt) and maintain runway heading."

    def update(self, state, dt):
        if self.blocking_reason() is not None:
            return None  # waiting on Settings -- no timer running

        if self._started_at is None:
            self._started_at = state.t
        if state.t - self._started_at > TIMEOUT_S:
            return self._finish(False, ["never applied go-around power in time"])

        if self._phase == "approach":
            if not state.on_ground and state.throttle_ratio > GO_AROUND_POWER_THRESHOLD:
                self._hdg_t = ToleranceTracker(ToleranceSpec.symmetric("Heading", "deg", state.heading_deg, HDG_TOL_DEG), diff_fn=heading_diff)
                self._vy_t = ToleranceTracker(
                    ToleranceSpec("Airspeed", "kt", self._vy_kt, self._tol_low, self._tol_high),
                    gate_until_captured=True,
                )
                self.trackers = [self._hdg_t, self._vy_t]
                self._phase = "climbing"
                self._climb_started_at = state.t
            return None

        self._hdg_t.update(state.heading_deg, dt)
        self._vy_t.update(state.ias_kt, dt)
        if state.t - self._climb_started_at >= CLIMB_HOLD_S:
            notes = []
            if not self._vy_t.captured:
                notes.append(
                    f"airspeed was never within tolerance of Vy ({self._vy_kt:.0f}kt) during the climb "
                    "(advisory only -- never captured, so nothing to grade the sustained tolerance against)"
                )
            return self._finish(True, notes)
        return None
