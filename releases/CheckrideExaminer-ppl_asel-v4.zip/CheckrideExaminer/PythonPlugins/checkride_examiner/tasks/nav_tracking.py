"""IR.V.A Intercepting and Tracking Navigational Systems and DME Arcs.

VOR/localizer (NAV1) only in this build -- no GPS/RNAV course tracking or
DME arcs yet (see README/SPEC known limitations).

ACS (FAA-S-ACS-8C, IR.V.A.S5/S6): maintain airspeed +/-10kt, altitude
+/-100ft, no more than 3/4-scale deflection of the CDI. The ACS also lists
"selected headings +/-5deg" (S5), but tracking a course inherently means
correcting heading for wind/drift -- a single fixed heading target would be
a poor model of what's actually being graded here, so heading is left to
the pilot's own course-tracking judgement and only altitude/airspeed/CDI
are tracked.
"""
from ..grading import ToleranceSpec, ToleranceTracker
from .base import HoldTask

CDI_FULL_SCALE_DOTS = 2.0
CDI_TOLERANCE_DOTS = CDI_FULL_SCALE_DOTS * 0.75


class NavTrackingTask(HoldTask):
    task_id = "nav_tracking"
    title = "Intercepting and Tracking a Navigation Course"
    acs_ref = "IR.V.A"
    HOLD_SECONDS = 30.0

    def instructions(self):
        return "Intercept and track the selected VOR/localizer course. Hold altitude and airspeed."

    def _arm_condition(self, state):
        return not state.on_ground and abs(state.vs_fpm) < 150.0 and abs(state.bank_deg) < 15.0

    def _on_arm(self, state):
        alt_t = ToleranceTracker(ToleranceSpec.symmetric("Altitude", "ft", state.indicated_alt_ft, 100.0))
        ias_t = ToleranceTracker(ToleranceSpec.symmetric("Airspeed", "kt", state.ias_kt, 10.0))
        cdi_t = ToleranceTracker(ToleranceSpec.symmetric("CDI", "dots", 0.0, CDI_TOLERANCE_DOTS))
        self.tracked = [
            (alt_t, lambda s: s.indicated_alt_ft),
            (ias_t, lambda s: s.ias_kt),
            (cdi_t, lambda s: s.nav1_hdef_dots),
        ]
