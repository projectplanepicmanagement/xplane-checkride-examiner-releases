"""CA.V.D Lazy Eights.

ACS (FAA-S-ACS-7B): complete no lower than 1,500 ft AGL (CA.V.D.S2); ~30deg
bank at the steepest point, with continuous change of pitch/roll/airspeed
throughout (S5a/b -- not individually graded here, since it's an
inherently continuous maneuver with no fixed mid-point target); at the
180deg point: altitude +/-100ft from entry, airspeed +/-10kt from entry,
heading +/-10deg from the reciprocal of entry (S5c/d/e).

One 180deg half of the figure-eight is graded (real ACS asks for a number
of full "symmetrical loops," i.e. multiple 180deg halves -- simplified
here to one, the same way Holding is simplified to one circuit).
"""
from ..util import heading_diff
from .base import Task

MIN_AGL_FT = 1500.0
ARM_BANK_DEG = 15.0
TIMEOUT_S = 90.0
ALT_TOL_FT = 100.0
IAS_TOL_KT = 10.0
HDG_TOL_DEG = 10.0


class LazyEightTask(Task):
    task_id = "lazy_eight"
    title = "Lazy Eight"
    acs_ref = "CA.V.D"

    def __init__(self, direction: str = "left"):
        super().__init__()
        assert direction in ("left", "right")
        self.direction = direction
        self._sign = -1.0 if direction == "left" else 1.0
        self._phase = "armed"
        self._armed_at = None
        self._started_at = None
        self._entry_heading = None
        self._entry_alt = None
        self._entry_ias = None
        self._last_heading = None
        self._cumulative_turn = 0.0

    def instructions(self):
        return (
            f"Begin the {self.direction} half of a lazy eight: continuously vary pitch, "
            "bank (~30deg at the steepest point), and airspeed through a smooth 180deg turn, "
            "arriving back at entry altitude/airspeed on the reciprocal heading."
        )

    def update(self, state, dt):
        if self._armed_at is None:
            self._armed_at = state.t

        if self._phase == "armed":
            if state.t - self._armed_at > TIMEOUT_S:
                return self._finish(False, [f"never established the {self.direction} lazy eight"])
            if self._sign * state.bank_deg > ARM_BANK_DEG:
                self._entry_heading = state.heading_deg
                self._entry_alt = state.indicated_alt_ft
                self._entry_ias = state.ias_kt
                self._last_heading = state.heading_deg
                self._cumulative_turn = 0.0
                self._started_at = state.t
                self._phase = "turning"
            return None

        if state.agl_ft < MIN_AGL_FT:
            return self._finish(False, [f"descended below the 1,500 ft AGL floor ({state.agl_ft:.0f} ft AGL)"])

        d = heading_diff(state.heading_deg, self._last_heading)
        self._cumulative_turn += d
        self._last_heading = state.heading_deg

        if state.t - self._started_at > TIMEOUT_S:
            return self._finish(False, ["did not complete the 180deg half in time"])

        if abs(self._cumulative_turn) >= 180.0:
            target_heading = (self._entry_heading + 180.0) % 360.0
            hdg_dev = heading_diff(state.heading_deg, target_heading)
            alt_dev = state.indicated_alt_ft - self._entry_alt
            ias_dev = state.ias_kt - self._entry_ias
            notes = []
            passed = True
            if abs(hdg_dev) > HDG_TOL_DEG:
                passed = False
                notes.append(f"heading {hdg_dev:+.0f}deg from the reciprocal (limit +/-10deg)")
            if abs(alt_dev) > ALT_TOL_FT:
                passed = False
                notes.append(f"altitude {alt_dev:+.0f}ft from entry (limit +/-100ft)")
            if abs(ias_dev) > IAS_TOL_KT:
                passed = False
                notes.append(f"airspeed {ias_dev:+.0f}kt from entry (limit +/-10kt)")
            if not notes:
                notes.append("180deg point on speed, altitude, and heading")
            return self._finish(passed, notes)
        return None
