"""Online device-binding check for the license key scheme in license.py.

license.py's key format is fully self-contained (a random payload plus an
HMAC checksum) and needs no network to *validate* -- that's deliberate,
since X-Plane add-ons are expected to keep working with no internet
connection. But a self-contained key can be typed into any number of
machines and each one will independently agree it's "correct," with
nothing anywhere tracking that it's already in use elsewhere. Enforcing
"one license, one device" is inherently a shared-state question a single
offline machine can't answer by itself -- it needs *some* server, however
small.

This module is that server call, and only that -- it does not replace
license.py's own crypto checks (a key still has to pass is_valid_key()
first, entirely offline, before this is ever consulted). On activation,
the plugin POSTs the key plus a random per-install `device_id` to a small
hosted endpoint (see /server/activation-worker.js, a Cloudflare Worker);
the server accepts the first device to ever present a given key and
rejects every other device from then on, until the seller manually clears
that binding via the worker's /admin/reset endpoint -- e.g. for a
legitimate computer replacement.

**This is a one-time online check at activation, not continuous
phone-home.** LicenseStore.activate() requires network access; once it
succeeds, LicenseStore.is_activated goes back to being a purely local,
offline check (see license.py), so a customer can still fly with no
internet connection on any ordinary day -- only the initial "Activate"
button press needs connectivity. The trade-off this accepts: someone who
copies not just the key but the *entire* license.json file (key +
device_id, both of which already satisfied the server once) onto a second
machine would not be caught here -- catching that would need continuous
re-verification, which conflicts with "works fully offline" the rest of
the time. This module only has to stop the realistic, casual threat --
one person handing their key string to another -- not a deliberate file
copy; see README's Known Limitations.

Injectable `post_json` (same dependency-injection pattern as updater.py's
`fetch_json`/`download`) so every test here runs with zero real network
calls.
"""
import json
import urllib.error
import urllib.request
import uuid
from typing import Callable, Optional, Tuple

from .updater import _ssl_context

# Deployed via `wrangler deploy` from /server/ (see server/README.md) --
# a Cloudflare Worker backed by a KV namespace, verified end-to-end
# (accept/reject/re-activate/admin-reset) against the live endpoint before
# this URL was pasted in here.
ACTIVATION_URL = "https://checkride-examiner-activation.projectplanepicmanagement.workers.dev/activate"

REQUEST_TIMEOUT_S = 10.0


def new_device_id() -> str:
    """A random per-install identifier -- not tied to any real hardware
    serial (XPPython3 exposes none reliably across Windows/macOS/Linux),
    just a value generated once and persisted in license.json alongside
    the key. Persisting it (rather than regenerating on every launch)
    means the *same* install re-activating later (e.g. after this plugin
    itself is updated/reinstalled, since license.json lives in X-Plane's
    prefs folder, not inside the plugin folder INSTALL.txt has users
    overwrite) is recognized as the same device and never rejected as a
    second one."""
    return uuid.uuid4().hex


def _default_post_json(url: str, payload: dict) -> dict:
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=data,
        # Cloudflare's shared *.workers.dev domain runs anti-bot
        # protection that blocks urllib's default "Python-urllib/x.y"
        # User-Agent outright (HTTP 403, Cloudflare error code 1010,
        # "banned based on your browser's signature") even though this is
        # our own Worker -- confirmed by reproducing it against the live
        # endpoint. Any non-default User-Agent clears it; this one just
        # also happens to be useful in the Worker's own access logs.
        headers={"Content-Type": "application/json", "User-Agent": "CheckrideExaminer/1 (XPPython3 plugin)"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT_S, context=_ssl_context()) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        # The worker returns a JSON body even on 4xx (e.g.
        # already_activated_elsewhere is a 409) -- try to recover it
        # before falling back to a bare status-code reason.
        try:
            return json.loads(exc.read().decode("utf-8"))
        except (ValueError, OSError):
            return {"ok": False, "error": f"http_{exc.code}"}


_REASON_MESSAGES = {
    "already_activated_elsewhere": (
        "This key is already activated on a different installation. If you're "
        "moving to a new computer, contact support to release the old one first."
    ),
    "missing_key_or_device_id": "Activation request was malformed -- please try again.",
}


def verify_device(
    key: str,
    device_id: str,
    post_json: Callable[[str, dict], dict] = _default_post_json,
) -> Tuple[bool, Optional[str]]:
    """(True, None) if `device_id` is now the one bound to `key` on the
    activation server -- either it was the first device to present this
    key, or it already was. (False, message) otherwise, where `message` is
    safe to show the pilot as-is.

    A network failure (server unreachable, timeout, malformed response)
    is deliberately reported as (False, ...), never (True, ...) --
    failing open here would let anyone activate with no network at all,
    which defeats the one-device check entirely (the whole reason this
    module exists). This is the one place in the plugin where "can't
    reach the network" is NOT treated as a harmless, ignorable outcome
    (contrast updater.py's Check for Updates, which fails softly)."""
    try:
        result = post_json(ACTIVATION_URL, {"key": key, "device_id": device_id})
    except Exception as exc:  # noqa: BLE001 - any transport/parsing failure, see docstring
        return False, (
            f"Couldn't reach the license server ({exc}). Check your internet "
            "connection and try again."
        )
    if result.get("ok"):
        return True, None
    reason = str(result.get("error", "unknown_error"))
    return False, _REASON_MESSAGES.get(reason, f"Activation failed ({reason}).")
