"""On-screen examiner UI.

Prefers an ImGui window (colored progress bars, in-window buttons, a
task-by-task progress strip) via XPPython3's bundled xp_imgui + pyimgui. If
that import fails for any reason -- a future XPPython3 build without
OpenGL, say -- this falls back to a plain XPLMDisplay text overlay that
only supports Checkride Mode (see _PlainBackend).

Neither mode is reachable until a valid serial key has been activated
(controller.is_licensed) -- the ImGui backend shows a license-entry screen
in place of Home until then; the plain fallback backend (see _PlainBackend)
has no text-input widget, so it just tells the pilot to use the ImGui UI.

Within a session, a task can independently block itself the same way --
`Task.blocking_reason()` (see tasks/base.py) is non-None when a mandatory
per-aircraft setting (Vx/Vy, VMC recovery speed, Slow Flight target -- see
aircraft_settings.py) hasn't been entered yet. Both `_draw_checkride` and
`_draw_practice_running` check it before drawing anything else for the
current task and show a "SETTINGS REQUIRED" banner with an Open Settings
shortcut instead; the plain fallback backend has the same text-input
problem as the license screen, so it just says so.

Two modes, both driven by the same `AppController`:
  - Checkride Mode: the full ordered 15-task session. Pass/fail is withheld
    until the end, like a real checkride -- the progress strip and task
    list only show how far along you are (done / current / not yet
    reached), never which of the done tasks were satisfactory. Only the
    final debrief screen reveals per-task results and the overall score.
  - Practice Mode: pick one task from a catalog (airborne ones reposition
    you into the air first), get immediate pass/fail feedback, and retry
    freely. Nothing here is hidden.

Every ImGui call site that isn't in XPPython3's typed `imgui.pyi` stub (i.e.
isn't 100%-confirmed against this exact bundle) is individually try/except
guarded: XPPython3's Window wrapper permanently stops rendering the window
after any exception escapes the draw callback, so a single uncertain call
must never be allowed to take the whole overlay down for the rest of the
session.

Both backends' windows start hidden (visible=0) -- the plugin is enabled
for every flight regardless of which aircraft is loaded, so popping the
window open by default meant it appeared uninvited even on, say, an
airliner flight that has nothing to do with a checkride (user-reported).
Open it via Plugins menu > Checkride Examiner > Show/Hide Window (or
`ExaminerOverlay.toggle_visible()`) when you actually want it.
"""
from XPPython3 import xp

from .aircraft_settings import AircraftSettings
from .airports import find_nearby_airports
from .controller import MODE_CHECKRIDE, MODE_PRACTICE
from .edition import visible_ratings
from .practice import PRACTICE_CATALOG
from ._version import PLUGIN_VERSION, PUBLIC_VERSION, PUBLIC_VERSION_BASE
from .weather_presets import PRESETS as WEATHER_PRESETS
from .sequence import RATINGS
from .tasks.quiz import MultipleChoiceTask


def _aircraft_display_name(aircraft_key):
    if not aircraft_key:
        return "(no aircraft loaded)"
    name = aircraft_key
    if name.lower().endswith(".acf"):
        name = name[:-4]
    return name

try:
    import imgui
    from XPPython3.xp_imgui import Window as ImguiWindow
    _HAS_IMGUI = True
except Exception:
    _HAS_IMGUI = False

GREEN = (0.40, 0.85, 0.40)
RED = (0.95, 0.40, 0.40)
YELLOW = (0.95, 0.80, 0.25)
GRAY = (0.65, 0.65, 0.65)
WHITE = (0.92, 0.92, 0.92)
DONE = (0.55, 0.60, 0.80)  # neutral "attempted" marker -- deliberately NOT pass/fail colored


def _tolerance_fraction(tracker) -> float:
    spec = tracker.spec
    span = spec.high - spec.low
    if span <= 0:
        return 0.5
    return max(0.0, min(1.0, (tracker.last_dev - spec.low) / span))


def _tolerance_color(tracker):
    if tracker.busted:
        return RED
    frac = _tolerance_fraction(tracker)
    if frac < 0.15 or frac > 0.85:
        return YELLOW
    return GREEN


class _ImguiBackend:
    def __init__(self, controller):
        self.controller = controller
        # Practice-mode setup-screen state (lives here, not on PracticeSession,
        # since it's in-progress UI configuration, not session state).
        self._setup_entry = None
        self._setup_agl_ft = 0.0
        self._setup_ias_kt = 0.0
        self._setup_pitch_deg = 0.0
        self._setup_location = None  # None = current position, else a NearbyAirport
        self._nearby_airports = []
        self._practice_rating_filter = "ppl_asel"
        # Home screen shown before anything is graded -- see AppController.started.
        self._home = True
        self._home_rating = "ppl_asel"
        # Checkride Mode pre-flight gate -- shown between "Start Checkride
        # Mode" and the session actually starting (AppController.start()
        # is deferred until this confirms). Catches every mandatory
        # Aircraft Setting this rating's tasks need up front, instead of
        # a pilot discovering one is missing mid-session when that task's
        # turn comes up (user-reported: a tester was surprised by the
        # "SETTINGS REQUIRED" banner appearing right before a maneuver).
        self._preflight_check = False
        # Weather screen state (IR immersion only -- see weather.py; nothing
        # graded depends on this, so there's nothing to stage/save here).
        self._show_weather = False
        # Update screen state -- see updater.py. _update_checked
        # distinguishes "never checked yet" from "checked and up to date"
        # (both start out with _update_info/_update_error at None).
        self._show_update = False
        self._update_checked = False
        self._update_info = None
        self._update_error = None
        self._update_applied = False
        self._update_apply_error = None
        # Settings screen state (staged values, only written to the store on Save).
        self._show_settings = False
        self._settings_vx_kt = 0.0
        self._settings_vy_kt = 0.0
        self._settings_sf_approach_kt = 0.0
        self._settings_vmc_recovery_kt = 0.0
        self._settings_slow_flight_kt = 0.0
        # License gate state -- shown instead of Home until activated (see
        # AppController.is_licensed); _force_license_screen lets an already
        # -activated pilot reopen it from Home to enter a different key.
        self._force_license_screen = False
        self._license_key_input = ""
        self._license_error = False
        self._window = ImguiWindow(
            60, 760, 560, 580, 0,  # starts hidden -- see class docstring
            self._draw, None,
            xp.WindowDecorationRoundRectangle,
            xp.WindowLayerFloatingWindows,
        )
        self._window.setTitle("Checkride Examiner")

    @property
    def window_id(self):
        return self._window.windowID

    def destroy(self):
        self._window.delete()

    def _draw(self, window_id, ref_con):
        try:
            self._draw_content()
        except Exception as exc:  # pragma: no cover - defensive UI guard
            xp.log(f"[CheckrideExaminer] overlay draw error: {exc!r}")
            try:
                imgui.text_colored("Checkride Examiner - UI error, see XPPython3Log.txt", *RED)
            except Exception:
                pass

    def _progress_bar(self, frac, width, label):
        try:
            imgui.progress_bar(frac, (width, 6.0), label or "")
        except Exception:
            pass

    def _wrapped(self, text):
        try:
            imgui.text_wrapped(text)
        except Exception:
            imgui.text(text[:110])

    def _begin_scroll(self, str_id, height):
        try:
            imgui.begin_child(str_id, 0.0, height, True)
            return True
        except Exception:
            return False

    def _end_scroll(self, scrolling):
        if scrolling:
            try:
                imgui.end_child()
            except Exception:
                pass

    def _draw_content(self):
        controller = self.controller
        if not controller.is_licensed or self._force_license_screen:
            self._draw_license_gate()
            return
        if self._show_settings:
            self._draw_settings()
            return
        if self._show_weather:
            self._draw_weather()
            return
        if self._show_update:
            self._draw_update()
            return
        if self._preflight_check:
            self._draw_preflight_check()
            return
        if self._home:
            self._draw_home()
            return

        imgui.text_colored("CHECKRIDE EXAMINER", *YELLOW)
        imgui.same_line()
        imgui.text_colored(RATINGS[controller.checkride.rating], *GRAY)
        imgui.same_line()
        if imgui.button("Home"):
            self._home = True
            return
        imgui.same_line()
        if imgui.button("Settings"):
            self._open_settings()
            return
        imgui.same_line()
        if imgui.button("Weather"):
            self._show_weather = True
            return
        imgui.same_line()
        if imgui.button("Updates"):
            self._show_update = True
            return
        imgui.spacing()

        if imgui.button("Checkride Mode" + ("  [active]" if controller.mode == MODE_CHECKRIDE else "")):
            controller.set_mode(MODE_CHECKRIDE)
        imgui.same_line()
        if imgui.button("Practice Mode" + ("  [active]" if controller.mode == MODE_PRACTICE else "")):
            controller.set_mode(MODE_PRACTICE)
        imgui.separator()

        if controller.mode == MODE_CHECKRIDE:
            self._draw_checkride(controller.checkride)
        else:
            self._draw_practice(controller.practice)

    def _draw_home(self):
        controller = self.controller
        imgui.text_colored("CHECKRIDE EXAMINER", *YELLOW)
        imgui.spacing()
        self._wrapped("Pick a rating, then choose Checkride Mode for the full graded "
                       "session (score withheld until the end) or Practice Mode to drill "
                       "one task at a time with immediate feedback. Nothing is tracked "
                       "until you start.")
        imgui.spacing()

        imgui.text_colored(f"Aircraft: {_aircraft_display_name(controller.aircraft_key)}", *GRAY)
        imgui.same_line()
        if imgui.button("Settings"):
            self._open_settings()
            return
        imgui.same_line()
        if imgui.button("Weather"):
            self._show_weather = True
            return
        imgui.same_line()
        if imgui.button(f"Updates (v{PUBLIC_VERSION})"):
            self._show_update = True
            return
        imgui.text_colored(f"License: {controller.license_key_display()}", *GREEN)
        imgui.same_line()
        if imgui.button("Change Key"):
            self._force_license_screen = True
            self._license_key_input = ""
            self._license_error = False
            return
        if controller.aircraft_key and not controller.is_current_aircraft_registered():
            self._wrapped(
                "This aircraft isn't set up yet -- open Settings and enter its Vx/Vy, VMC "
                "Demonstration recovery speed, and Slow Flight target speed. Those tasks will not "
                "start at all until their number is entered (a real target varies by flight "
                "school/aircraft); short-field approach speed is optional and falls back to 1.3 x Vso."
            )
        imgui.spacing()

        imgui.text_colored("Rating:", *GRAY)
        for key, label in visible_ratings(RATINGS, controller.licensed_ratings).items():
            imgui.same_line()
            if imgui.button(label + ("  [selected]" if self._home_rating == key else "")):
                self._home_rating = key
        imgui.spacing()
        imgui.separator()
        imgui.spacing()

        if imgui.button("Start Checkride Mode", 480, 40):
            controller.set_checkride_rating(self._home_rating)
            controller.set_mode(MODE_CHECKRIDE)
            self._home = False
            self._preflight_check = True
        imgui.spacing()
        if imgui.button("Start Practice Mode", 480, 40):
            self._practice_rating_filter = self._home_rating
            controller.set_mode(MODE_PRACTICE)
            self._home = False
            self._preflight_check = True
        imgui.spacing()
        imgui.text_colored("(\"Home\" at the top brings you back here any time -- your "
                            "progress in either mode is kept.)", *GRAY)

    def _draw_preflight_check(self):
        """Gates AppController.start() for both modes -- collects every
        mandatory Aircraft Setting the chosen rating could need (via each
        task's own blocking_reason(), the same check that would otherwise
        only surface once a specific task's turn came up -- for Checkride
        Mode that's mid-session; for Practice Mode it's the moment a
        blocked entry is picked from the catalog) and forces them to be
        entered before anything can begin. If everything's already
        registered, shows a one-screen confirm instead of silently diving
        straight into Task 1 / the practice catalog."""
        controller = self.controller
        is_practice = controller.mode == MODE_PRACTICE
        rating = self._practice_rating_filter if is_practice else controller.checkride.rating
        imgui.text_colored("PRE-FLIGHT CHECK", *YELLOW)
        imgui.spacing()
        imgui.text_colored(f"Mode: {'Practice' if is_practice else 'Checkride'}", *GRAY)
        imgui.text_colored(f"Rating: {RATINGS[rating]}", *GRAY)
        imgui.text_colored(f"Aircraft: {_aircraft_display_name(controller.aircraft_key)}", *GRAY)
        imgui.spacing()

        blocking_reasons = (
            controller.practice_blocking_reasons(rating) if is_practice
            else controller.checkride_blocking_reasons()
        )

        if blocking_reasons:
            imgui.text_colored("SETTINGS REQUIRED BEFORE STARTING", *RED)
            self._wrapped(
                ("Practice Mode's catalog for this rating" if is_practice else "This rating's syllabus")
                + " needs the following entered first, so you won't be interrupted "
                + ("by a blocked entry" if is_practice else "mid-session by a task refusing to start") + ":"
            )
            imgui.spacing()
            for reason in blocking_reasons:
                self._wrapped("- " + reason)
            imgui.spacing()
            if imgui.button("Open Settings", 200, 0):
                self._open_settings()
                return
            imgui.same_line()
            if imgui.button("Back to Home", 150, 0):
                self._preflight_check = False
                self._home = True
            return

        settings = controller.current_settings()
        self._wrapped(
            "Every mandatory speed this rating needs is already registered for this "
            "aircraft. Confirm before starting -- "
            + ("Practice Mode" if is_practice else "once the checkride begins, it")
            + " won't ask again."
        )
        imgui.spacing()
        if settings.vx_kt > 0.0:
            imgui.text_colored(f"Vx: {settings.vx_kt:.0f}kt", *WHITE)
        if settings.vy_kt > 0.0:
            imgui.text_colored(f"Vy: {settings.vy_kt:.0f}kt", *WHITE)
        if settings.vmc_recovery_kt > 0.0:
            imgui.text_colored(f"VMC Demo recovery speed: {settings.vmc_recovery_kt:.0f}kt", *WHITE)
        if settings.slow_flight_kt > 0.0:
            imgui.text_colored(f"Slow Flight target: {settings.slow_flight_kt:.0f}kt", *WHITE)
        if settings.short_field_approach_kt > 0.0:
            imgui.text_colored(f"Short-field approach speed: {settings.short_field_approach_kt:.0f}kt", *WHITE)
        else:
            imgui.text_colored("Short-field approach speed: not set -- 1.3 x Vso will be used automatically", *GRAY)
        imgui.spacing()
        if imgui.button("Confirm and Start", 250, 40):
            controller.start()
            self._preflight_check = False
        imgui.same_line()
        if imgui.button("Edit Settings", 150, 0):
            self._open_settings()
            return
        imgui.same_line()
        if imgui.button("Back to Home", 150, 0):
            self._preflight_check = False
            self._home = True

    def _text_input(self, label, value):
        try:
            _changed, value = imgui.input_text(label, value, 32)
        except Exception:
            imgui.text(f"{label}: {value}")
        return value

    def _draw_license_gate(self):
        controller = self.controller
        imgui.text_colored("CHECKRIDE EXAMINER - LICENSE", *YELLOW)
        imgui.spacing()
        already_licensed = controller.is_licensed
        if already_licensed:
            imgui.text_colored(f"Currently activated: {controller.license_key_display()}", *GREEN)
            imgui.spacing()
        self._wrapped(
            "Enter the serial key you received with your purchase to unlock Checkride "
            "and Practice Mode. Activating needs an internet connection the first time, "
            "to confirm this key isn't already in use on another computer -- after that, "
            "everything runs offline as usual."
        )
        imgui.spacing()
        self._license_key_input = self._text_input("Serial key", self._license_key_input)
        imgui.spacing()
        if imgui.button("Activate", 150, 0):
            if controller.activate_license(self._license_key_input):
                self._license_key_input = ""
                self._license_error = False
                self._force_license_screen = False
            else:
                self._license_error = True
        if already_licensed:
            imgui.same_line()
            if imgui.button("Back", 100, 0):
                self._force_license_screen = False
        if self._license_error:
            message = controller.license_activation_error or "That key isn't valid -- check for typos."
            self._wrapped(message)

    def _open_settings(self):
        current = self.controller.current_settings()
        self._settings_vx_kt = current.vx_kt
        self._settings_vy_kt = current.vy_kt
        self._settings_sf_approach_kt = current.short_field_approach_kt
        self._settings_vmc_recovery_kt = current.vmc_recovery_kt
        if current.slow_flight_kt > 0.0:
            self._settings_slow_flight_kt = current.slow_flight_kt
        elif self.controller.last_vso_kt > 0.0:
            # not registered yet -- suggest a starting point (1.2x the
            # aircraft's real stall speed) rather than a bare 0 slider;
            # still has to be explicitly saved to actually register it.
            self._settings_slow_flight_kt = round(1.2 * self.controller.last_vso_kt)
        else:
            self._settings_slow_flight_kt = 0.0
        self._show_settings = True

    def _draw_settings(self):
        controller = self.controller
        imgui.text_colored("AIRCRAFT SETTINGS", *YELLOW)
        imgui.spacing()
        imgui.text_colored(f"Aircraft: {_aircraft_display_name(controller.aircraft_key)}", *GRAY)
        if not controller.aircraft_key:
            self._wrapped("No aircraft detected yet -- load one before entering its numbers.")
            imgui.spacing()
            if imgui.button("Back", 100, 0):
                self._show_settings = False
            return
        self._wrapped(
            "These are saved per aircraft (matched by its .acf file), so you only enter them "
            "once per add-on. Short-Field Takeoff, VMC Demonstration, and Slow Flight will not "
            "start at all until their speed below is set (a real target varies too much by "
            "flight school/aircraft to guess) -- Short-field approach speed is the one exception, "
            "since 0 there falls back to the ACS's own 1.3 x Vso formula automatically."
        )
        imgui.spacing()
        self._settings_vx_kt = self._slider("Vx - best angle of climb (kt, 0 = not set -- required)", self._settings_vx_kt, 0.0, 120.0)
        self._settings_vy_kt = self._slider("Vy - best rate of climb (kt, 0 = not set -- required)", self._settings_vy_kt, 0.0, 120.0)
        self._settings_sf_approach_kt = self._slider(
            "Short-field approach speed (kt, 0 = auto: 1.3 x Vso)", self._settings_sf_approach_kt, 0.0, 120.0,
        )
        self._settings_vmc_recovery_kt = self._slider(
            "VMC Demo recovery speed, e.g. Vyse (kt, 0 = not set -- required, AMEL only)", self._settings_vmc_recovery_kt, 0.0, 160.0,
        )
        self._settings_slow_flight_kt = self._slider(
            "Slow Flight target speed / MCA (kt, 0 = not set -- required)", self._settings_slow_flight_kt, 0.0, 120.0,
        )
        imgui.spacing()
        if imgui.button("Save", 150, 0):
            controller.save_aircraft_settings(AircraftSettings(
                vx_kt=self._settings_vx_kt,
                vy_kt=self._settings_vy_kt,
                short_field_approach_kt=self._settings_sf_approach_kt,
                vmc_recovery_kt=self._settings_vmc_recovery_kt,
                slow_flight_kt=self._settings_slow_flight_kt,
            ))
            self._show_settings = False
        imgui.same_line()
        if imgui.button("Back", 100, 0):
            self._show_settings = False

    def _draw_weather(self):
        imgui.text_colored("WEATHER", *YELLOW)
        imgui.spacing()
        self._wrapped(
            "For IR practice: puts the aircraft in genuinely reduced visibility instead of "
            "only being graded as if it were. This is presentation only -- grading (CDI dots, "
            "altitude, airspeed, etc.) never changes with the weather, so this is safe to use "
            "any time, in any mode."
        )
        imgui.spacing()
        for preset in WEATHER_PRESETS:
            if imgui.button(preset.label, 480, 30):
                self.controller.apply_weather_preset(preset.key)
            self._wrapped(preset.description)
            imgui.spacing()
        imgui.separator()
        if imgui.button("Back", 100, 0):
            self._show_weather = False

    def _draw_update(self):
        imgui.text_colored("UPDATES", *YELLOW)
        imgui.spacing()
        imgui.text_colored(f"Installed version: v{PUBLIC_VERSION}", *GRAY)
        imgui.spacing()

        if imgui.button("Check for Updates", 220, 0):
            info, error = self.controller.check_for_update()
            self._update_info = info
            self._update_error = error
            self._update_checked = True
            self._update_applied = False
            self._update_apply_error = None
        imgui.spacing()

        if self._update_error is not None:
            imgui.text_colored(f"Check failed: {self._update_error}", *RED)
        elif self._update_checked and self._update_info is None:
            imgui.text_colored("You're up to date.", *GREEN)
        elif self._update_info is not None:
            imgui.text_colored(
                f"Update available: v{self._update_info.version - PUBLIC_VERSION_BASE}", *YELLOW
            )
            if self._update_info.notes:
                self._wrapped(self._update_info.notes)
            imgui.spacing()
            if self._update_applied:
                imgui.text_colored(
                    "Installed -- restart X-Plane, or Plugins > Plugin Admin > Reload Scripts, to finish.", *GREEN,
                )
            else:
                if imgui.button("Download and Install", 220, 0):
                    apply_error = self.controller.apply_update(self._update_info)
                    if apply_error is not None:
                        self._update_apply_error = apply_error
                    else:
                        self._update_applied = True
                        self._update_apply_error = None
                if self._update_apply_error is not None:
                    imgui.text_colored(f"Install failed: {self._update_apply_error}", *RED)

        imgui.spacing()
        imgui.separator()
        if imgui.button("Back", 100, 0):
            self._show_update = False

    def _draw_blocking_banner(self, reason) -> bool:
        """Renders the "needs Settings" banner; returns True if the pilot
        clicked through to Settings (caller should stop drawing this frame,
        same convention as the top-bar Settings button)."""
        imgui.spacing()
        imgui.text_colored("SETTINGS REQUIRED", *RED)
        self._wrapped(reason)
        imgui.spacing()
        if imgui.button("Open Settings", 200, 0):
            self._open_settings()
            return True
        return False

    def _draw_checkride(self, session):
        imgui.text_colored("Rating:", *GRAY)
        for key, label in visible_ratings(RATINGS, self.controller.licensed_ratings).items():
            imgui.same_line()
            if imgui.button(label + ("  [selected]" if session.rating == key else "")):
                self.controller.set_checkride_rating(key)
        if session.rating != self.controller.checkride.rating:
            return  # the button click above just swapped the session object; redraw next frame
        imgui.spacing()

        total = len(session.tasks)
        done = len(session.results)
        self._progress_bar(done / total if total else 0.0, 480.0, f"{done}/{total} tasks")

        for i in range(total):
            if i > 0:
                imgui.same_line(0, 6)
            if i < done:
                color = DONE  # attempted -- pass/fail withheld until the debrief
            elif i == session.index:
                color = YELLOW
            else:
                color = GRAY
            imgui.text_colored(str(i + 1), *color)

        imgui.spacing()
        task = session.current_task
        if task is None:
            self._draw_debrief(session)
            return

        imgui.text_colored(f"Task {session.index + 1}/{total}: {task.title}", *WHITE)
        imgui.same_line()
        imgui.text_colored(f"({task.acs_ref})", *GRAY)

        blocking_reason = task.blocking_reason()
        if blocking_reason is not None:
            if self._draw_blocking_banner(blocking_reason):
                return
            imgui.spacing()
            if imgui.button("Skip Task"):
                session.skip_current()
            imgui.same_line()
            if imgui.button("Restart Session"):
                session.restart()
            return

        self._wrapped(task.instructions())
        imgui.spacing()

        if session.is_waiting_for_ready:
            imgui.text_colored("Take your time to get set up for this task.", *GRAY)
            if imgui.button("Ready", 200, 0):
                session.ready()
            imgui.spacing()

        if isinstance(task, MultipleChoiceTask):
            self._draw_quiz(task)
        else:
            for tracker in task.trackers:
                color = _tolerance_color(tracker)
                imgui.text_colored(f"{tracker.spec.label}: {tracker.last_dev:+.1f}{tracker.spec.unit}", *color)
                self._progress_bar(_tolerance_fraction(tracker), 220.0, "")

        next_task = session.next_task
        if next_task is not None:
            imgui.spacing()
            imgui.text_colored(f"Next: {next_task.title}", *GRAY)

        imgui.spacing()
        if imgui.button("Skip Task"):
            session.skip_current()
        imgui.same_line()
        if imgui.button("Restart Session"):
            session.restart()

    def _draw_practice(self, practice):
        if practice.active:
            self._draw_practice_running(practice)
            return
        if self._setup_entry is not None:
            self._draw_practice_setup(self._setup_entry)
            return

        imgui.text_colored("Rating:", *GRAY)
        for key, label in visible_ratings(RATINGS, self.controller.licensed_ratings).items():
            imgui.same_line()
            if imgui.button(label + ("  [selected]" if self._practice_rating_filter == key else "")):
                self._practice_rating_filter = key
        imgui.spacing()

        imgui.text_colored("Pick a task to practice:", *WHITE)
        entries = [e for e in PRACTICE_CATALOG if self._practice_rating_filter in e.ratings]
        ground = [e for e in entries if e.airborne_agl_ft is None]
        airborne = [e for e in entries if e.airborne_agl_ft is not None]

        scrolling = self._begin_scroll("practice_catalog", 380.0)
        if ground:
            imgui.text_colored("Ground (practiced in place)", *GRAY)
            for entry in ground:
                if imgui.button(entry.label, 460, 0):
                    self.controller.start_practice(entry)
            imgui.spacing()
        if airborne:
            imgui.text_colored("Airborne (choose start conditions next)", *GRAY)
            for entry in airborne:
                if imgui.button(entry.label, 460, 0):
                    self._open_setup(entry)
        if not entries:
            imgui.text_colored("(nothing in the catalog for this rating yet)", *GRAY)
        self._end_scroll(scrolling)

    def _open_setup(self, entry):
        self._setup_entry = entry
        self._setup_agl_ft = entry.airborne_agl_ft
        self._setup_ias_kt = entry.airborne_ias_kt
        self._setup_pitch_deg = 0.0
        self._setup_location = None
        try:
            self._nearby_airports = find_nearby_airports()
        except Exception as exc:
            xp.log(f"[CheckrideExaminer] nearby airport lookup failed: {exc!r}")
            self._nearby_airports = []

    def _draw_practice_setup(self, entry):
        imgui.text_colored(f"Set up: {entry.label}", *WHITE)
        imgui.spacing()

        imgui.text_colored("Start location", *GRAY)
        current = "Current Position (straight up)" if self._setup_location is None else \
            f"{self._setup_location.label} ({self._setup_location.distance_nm:.0f} nm away)"
        imgui.text(f"Selected: {current}")
        if imgui.button("Use Current Position", 260, 0):
            self._setup_location = None
        if self._nearby_airports:
            imgui.spacing()
            imgui.text_colored("Nearby airports (from the loaded scenery, not a live map):", *GRAY)
            for airport in self._nearby_airports:
                if imgui.button(f"{airport.label} - {airport.distance_nm:.0f} nm", 260, 0):
                    self._setup_location = airport
        else:
            imgui.text_colored("(no other airports found in the loaded scenery)", *GRAY)

        imgui.spacing()
        imgui.separator()
        imgui.text_colored("Start conditions", *GRAY)
        self._setup_agl_ft = self._slider("Altitude (ft AGL)", self._setup_agl_ft, 0.0, 10000.0)
        self._setup_ias_kt = self._slider("Airspeed (kt)", self._setup_ias_kt, 0.0, 160.0)
        self._setup_pitch_deg = self._slider("Pitch (deg, + nose up)", self._setup_pitch_deg, -20.0, 20.0)

        imgui.spacing()
        if imgui.button("Start", 200, 0):
            kwargs = dict(
                agl_ft=self._setup_agl_ft,
                ias_kt=self._setup_ias_kt,
                pitch_deg=self._setup_pitch_deg,
            )
            if self._setup_location is not None:
                kwargs["lat"] = self._setup_location.lat
                kwargs["lon"] = self._setup_location.lon
                kwargs["ground_elevation_m"] = self._setup_location.elevation_m
            self.controller.practice.start(entry, **kwargs)
            self._setup_entry = None
        imgui.same_line()
        if imgui.button("Cancel", 100, 0):
            self._setup_entry = None

    def _slider(self, label, value, lo, hi):
        try:
            _changed, value = imgui.slider_float(label, value, lo, hi, "%.0f")
        except Exception:
            imgui.text(f"{label}: {value:.0f}")
        return value

    def _draw_practice_running(self, practice):
        task = practice.task
        imgui.text_colored(f"Practicing: {task.title}", *WHITE)
        imgui.same_line()
        imgui.text_colored(f"({task.acs_ref})", *GRAY)

        blocking_reason = task.blocking_reason()
        if blocking_reason is not None:
            if self._draw_blocking_banner(blocking_reason):
                return
            imgui.spacing()
            if imgui.button("Give Up / Back to List"):
                self.controller.stop_practice()
            return

        self._wrapped(task.instructions())
        imgui.spacing()

        if practice.last_result is None:
            if isinstance(task, MultipleChoiceTask):
                self._draw_quiz(task)
            else:
                for tracker in task.trackers:
                    color = _tolerance_color(tracker)
                    imgui.text_colored(f"{tracker.spec.label}: {tracker.last_dev:+.1f}{tracker.spec.unit}", *color)
                    self._progress_bar(_tolerance_fraction(tracker), 220.0, "")
            imgui.spacing()
            if imgui.button("Give Up / Back to List"):
                self.controller.stop_practice()
            return

        result = practice.last_result
        color = GREEN if result.passed else RED
        imgui.text_colored("SATISFACTORY" if result.passed else "UNSATISFACTORY", *color)
        for note in result.notes:
            self._wrapped(note)
        imgui.spacing()
        if imgui.button("Try Again"):
            self.controller.retry_practice()
        imgui.same_line()
        if imgui.button("Back to List"):
            self.controller.stop_practice()

    def _draw_quiz(self, task):
        for i, option in enumerate(task.question.options):
            label = f"{chr(65 + i)}. {option}"
            try:
                clicked = imgui.button(label, 480, 0)
            except Exception:
                imgui.text(label)
                clicked = False
            if clicked:
                self.controller.submit_answer(i)
            imgui.spacing()

    def _draw_debrief(self, session):
        overall_ok = bool(session.results) and all(r.passed for r in session.results)
        color = GREEN if overall_ok else RED
        verdict = "ALL TASKS SATISFACTORY" if overall_ok else "NOT ALL TASKS SATISFACTORY"
        imgui.text_colored(verdict, *color)
        imgui.text(session.score_summary())
        if not overall_ok:
            failed = [r.title for r in session.results if not r.passed]
            self._wrapped("Review before your checkride: " + ", ".join(failed))
        imgui.separator()
        self._draw_results_log(session)
        imgui.spacing()
        if imgui.button("Restart Session"):
            session.restart()

    def _draw_results_log(self, session):
        imgui.text_colored("Results", *GRAY)
        for r in session.results:
            color = GREEN if r.passed else RED
            mark = "PASS" if r.passed else "FAIL"
            imgui.text_colored(f"[{mark}] {r.title}", *color)
            if r.notes:
                self._wrapped("    " + "; ".join(r.notes))


class _PlainBackend:
    """XPLMDisplay-only fallback used if imgui/OpenGL aren't available.
    Practice Mode needs clickable per-item regions that this simple
    draw-a-string approach doesn't support, so this only renders Checkride
    Mode; the controller can still be switched into Practice Mode from
    XPPython3Log.txt / a future key binding, but there's nothing to click
    here."""

    def __init__(self, controller):
        self.controller = controller
        # No clickable Home/Start screen is possible here (see class docstring),
        # so skip it and start grading immediately, matching this backend's
        # pre-existing behavior.
        controller.start()
        self.window_id = xp.createWindowEx(
            60, 760, 560, 420, 0,  # starts hidden, same as the ImGui backend
            self._draw, self._click, None, None, None,
            None,
            xp.WindowDecorationRoundRectangle,
            xp.WindowLayerFloatingWindows,
            None,
        )
        xp.setWindowPositioningMode(self.window_id, xp.WindowPositionFree)

    def destroy(self):
        xp.destroyWindow(self.window_id)

    def _click(self, window_id, x, y, mouse, refcon):
        return 1

    @staticmethod
    def _wrap(text, width=78):
        words = text.split()
        lines, line = [], ""
        for w in words:
            candidate = f"{line} {w}".strip()
            if len(candidate) > width and line:
                lines.append(line)
                line = w
            else:
                line = candidate
        if line:
            lines.append(line)
        return lines

    def _draw(self, window_id, refcon):
        left, top, right, bottom = xp.getWindowGeometry(window_id)
        xp.drawTranslucentDarkBox(left, top, right, bottom)

        if not self.controller.is_licensed:
            xp.drawString(YELLOW, left + 10, top - 20, "CHECKRIDE EXAMINER - LICENSE REQUIRED", 0, xp.Font_Proportional)
            xp.drawString(GRAY, left + 10, top - 40, "Serial-key entry needs the ImGui UI -- see README for requirements.", 0, xp.Font_Proportional)
            return

        session = self.controller.checkride
        y = top - 20
        xp.drawString(YELLOW, left + 10, y, f"CHECKRIDE EXAMINER - {RATINGS.get(session.rating, session.rating)}", 0, xp.Font_Proportional)
        y -= 20

        if self.controller.mode != MODE_CHECKRIDE:
            xp.drawString(GRAY, left + 10, y, "Practice Mode needs the ImGui UI -- showing Checkride Mode.", 0, xp.Font_Proportional)
            y -= 20

        task = session.current_task
        if task is None:
            xp.drawString(GREEN, left + 10, y, f"Session complete: {session.score_summary()}", 0, xp.Font_Proportional)
            y -= 20
            for r in session.results:
                color = GREEN if r.passed else RED
                xp.drawString(color, left + 10, y, r.summary_line()[:90], 0, xp.Font_Proportional)
                y -= 16
            return

        xp.drawString(
            WHITE, left + 10, y,
            f"Task {session.index + 1}/{len(session.tasks)}: {task.title} ({task.acs_ref})",
            0, xp.Font_Proportional,
        )
        y -= 18

        blocking_reason = task.blocking_reason()
        if blocking_reason is not None:
            xp.drawString(RED, left + 10, y, "SETTINGS REQUIRED (needs the ImGui UI to enter):", 0, xp.Font_Proportional)
            y -= 16
            for line in self._wrap(blocking_reason):
                xp.drawString(RED, left + 10, y, line, 0, xp.Font_Proportional)
                y -= 16
            return

        for line in self._wrap(task.instructions()):
            xp.drawString(WHITE, left + 10, y, line, 0, xp.Font_Proportional)
            y -= 16
        y -= 4

        if session.is_waiting_for_ready:
            xp.drawString(
                GRAY, left + 10, y,
                "Get set up for this task, then bind checkride/examiner/ready to a key to start grading.",
                0, xp.Font_Proportional,
            )
            y -= 20

        if isinstance(task, MultipleChoiceTask):
            for i, option in enumerate(task.question.options):
                for line in self._wrap(f"{chr(65 + i)}. {option}"):
                    xp.drawString(YELLOW, left + 10, y, line, 0, xp.Font_Proportional)
                    y -= 16
            xp.drawString(GRAY, left + 10, y, "(bind checkride/examiner/answer_a .. answer_d to a key)", 0, xp.Font_Proportional)
            y -= 20
        else:
            for line in task.status_lines():
                xp.drawString(YELLOW, left + 10, y, line, 0, xp.Font_Proportional)
                y -= 16
            y -= 4
            xp.drawString(GRAY, left + 10, y, "(bind checkride/examiner/skip_task or /restart to a key for controls)", 0, xp.Font_Proportional)
            y -= 20
        xp.drawString(GRAY, left + 10, y, f"Progress: {session.index + 1}/{len(session.tasks)} (results shown at the end)", 0, xp.Font_Proportional)


class ExaminerOverlay:
    def __init__(self, controller):
        self._backend = _ImguiBackend(controller) if _HAS_IMGUI else _PlainBackend(controller)

    def destroy(self):
        self._backend.destroy()

    def toggle_visible(self):
        wid = self._backend.window_id
        now_visible = not xp.getWindowIsVisible(wid)
        xp.setWindowIsVisible(wid, 1 if now_visible else 0)
        if now_visible:
            xp.bringWindowToFront(wid)
