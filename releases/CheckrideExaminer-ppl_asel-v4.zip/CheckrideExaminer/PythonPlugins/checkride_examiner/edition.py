"""Which ratings this particular build's UI lets a pilot pick -- see
README's "Editions" note. All task/syllabus code for every rating always
ships inside the package regardless of edition: splitting that out per
edition would mean either duplicating sequence.py's/practice.py's
top-level imports per edition or teaching them to import conditionally,
for no real benefit here -- the source isn't hidden from a curious user
either way (see license.py's own known limitation about that). Only which
ratings are *selectable in the UI* is restricted.

SHIPPED_RATINGS = None means "all of them" -- the default, full-line
build. package.sh overwrites this file (same pattern as _version.py) when
building a restricted single-rating edition, via its --ratings option.

This is one of *two* independent layers -- `visible_ratings()` also takes
the activated license key's own encoded restriction (see
`license.decode_licensed_ratings()`) and intersects it with
SHIPPED_RATINGS, so a pilot only ever sees a rating if both the build
exposes it *and* their own key authorizes it. The build-level layer alone
isn't enough: it protects against a build being more permissive than
intended, but not against a customer's own (legitimate) key being used
with a *different, more permissive build* they shouldn't have -- which is
exactly what happened once already (see SPEC.md's incident writeup) when
a full build was briefly reachable while only a restricted edition had
been sold. The key-level layer means even a leaked/misused build can't
unlock more than that specific key was issued for.
"""
from typing import Optional, Tuple

SHIPPED_RATINGS: Optional[Tuple[str, ...]] = ('ppl_asel',)


def visible_ratings(all_ratings: dict, licensed_ratings: Optional[Tuple[str, ...]] = None) -> dict:
    """`all_ratings` filtered down to SHIPPED_RATINGS (build-level, reads
    the module attribute directly -- see below), then further filtered
    down to `licensed_ratings` if given (key-level, from
    `AppController.licensed_ratings` -- None means the activated key
    carries no restriction of its own, e.g. a legacy key, so only the
    build-level filter applies). Order from `all_ratings` is preserved
    throughout.

    SHIPPED_RATINGS is read as a module attribute rather than a second
    "which ratings does this build expose" parameter so every call site
    in overlay.py stays in sync with a single source of truth -- tests
    exercise it by monkeypatching this module's attribute directly (see
    tests/test_edition.py), which is simpler than giving it its own
    parameter with an "unset" sentinel distinct from SHIPPED_RATINGS' own
    None-means-everything meaning. `licensed_ratings` IS an ordinary
    parameter, since callers already have it in hand (no analogous global
    to read it from) and a given build may be activated with different
    keys across installs."""
    if SHIPPED_RATINGS is None:
        result = dict(all_ratings)
    else:
        result = {k: v for k, v in all_ratings.items() if k in SHIPPED_RATINGS}
    if licensed_ratings is not None:
        result = {k: v for k, v in result.items() if k in licensed_ratings}
    return result
