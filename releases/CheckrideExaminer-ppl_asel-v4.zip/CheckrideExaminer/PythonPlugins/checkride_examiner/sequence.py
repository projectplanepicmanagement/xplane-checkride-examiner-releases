"""Orchestrates an ordered sequence of Tasks for one checkride session."""
from typing import List, Optional

from .grading import TaskResult
from .state import FlightState
from .tasks.base import Task
from .tasks.basic_instrument import (
    ConstantAirspeedClimbTask,
    ConstantAirspeedDescentTask,
    StraightAndLevelTask,
    TurnsToHeadingTask,
)
from .tasks.accelerated_stall import AcceleratedStallTask
from .tasks.approaches import NonprecisionApproachTask, PrecisionApproachTask
from .tasks.chandelle import ChandelleTask
from .tasks.emergency_descent import EmergencyDescentTask
from .tasks.go_around import GoAroundTask
from .tasks.ground_ops import RunUpTask, TaxiTask
from .tasks.ground_reference import TurnsAroundAPointTask
from .tasks.heli_hovering import HoverTaxiTask, RotorEngagementTask, VerticalTakeoffLandingTask
from .tasks.heli_performance import AutorotationTask, RapidDecelerationTask
from .tasks.heli_takeoff_landing import NormalApproachTask, NormalTakeoffClimbTask, SteepApproachTask
from .tasks.holding import HoldingTask
from .tasks.lazy_eight import LazyEightTask
from .tasks.missed_approach import MissedApproachTask
from .tasks.multiengine import EngineFailureAfterLiftoffTask, ManeuveringOneEngineInoperativeTask
from .tasks.nav_tracking import NavTrackingTask
from .tasks.normal_landing import NormalLandingTask, NormalTakeoffTask
from .tasks.short_field import ShortFieldApproachLandingTask, ShortFieldTakeoffTask
from .tasks.soft_field import SoftFieldLandingTask, SoftFieldTakeoffTask
from .tasks.traffic_pattern import TrafficPatternTask
from .tasks.vmc_demo import VmcDemonstrationTask
from .tasks.quiz import (
    random_clearance_question_task,
    random_ground_question_task,
    random_tower_question_task,
)
from .tasks.slow_flight import CommercialSlowFlightTask, SlowFlightTask
from .tasks.stalls import (
    CommercialPowerOffStallTask,
    CommercialPowerOnStallTask,
    PowerOffStallTask,
    PowerOnStallTask,
)
from .tasks.steep_turns import SteepTurnTask


def build_ppl_asel_syllabus() -> List[Task]:
    """Default PPL/ASEL task order: starts on the ground (ATC quiz, taxi,
    run-up, ATC quiz), a short-field takeoff, then the airborne tasks, then
    a landing-phase block (re-entering the pattern through a full stop),
    finishing with a short-field approach and landing back to the ground.

    The airborne order is deliberately NOT the ACS document's own Area
    ordering (which groups Basic Instrument Maneuvers -- straight/level,
    climbs, descents, turns to headings -- together in Area VIII, straight
    after Takeoffs/Landings in the table of contents). Following that order
    literally put a Descent task right after the short-field takeoff's
    climb-out (user-reported: "why would ATC/the DPE ask me to descend the
    instant I've just taken off?"). Instead this climbs out and stays up
    for the altitude-hungry airwork first (climb, level off, turns, steep
    turns, slow flight, stalls), only descends once there's an actual
    reason to (down toward ground-reference-maneuver altitude), and saves
    Emergency Descent for last before the approach and landing -- altitude
    generally trends up through the first half of the flight and down
    through the second, the way an actual checkride flows, rather than
    yo-yoing up and down to match the ACS's own document structure.

    The landing-phase block (Traffic Pattern, Go-Around, then Normal and
    Soft-Field takeoffs/landings paired as touch-and-goes) mirrors how a
    real multi-landing checkride segment actually flows: re-enter the
    pattern, fly one approach that gets rejected (go-around), then land and
    immediately depart again for each remaining technique, saving the
    already-implemented Short-Field Takeoff/Approach as the flight's
    opening departure and closing full stop respectively."""
    return [
        random_ground_question_task(),
        TaxiTask(),
        RunUpTask(),
        random_tower_question_task(),
        ShortFieldTakeoffTask(),
        ConstantAirspeedClimbTask(),
        StraightAndLevelTask(),
        TurnsToHeadingTask(),
        SteepTurnTask("left"),
        SteepTurnTask("right"),
        SlowFlightTask(),
        PowerOffStallTask(),
        PowerOnStallTask(),
        ConstantAirspeedDescentTask(),
        TurnsAroundAPointTask(),
        EmergencyDescentTask(),
        TrafficPatternTask(),
        GoAroundTask(),
        NormalLandingTask(),
        NormalTakeoffTask(),
        SoftFieldLandingTask(),
        SoftFieldTakeoffTask(),
        ShortFieldApproachLandingTask(),
    ]


def build_ir_syllabus() -> List[Task]:
    """Instrument Rating - Airplane task order (FAA-S-ACS-8C): clearance
    compliance, then navigation/holding/approach tasks. VOR/localizer +
    glideslope (NAV1) only -- no GPS/RNAV approaches yet."""
    return [
        random_clearance_question_task(),
        NavTrackingTask(),
        HoldingTask(),
        NonprecisionApproachTask(),
        PrecisionApproachTask(),
        MissedApproachTask(),
    ]


def build_cpl_syllabus() -> List[Task]:
    """Commercial Pilot - Airplane task order (FAA-S-ACS-7B): a short-field
    takeoff, the Commercial-specific performance maneuvers (steep turns at
    ~50deg, chandelles, lazy eights), then tightened-tolerance slow
    flight/stalls, then accelerated stalls, emergency descent, a
    landing-phase block (same rationale as PPL/ASEL's, see
    build_ppl_asel_syllabus -- Traffic Pattern's numbers aren't tightened
    for Commercial per the ACS, but Go-Around/Normal/Soft-Field are, same
    +/-5kt pattern as everything else here), and a short-field landing
    (approach speed graded against 1.3 x this aircraft's actual Vso,
    tighter +/-5kt than Private's +10/-5; touchdown standard is the ACS's
    100ft vs Private's 200ft, though that distance itself still isn't
    graded -- see short_field.py). Steep Spiral and Eights on Pylons aren't
    implemented yet -- both need a ground-reference-point estimate at least
    as involved as PPL's Turns Around a Point, and Eights on Pylons has no
    numeric altitude/airspeed tolerance in the ACS to grade against in the
    first place (see README/SPEC known limitations)."""
    return [
        ShortFieldTakeoffTask(acs_ref="CA.IV.E", tolerance_low=-5.0, tolerance_high=5.0),
        SteepTurnTask("left", target_bank=50.0, acs_ref="CA.V.A"),
        SteepTurnTask("right", target_bank=50.0, acs_ref="CA.V.A"),
        ChandelleTask("left"),
        ChandelleTask("right"),
        LazyEightTask("left"),
        LazyEightTask("right"),
        CommercialSlowFlightTask(),
        CommercialPowerOffStallTask(),
        CommercialPowerOnStallTask(),
        AcceleratedStallTask("left"),
        EmergencyDescentTask(acs_ref="CA.IX.A", bank_required=True),
        TrafficPatternTask(acs_ref="CA.III.B"),
        GoAroundTask(acs_ref="CA.IV.N", tolerance_low=-5.0, tolerance_high=5.0),
        NormalLandingTask(acs_ref="CA.IV.B", tolerance_low=-5.0, tolerance_high=5.0, touchdown_distance_ft=200.0),
        NormalTakeoffTask(acs_ref="CA.IV.A", tolerance_low=-5.0, tolerance_high=5.0),
        SoftFieldLandingTask(acs_ref="CA.IV.D", tolerance_low=-5.0, tolerance_high=5.0),
        SoftFieldTakeoffTask(acs_ref="CA.IV.C", tolerance_low=-5.0, tolerance_high=5.0),
        ShortFieldApproachLandingTask(acs_ref="CA.IV.F", tolerance_low=-5.0, tolerance_high=5.0, touchdown_distance_ft=100.0),
    ]


def build_ppl_amel_syllabus() -> List[Task]:
    """PPL/AMEL: the full PPL/ASEL syllabus plus the AMEL-specific
    multiengine tasks (FAA-S-ACS-6, Area IX.F and Area X.A-C) -- a real PPL
    checkride in a twin covers everything a single-engine checkride does,
    plus these. `Maneuvering with One Engine Inoperative` covers both
    PA.X.A (visual) and PA.X.C (instrument) since they share identical
    tolerances and this build can't detect hood use."""
    return build_ppl_asel_syllabus() + [
        EngineFailureAfterLiftoffTask(acs_ref="PA.IX.F"),
        ManeuveringOneEngineInoperativeTask(acs_ref="PA.X.A / PA.X.C"),
        VmcDemonstrationTask(acs_ref="PA.X.B", recovery_low=-5.0, recovery_high=10.0),
    ]


def build_cpl_amel_syllabus() -> List[Task]:
    """CPL/AMEL: the full Commercial syllabus plus the AMEL-specific
    multiengine tasks (FAA-S-ACS-7B, Area IX.F and Area X.A-C). Commercial's
    VMC Demonstration recovery-airspeed tolerance is tighter (+/-5kt) than
    Private's (+10/-5kt) -- the only number that differs between the two
    ratings' versions of these tasks. Task X.D (Instrument Approach and
    Landing with an Inoperative Engine) isn't implemented -- it needs both
    real approach-procedure awareness and landing/runway-proximity data,
    neither of which this build has yet."""
    return build_cpl_syllabus() + [
        EngineFailureAfterLiftoffTask(acs_ref="CA.IX.F"),
        ManeuveringOneEngineInoperativeTask(acs_ref="CA.X.A / CA.X.C"),
        VmcDemonstrationTask(acs_ref="CA.X.B", recovery_low=-5.0, recovery_high=5.0),
    ]


def build_ppl_helicopter_syllabus() -> List[Task]:
    """Private Pilot - Helicopter task order (FAA-S-ACS-15): rotor
    engagement, hovering maneuvers, normal takeoff/climb and approaches
    (normal then steep), then the performance maneuvers (quick stop, then
    straight-in and turning autorotations). Slope Operations, Confined Area
    Operations, and Pinnacle Operations aren't implemented -- the ACS grades
    these almost entirely on site selection/reconnaissance judgment rather
    than numeric standards a flight-data plugin can check. Go-Around and
    Maximum Performance Takeoff aren't implemented yet either (same shape as
    Normal Takeoff/Approach, just not built out). None of Area VIII's
    emergency tasks (Vortex Ring State, Low Rotor RPM, Antitorque Failure,
    Dynamic Rollover, Ground Resonance) are implemented -- deliberately
    provoking any of them is unsafe to script into a teleport/setup screen,
    and the ACS grades recognition/recovery judgment there, not a number."""
    return [
        RotorEngagementTask(),
        VerticalTakeoffLandingTask(),
        HoverTaxiTask(),
        NormalTakeoffClimbTask(),
        NormalApproachTask(),
        SteepApproachTask(),
        RapidDecelerationTask(),
        AutorotationTask(require_turn=False, acs_ref="PH.VI.B"),
        AutorotationTask(require_turn=True, acs_ref="PH.VI.C"),
    ]


RATINGS = {
    "ppl_asel": "PPL / ASEL",
    "ppl_amel": "PPL / AMEL",
    "ir": "Instrument Rating",
    "cpl": "Commercial Pilot",
    "cpl_amel": "Commercial Pilot / AMEL",
    "ppl_helicopter": "PPL / Helicopter",
}

_SYLLABUS_BUILDERS = {
    "ppl_asel": build_ppl_asel_syllabus,
    "ppl_amel": build_ppl_amel_syllabus,
    "ir": build_ir_syllabus,
    "cpl": build_cpl_syllabus,
    "cpl_amel": build_cpl_amel_syllabus,
    "ppl_helicopter": build_ppl_helicopter_syllabus,
}


class ExaminerSession:
    """`is_waiting_for_ready`: after one task finishes, the next one
    doesn't start watching for its own arm condition until the pilot
    explicitly presses "Ready" (`ready()`, wired to a UI button and the
    `checkride/examiner/ready` command). A real DPE waits for your "ready"
    call before starting the next maneuver's clock rather than guessing a
    fixed pause -- some maneuvers need longer to recover from than others
    (a stall recovery vs. rolling level after a steep turn), and only the
    pilot actually knows when that is. An earlier version used a flat
    5-second timer instead; that was either too short for some tasks or an
    annoying forced wait for others (user-reported), so it's now entirely
    pilot-paced with no timeout of its own.

    Skipped for multiple-choice tasks (quizzes): those don't have any
    "still recovering from the last maneuver" concern, so the pilot isn't
    made to press Ready before answering -- see `_advance()`.

    Applies to every way a task can finish (a flight-data tick, a quiz
    answer, a skip), via the shared `_advance()`."""

    def __init__(self, rating: str = "ppl_asel"):
        self.rating = rating
        self.tasks: List[Task] = _SYLLABUS_BUILDERS[rating]()
        self.index = 0
        self.results: List[TaskResult] = []
        self._last_t: Optional[float] = None
        self._waiting_for_ready = False
        self.finished = False

    @property
    def current_task(self) -> Optional[Task]:
        if self.index >= len(self.tasks):
            return None
        return self.tasks[self.index]

    @property
    def next_task(self) -> Optional[Task]:
        if self.index + 1 >= len(self.tasks):
            return None
        return self.tasks[self.index + 1]

    @property
    def is_waiting_for_ready(self) -> bool:
        return self._waiting_for_ready

    def ready(self) -> None:
        """Pilot-initiated: start watching the current (just-advanced-to)
        task's arm condition. A no-op if nothing is waiting."""
        self._waiting_for_ready = False

    def submit_answer(self, index: int) -> None:
        """Route an answer from a MultipleChoiceTask's overlay buttons (or
        the answer_a..d commands) to the current task, then advance."""
        task = self.current_task
        answer = getattr(task, "answer", None)
        if answer is None:
            return
        result = answer(index)
        if result is not None:
            self._advance(result)

    def skip_current(self) -> None:
        task = self.current_task
        if task is None:
            return
        self._advance(TaskResult(task.task_id, task.title, False, ["skipped by pilot/examiner"]))

    def restart(self) -> None:
        self.__init__(self.rating)

    def _advance(self, result: TaskResult) -> None:
        self.results.append(result)
        self.index += 1
        self._last_t = None
        if self.index >= len(self.tasks):
            self.finished = True
            return
        next_task = self.current_task
        # quizzes have no "still recovering from the last maneuver" concern
        # -- don't make the pilot press Ready before they can even answer.
        self._waiting_for_ready = getattr(next_task, "answer", None) is None

    def tick(self, state: FlightState) -> None:
        if self.finished:
            return
        task = self.current_task
        if task is None:
            self.finished = True
            return
        if self._waiting_for_ready:
            return  # don't even start task's clock (_last_t) until ready() is called
        if self._last_t is None:
            self._last_t = state.t
        dt = max(0.0, min(state.t - self._last_t, 1.0))
        self._last_t = state.t
        result = task.update(state, dt)
        if result is not None:
            self._advance(result)

    def score_summary(self) -> str:
        total = len(self.results)
        passed = sum(1 for r in self.results if r.passed)
        return f"{passed}/{total} tasks satisfactory"
