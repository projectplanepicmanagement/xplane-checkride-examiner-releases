"""Heading / ground-track helpers shared across examiner tasks."""
import math


def heading_diff(value: float, target: float) -> float:
    """Smallest signed difference value-target in degrees, wrapped to [-180, 180]."""
    return (value - target + 180.0) % 360.0 - 180.0


def wrap360(heading: float) -> float:
    return heading % 360.0


def resolve_approach_speed(published_kt: float, vso_kt: float, factor: float = 1.3):
    """ACS formula shared by Normal/Soft-Field/Short-Field Approach and
    Landing (PA.IV.B.S6 / PA.IV.D.S6 / PA.IV.F.S7, identical wording in all
    three): the manufacturer's published approach speed, or in its
    absence, `factor` x Vso. Returns None if neither is available -- the
    caller falls back to a self-referential, advisory-only target in that
    case (see e.g. tasks/short_field.py)."""
    if published_kt > 0.0:
        return published_kt
    if vso_kt > 0.0:
        return factor * vso_kt
    return None


FT_PER_DEG_LAT = 364000.0  # approximation, good enough over a few nm


def local_xy_ft(lat: float, lon: float, ref_lat: float, ref_lon: float):
    """Flat-earth local tangent-plane offset of (lat, lon) from (ref_lat, ref_lon), in feet.

    Only valid over the small distances (a few nautical miles) involved in a
    single training maneuver.
    """
    dlat = lat - ref_lat
    dlon = lon - ref_lon
    y = dlat * FT_PER_DEG_LAT
    x = dlon * FT_PER_DEG_LAT * math.cos(math.radians(ref_lat))
    return x, y
