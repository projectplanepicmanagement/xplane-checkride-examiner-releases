"""Checkride Examiner: an X-Plane 12 / XPPython3 plugin that acts as a virtual
DPE for Private Pilot (PPL), ASEL. It calls out ACS tasks one at a time and
grades the flying against numeric tolerances from the FAA Private Pilot -
Airplane ACS (FAA-S-ACS-6 / -6B).
"""

__version__ = "0.1.0"
