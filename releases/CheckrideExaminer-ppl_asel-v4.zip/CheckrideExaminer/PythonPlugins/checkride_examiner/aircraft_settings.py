"""Per-aircraft manually-entered V-speeds and maneuver target speeds that
X-Plane has no dataref for (see tasks/short_field.py, tasks/vmc_demo.py,
tasks/slow_flight.py) and that can vary by flight school on top of that,
persisted to a small JSON file keyed by the loaded aircraft's .acf file name
so each add-on/livery is remembered separately.

`vx_kt`/`vy_kt`, `vmc_recovery_kt`, and `slow_flight_kt` are **mandatory**
for their tasks: left at 0 (unregistered), those tasks refuse to even arm
(`Task.blocking_reason()`) rather than falling back to a self-referential
guess -- a real target speed varies too much by flight school/aircraft to
assume one (user-requested; these three used to be optional/advisory-only).
`short_field_approach_kt` stays optional: X-Plane's own `acf_Vso` dataref
already gives a real ACS-formula fallback (1.3 x Vso) for that one, so
there's a sound automatic answer when it's left unset.

No XPPython3 import here -- `path` is just a string, resolved by the caller
(normally `dirname(xp.getPrefsPath())`, X-Plane's writable preferences
folder, so the file survives a plugin update/reinstall the same way the
user's other X-Plane settings do; overwriting `checkride_examiner/` per
INSTALL.txt's update instructions never touches it). Passing `path=None`
runs fully in-memory (used by tests, and as a harmless fallback if
resolving a real path ever fails) -- settings just don't persist.
"""
import json
import os
from dataclasses import asdict, dataclass, fields
from typing import Dict, Optional


@dataclass
class AircraftSettings:
    vx_kt: float = 0.0
    vy_kt: float = 0.0
    # ACS: "manufacturer's published approach airspeed or in its absence
    # not more than 1.3 x Vso" -- 0 means "use 1.3 x Vso" (see
    # tasks/short_field.py), since Vso itself comes from a live dataref,
    # not something the pilot needs to type in. Optional -- see module
    # docstring for why this one, unlike the three below, has a sound
    # automatic fallback.
    short_field_approach_kt: float = 0.0
    # VMC Demonstration's recovery target (e.g. Vyse) -- mandatory, no
    # dataref/formula fallback exists (tasks/vmc_demo.py).
    vmc_recovery_kt: float = 0.0
    # Maneuvering During Slow Flight's target airspeed (MCA) -- mandatory,
    # no dataref/formula fallback exists (tasks/slow_flight.py).
    slow_flight_kt: float = 0.0

    @property
    def is_registered(self) -> bool:
        return (
            self.vx_kt > 0.0 or self.vy_kt > 0.0 or self.short_field_approach_kt > 0.0
            or self.vmc_recovery_kt > 0.0 or self.slow_flight_kt > 0.0
        )


_FIELD_NAMES = {f.name for f in fields(AircraftSettings)}


class AircraftSettingsStore:
    def __init__(self, path: Optional[str]):
        self._path = path
        self._by_aircraft: Dict[str, AircraftSettings] = {}
        self._load()

    def _load(self) -> None:
        if not self._path or not os.path.exists(self._path):
            return
        try:
            with open(self._path, "r", encoding="utf-8") as f:
                raw = json.load(f)
            for key, values in raw.items():
                if isinstance(values, dict):
                    self._by_aircraft[key] = AircraftSettings(**{k: v for k, v in values.items() if k in _FIELD_NAMES})
        except (OSError, ValueError, TypeError):
            # corrupt or unreadable file -- start fresh rather than crash the plugin
            self._by_aircraft = {}

    def _save(self) -> None:
        if not self._path:
            return
        directory = os.path.dirname(self._path)
        if directory:
            os.makedirs(directory, exist_ok=True)
        raw = {key: asdict(value) for key, value in self._by_aircraft.items()}
        tmp_path = self._path + ".tmp"
        with open(tmp_path, "w", encoding="utf-8") as f:
            json.dump(raw, f, indent=2, sort_keys=True)
        os.replace(tmp_path, self._path)

    def is_registered(self, aircraft_key: str) -> bool:
        settings = self._by_aircraft.get(aircraft_key)
        return settings is not None and settings.is_registered

    def get(self, aircraft_key: str) -> AircraftSettings:
        return self._by_aircraft.get(aircraft_key, AircraftSettings())

    def set(self, aircraft_key: str, settings: AircraftSettings) -> None:
        self._by_aircraft[aircraft_key] = settings
        self._save()
