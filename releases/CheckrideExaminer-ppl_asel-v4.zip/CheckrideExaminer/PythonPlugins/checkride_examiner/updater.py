"""Self-hosted update checker/installer -- no third-party updater service.

SkunkCrafts Updater (the de facto standard for X-Plane payware) turned out
to require personally contacting its one maintainer to get a new addon
onboarded (confirmed via several forum threads from Nov 2024 through Jan
2026, all answered with "DM me on Discord" -- there's no public self-serve
process). Rather than block shipping updates on that, this is a small
from-scratch updater that needs nothing beyond what's already true of any
customer's install: XPPython3's embedded Python, which already has
`urllib`/`json`/`zipfile`/`shutil` in its standard library -- nothing new
to install.

**Manual, user-initiated only.** There is no automatic check on startup.
This matters for a reason SkunkCrafts Updater's own documentation calls
out about ITS old in-sim plugin version: "if a remote server is
unresponsive then X-Plane will be unresponsive for a couple of minutes."
A "Check for Updates" button (see overlay.py) means a slow/unreachable
server can only ever stall that one click, never X-Plane's own startup --
this is a property of *when* the network call happens, not just the
request timeout.

MANIFEST_URL points at a small JSON file in a *public* GitHub repo
dedicated to distribution (`xplane-checkride-examiner-releases`), kept
separate from the private source repo -- a private repo's raw/release
URLs need an auth token to fetch, which an anonymous pilot's install
obviously doesn't have, so the source repo staying private and the
distribution repo being public are both load-bearing, not incidental.

check()/apply() take `fetch_json`/`download` as injectable dependencies
(default to real `urllib` calls) specifically so the version-comparison
and extraction logic can be unit-tested offline (tests/test_updater.py)
without ever making a real network call.

apply() extracts to a temp directory and only starts replacing files
after confirming the expected `CheckrideExaminer/PythonPlugins/...` layout
is present in the downloaded zip -- see package.sh for why that's the
layout -- so a malformed/truncated download can't leave a half-replaced,
broken install. It replaces `checkride_examiner/` (the whole folder) and
`PI_CheckrideExaminer.py`, mirroring INSTALL.txt's own manual-update
instructions ("overwrite the checkride_examiner folder and
PI_CheckrideExaminer.py"). Overwriting files Python has already imported
in the running session is safe at the OS level (the interpreter doesn't
keep source files open after reading them) but doesn't take effect until
X-Plane restarts or Plugin Admin > Reload Scripts runs -- apply() cannot
make that happen from inside itself, so the caller (overlay.py) is
responsible for telling the pilot to do it.

**TLS uses a vendored root CA bundle (`cacert.pem`), not the interpreter's
own trust store.** This was originally documented as an unconfirmed risk
("might fail depending on the Python environment's CA bundle") and then
actually hit on a real XPPython3 install: `CERTIFICATE_VERIFY_FAILED:
unable to get local issuer certificate` on the exact same
`raw.githubusercontent.com` URL that worked fine elsewhere -- confirming
XPPython3's embedded interpreter can ship with no usable root CA list on
some platforms, the same failure mode python.org's own macOS installer is
notorious for. Rather than silently fall back to no verification (which
would make apply() -- something that downloads and installs executable
Python code -- trust literally anything on the network, a real MITM risk),
`cacert.pem` is the standard Mozilla root bundle (via the `certifi`
project, vendored as a static file rather than a pip dependency XPPython3
may not be able to install) shipped alongside this file and loaded
explicitly via `ssl.create_default_context(cafile=...)`. Every HTTPS call
this module makes uses it, so verification no longer depends on whatever
trust store (if any) the host Python happens to have. It's a dated
snapshot like any vendored CA bundle -- see README/SPEC for the refresh
note -- and falls back to the interpreter's own default context if the
file is ever missing, rather than failing outright.
"""
import json
import os
import shutil
import ssl
import tempfile
import urllib.request
import zipfile
from typing import Callable, NamedTuple, Optional

MANIFEST_URL = "https://raw.githubusercontent.com/projectplanepicmanagement/xplane-checkride-examiner-releases/main/manifest.json"
FETCH_TIMEOUT_S = 6.0
DOWNLOAD_TIMEOUT_S = 30.0

_ZIP_PLUGINS_PREFIX = "CheckrideExaminer/PythonPlugins"
_CACERT_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "cacert.pem")


def _ssl_context() -> ssl.SSLContext:
    if os.path.isfile(_CACERT_PATH):
        return ssl.create_default_context(cafile=_CACERT_PATH)
    return ssl.create_default_context()  # vendored bundle missing -- fall back rather than fail outright


class UpdateInfo(NamedTuple):
    version: int
    zip_url: str
    notes: str


class UpdateError(Exception):
    pass


def _default_fetch_json(url: str) -> dict:
    with urllib.request.urlopen(url, timeout=FETCH_TIMEOUT_S, context=_ssl_context()) as resp:
        return json.loads(resp.read().decode("utf-8"))


def _default_download(url: str, dest_path: str) -> None:
    with urllib.request.urlopen(url, timeout=DOWNLOAD_TIMEOUT_S, context=_ssl_context()) as resp, open(dest_path, "wb") as f:
        shutil.copyfileobj(resp, f)


def parse_manifest(data: dict) -> UpdateInfo:
    """Pure parsing, split out so a malformed remote manifest is testable
    without touching the network -- raises UpdateError with a message
    that's safe to show the pilot as-is, rather than a raw KeyError."""
    try:
        return UpdateInfo(
            version=int(data["version"]),
            zip_url=str(data["zip_url"]),
            notes=str(data.get("notes", "")),
        )
    except (KeyError, TypeError, ValueError) as exc:
        raise UpdateError(f"manifest is missing or has a malformed field: {exc!r}") from exc


class UpdateChecker:
    def __init__(
        self,
        plugins_root: str,
        current_version: int,
        fetch_json: Callable[[str], dict] = _default_fetch_json,
        download: Callable[[str, str], None] = _default_download,
    ):
        """plugins_root: the X-Plane `.../Resources/plugins/PythonPlugins`
        directory -- the parent of `checkride_examiner/` and
        `PI_CheckrideExaminer.py` -- i.e. what
        `os.path.dirname(os.path.abspath(__file__))` gives from
        PI_CheckrideExaminer.py itself, since that file lives directly in
        PythonPlugins/."""
        self._plugins_root = plugins_root
        self._current_version = current_version
        self._fetch_json = fetch_json
        self._download = download

    def check(self) -> Optional[UpdateInfo]:
        """None means "up to date" (or the manifest's version isn't newer
        than what's installed) -- never means "check failed"; a failed
        fetch raises instead, since the caller needs to tell those two
        cases apart in the UI (see overlay.py)."""
        info = parse_manifest(self._fetch_json(MANIFEST_URL))
        if info.version <= self._current_version:
            return None
        return info

    def apply(self, info: UpdateInfo) -> None:
        with tempfile.TemporaryDirectory(prefix="checkride_examiner_update_") as tmp:
            zip_path = os.path.join(tmp, "update.zip")
            self._download(info.zip_url, zip_path)

            extract_dir = os.path.join(tmp, "extracted")
            try:
                with zipfile.ZipFile(zip_path) as zf:
                    zf.extractall(extract_dir)
            except zipfile.BadZipFile as exc:
                raise UpdateError(f"downloaded file isn't a valid zip: {exc!r}") from exc

            new_pkg_dir = os.path.join(extract_dir, _ZIP_PLUGINS_PREFIX, "checkride_examiner")
            new_pi_file = os.path.join(extract_dir, _ZIP_PLUGINS_PREFIX, "PI_CheckrideExaminer.py")
            if not os.path.isdir(new_pkg_dir) or not os.path.isfile(new_pi_file):
                raise UpdateError(
                    f"downloaded zip doesn't have the expected {_ZIP_PLUGINS_PREFIX}/ layout -- "
                    "not installing anything from it"
                )

            dest_pkg_dir = os.path.join(self._plugins_root, "checkride_examiner")
            dest_pi_file = os.path.join(self._plugins_root, "PI_CheckrideExaminer.py")

            # Only start touching the real install after everything above
            # succeeded -- a bad download must never leave a half-replaced,
            # broken plugin on disk.
            if os.path.isdir(dest_pkg_dir):
                shutil.rmtree(dest_pkg_dir)
            shutil.copytree(new_pkg_dir, dest_pkg_dir)
            shutil.copy2(new_pi_file, dest_pi_file)
