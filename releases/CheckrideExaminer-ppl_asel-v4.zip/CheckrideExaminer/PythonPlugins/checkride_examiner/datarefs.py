"""Wraps the X-Plane DataRefs the examiner needs into a single snapshot() call.

Dataref choices verified against this machine's X-Plane 12
Resources/plugins/DataRefs.txt (2026-09-14, re-checked 2026-09-21). Notably
`sim/flightmodel/position/magpsi` and `sim/cockpit2/controls/parking_brake_ratio`
are both marked "DO NOT USE THIS" / "REPLACED" in that file, so parking
brake uses `sim/multiplayer/controls/parking_brake` (index 0 is the user's
aircraft).

`heading_deg` reads `sim/flightmodel/position/psi` -- the aircraft's actual
orientation as the flight model tracks it, not a simulated cockpit
instrument. An earlier version read `sim/cockpit/misc/compass_indicated`
instead (chosen only because `magpsi` was marked DO NOT USE), but that
dataref simulates the panel's WET MAGNETIC COMPASS specifically, which is
realistically modeled with the same turning/dip errors a real wet compass
has -- DataRefs.txt's own note on the related `gyr_magnetometer_diff`
dataref says outright that a magnetometer-derived heading is "only
accurate in straight and level flight" due to dip error. Every task that
tracks a *cumulative turn amount* by summing successive heading deltas
(Steep Turns, Chandelle, Lazy Eight, Turns Around a Point, Traffic
Pattern, Holding Procedure -- anything using `heading_diff` tick-to-tick,
not just a one-shot rollout comparison) was therefore accumulating against
a heading source that's least reliable exactly when banked, i.e. during
the turn itself. In testing this surfaced as "the turn never completes":
an already-shipped fix (see tasks/steep_turns.py) made finishing not
require an exact cumulative 360.0, but that didn't address a heading
source that could itself drift or lag enough, mid-turn, to never reach
even the 300 degrees that fix's early-rollout floor requires -- users
kept seeing the same "doesn't end" symptom after that fix shipped. `psi`
is the aircraft's real orientation (equivalent to what a gyroscopic
heading indicator/DG shows, which is what pilots actually fly a maneuver
by and what a real DPE grades against -- nobody flies a steep turn off
the wet compass), with no simulated instrument error at all. This is a
pure dataref-source change: nothing in tasks/*.py changed, so the offline
test suite (which feeds heading_deg values directly, bypassing datarefs.py
entirely) could never have caught this -- it only showed up against the
real simulator.

`nav1_hdef_dots_pilot` / `nav1_vdef_dots_pilot` are used over the older
`nav1_hdef_dot` / `nav1_vdef_dot` because their DataRefs.txt units are
explicitly "dots" rather than the ambiguous legacy "prcnt". The IR tasks
that consume these (tasks/nav_tracking.py, tasks/holding.py,
tasks/approaches.py) assume the standard CDI/HSI convention that full-scale
(pegged) deflection is +/-2.0 dots -- this wasn't confirmed against a live
gauge, so verify against an actual approach in the sim if grading looks off.

AMEL tasks read `throttle2_ratio` (engine 2/right) from the same
`ENGN_thro` array as `throttle_ratio` (engine 1/left) -- assumes engine
index 0 is the left engine and index 1 is the right one, the standard
X-Plane convention for a conventional twin (not centerline-thrust).

Short-field tasks read `flap_ratio` from `sim/flightmodel/controls/flaprat`
("Actual flap 1 deployment ratio", already a plain 0..1 float, generic
across aircraft) rather than `flaprqst` (the requested/handle position) --
the actual deployed ratio is what the aircraft is really flying with, which
matters since flaps take a few seconds to travel and this build cares about
the achieved configuration, not just what the pilot last commanded.

`vso_kt` reads `sim/aircraft/view/acf_Vso` -- the aircraft's own stall
speed in landing configuration (from its Plane Maker performance data, so
it's aircraft-specific, not a guess). This exists specifically so
Short-Field Approach and Landing can grade against the ACS's actual
formula ("1.3 x Vso") instead of a self-referential proxy. `vno_kt` reads
the sibling `sim/aircraft/view/acf_Vno` (max structural cruising speed) the
same way, so Emergency Descent can hard-bust a real overspeed instead of
only checking against whatever speed the pilot happened to enter the
descent at. X-Plane has NO equivalent dataref for Vx/Vy (best angle/rate-
of-climb speed), VMC Demonstration's recovery speed (Vyse), or a slow-
flight target speed -- those are performance-chart/POH numbers, not part
of the basic flight model the sim exposes, and can vary by flight school on
top of that -- so those are instead entered manually per aircraft (see
aircraft_settings.py) and matched up here via `aircraft_key`, read from
`xp.getNthAircraftModel(0)` (XPLMPlanes; index 0 = the user's aircraft),
which returns `(fileName, fullPath)` -- the file name (e.g.
"Cessna_172SP.acf") is used as the key since it's stable across flights/
liveries of the same add-on without depending on where it's installed.

`yoke_pitch_ratio` reads `sim/cockpit2/controls/yoke_pitch_ratio` -- the
pilot's raw elevator control INPUT (-1 full down .. +1 full up), not the
resulting surface deflection (which trim/autopilot also move). This is what
Soft-Field Takeoff/Landing (tasks/soft_field.py) uses to check for sustained
back-elevator pressure during the ground roll/rollout -- a real, generic,
per-user-input dataref, unlike anything available for Vx/Vy.

Helicopter tasks read `rotor_rpm` from `sim/flightmodel/engine/POINT_tacrad`
(index 0) -- the same "physically-simulated rotation speed" dataref
`reposition.py` writes to spin an engine's propeller back up after a
teleport. For a helicopter, engine 0's "point" is the main rotor, so this
reads its actual rotor speed (rad/sec, converted to RPM here) rather than
engine/N2 speed -- important because the two decouple during an
autorotation (that's the whole point of the maneuver), so engine RPM alone
wouldn't reflect what the rotor is actually doing.
"""
import math

from XPPython3 import xp

from .state import FlightState

_M_TO_FT = 3.280839895
_MPS_TO_KT = 1.9438445
_RAD_SEC_TO_RPM = 30.0 / math.pi


class DataRefReader:
    def __init__(self):
        self._lat = xp.findDataRef("sim/flightmodel/position/latitude")
        self._lon = xp.findDataRef("sim/flightmodel/position/longitude")
        self._alt_ind = xp.findDataRef("sim/cockpit2/gauges/indicators/altitude_ft_pilot")
        self._agl_m = xp.findDataRef("sim/flightmodel/position/y_agl")
        self._ias = xp.findDataRef("sim/flightmodel/position/indicated_airspeed")
        self._hdg = xp.findDataRef("sim/flightmodel/position/psi")
        self._phi = xp.findDataRef("sim/flightmodel/position/phi")
        self._theta = xp.findDataRef("sim/flightmodel/position/theta")
        self._vs = xp.findDataRef("sim/flightmodel/position/vh_ind_fpm")
        self._stall = xp.findDataRef("sim/cockpit2/annunciators/stall_warning")
        self._thr = xp.findDataRef("sim/flightmodel/engine/ENGN_thro")
        self._on_ground = xp.findDataRef("sim/flightmodel/failures/onground_any")
        self._gs = xp.findDataRef("sim/flightmodel/position/groundspeed")
        self._park_brake = xp.findDataRef("sim/multiplayer/controls/parking_brake")
        self._rpm = xp.findDataRef("sim/cockpit2/engine/indicators/engine_speed_rpm")
        self._oil_press = xp.findDataRef("sim/cockpit2/engine/indicators/oil_pressure_psi")
        self._nav1_hdef = xp.findDataRef("sim/cockpit2/radios/indicators/nav1_hdef_dots_pilot")
        self._nav1_vdef = xp.findDataRef("sim/cockpit2/radios/indicators/nav1_vdef_dots_pilot")
        self._rotor_tacrad = xp.findDataRef("sim/flightmodel/engine/POINT_tacrad")
        self._flap = xp.findDataRef("sim/flightmodel/controls/flaprat")
        self._vso = xp.findDataRef("sim/aircraft/view/acf_Vso")
        self._vno = xp.findDataRef("sim/aircraft/view/acf_Vno")
        self._yoke_pitch = xp.findDataRef("sim/cockpit2/controls/yoke_pitch_ratio")

    def snapshot(self, t: float) -> FlightState:
        thr = [0.0, 0.0]
        xp.getDatavf(self._thr, thr, 0, 2)  # index 0 = engine 1 (left), index 1 = engine 2 (right), for AMEL tasks
        park = [0.0]
        xp.getDatavf(self._park_brake, park, 0, 1)
        rpm = [0.0]
        xp.getDatavf(self._rpm, rpm, 0, 1)
        oil_press = [0.0]
        xp.getDatavf(self._oil_press, oil_press, 0, 1)
        rotor_rad = [0.0]
        xp.getDatavf(self._rotor_tacrad, rotor_rad, 0, 1)
        return FlightState(
            t=t,
            lat=xp.getDatad(self._lat),
            lon=xp.getDatad(self._lon),
            indicated_alt_ft=xp.getDataf(self._alt_ind),
            agl_ft=xp.getDataf(self._agl_m) * _M_TO_FT,
            ias_kt=xp.getDataf(self._ias),
            heading_deg=xp.getDataf(self._hdg),
            bank_deg=xp.getDataf(self._phi),
            pitch_deg=xp.getDataf(self._theta),
            vs_fpm=xp.getDataf(self._vs),
            stall_warning=bool(xp.getDatai(self._stall)),
            throttle_ratio=thr[0],
            throttle2_ratio=thr[1],
            on_ground=bool(xp.getDatai(self._on_ground)),
            groundspeed_kt=xp.getDataf(self._gs) * _MPS_TO_KT,
            parking_brake=park[0],
            engine_rpm=rpm[0],
            oil_press_psi=oil_press[0],
            nav1_hdef_dots=xp.getDataf(self._nav1_hdef),
            nav1_vdef_dots=xp.getDataf(self._nav1_vdef),
            rotor_rpm=rotor_rad[0] * _RAD_SEC_TO_RPM,
            flap_ratio=xp.getDataf(self._flap),
            vso_kt=xp.getDataf(self._vso),
            vno_kt=xp.getDataf(self._vno),
            aircraft_key=xp.getNthAircraftModel(0)[0],
            yoke_pitch_ratio=xp.getDataf(self._yoke_pitch),
        )
