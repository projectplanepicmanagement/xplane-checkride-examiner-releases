"""Plain flight-state snapshot. No XPPython3 import here so this (and the
task logic that consumes it) can be unit-tested without X-Plane running."""
from dataclasses import dataclass


@dataclass
class FlightState:
    t: float                 # sim elapsed time, seconds
    lat: float                # degrees
    lon: float                # degrees
    indicated_alt_ft: float   # pilot's altimeter, feet
    agl_ft: float             # height above ground, feet
    ias_kt: float             # indicated airspeed, knots
    heading_deg: float        # panel heading indicator, magnetic degrees
    bank_deg: float           # roll angle, degrees (+ = right wing down)
    pitch_deg: float          # pitch angle, degrees (+ = nose up)
    vs_fpm: float             # vertical speed, feet per minute
    stall_warning: bool       # stall horn/annunciator active
    throttle_ratio: float     # engine 1 (left) throttle, 0..1
    throttle2_ratio: float    # engine 2 (right) throttle, 0..1 -- AMEL tasks only; 0 on a single-engine aircraft
    on_ground: bool           # any part of the aircraft touching the ground
    groundspeed_kt: float     # ground speed, knots
    parking_brake: float      # 0 (off) .. 1 (full)
    engine_rpm: float         # engine 1 speed, RPM
    oil_press_psi: float      # engine 1 oil pressure, psi
    nav1_hdef_dots: float     # NAV1 CDI/localizer lateral deflection, dots (+/-2.0 = full scale)
    nav1_vdef_dots: float     # NAV1 glideslope vertical deflection, dots (+/-2.0 = full scale)
    rotor_rpm: float          # main rotor (helicopter) speed, RPM -- 0 / meaningless on a fixed-wing aircraft
    flap_ratio: float         # actual flap deployment, 0 (up) .. 1 (full)
    vso_kt: float             # stall speed, landing configuration, knots -- from the aircraft's own performance data (0 if not modeled)
    vno_kt: float             # max structural cruising speed, knots -- from the aircraft's own performance data (0 if not modeled)
    aircraft_key: str         # loaded aircraft's .acf file name -- identifies the add-on for per-aircraft settings (aircraft_settings.py)
    yoke_pitch_ratio: float   # pilot's raw elevator control INPUT, -1 (full down) .. +1 (full up) -- not surface deflection
