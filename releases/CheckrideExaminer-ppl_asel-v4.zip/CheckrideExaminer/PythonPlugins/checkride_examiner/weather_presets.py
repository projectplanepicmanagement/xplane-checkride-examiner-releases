"""Pure weather-preset data and unit conversion, split out of weather.py so
controller.py (imported by the offline test suite, no XPPython3 available)
can look up a preset by key without pulling in `xp`. See weather.py's
module docstring for the full rationale/dataref research; this file is just
the named presets and their AGL(current position)->MSL cloud-layer math.
"""
from typing import NamedTuple, Tuple

_FT_TO_M = 0.3048


class WeatherPreset(NamedTuple):
    key: str
    label: str
    description: str
    cloud_coverage: float  # 0..1 -- sim/weather/region/cloud_coverage_percent
    ceiling_agl_ft: float  # cloud base, relative to current ground elevation
    thickness_ft: float    # cloud_tops = base + this
    vis_sm: float


PRESETS = [
    WeatherPreset(
        key="vmc",
        label="Clear (VMC)",
        description="Clear skies, 15sm visibility -- resets back to good weather.",
        cloud_coverage=0.0,
        ceiling_agl_ft=0.0,
        thickness_ft=0.0,
        vis_sm=15.0,
    ),
    WeatherPreset(
        key="imc_enroute",
        label="Overcast (en-route IMC)",
        description="Overcast ~2,500ft AGL, 3sm visibility -- typical actual-IMC en-route practice.",
        cloud_coverage=1.0,
        ceiling_agl_ft=2500.0,
        thickness_ft=3000.0,
        vis_sm=3.0,
    ),
    WeatherPreset(
        key="low_ifr",
        label="Low IFR (approach practice)",
        description="Overcast ~300ft AGL, 0.75sm visibility -- near typical approach minimums "
                    "(not a specific published minimum for any procedure).",
        cloud_coverage=1.0,
        ceiling_agl_ft=300.0,
        thickness_ft=1500.0,
        vis_sm=0.75,
    ),
]

PRESETS_BY_KEY = {p.key: p for p in PRESETS}


def cloud_base_and_tops_m(ground_elevation_m: float, ceiling_agl_ft: float, thickness_ft: float) -> Tuple[float, float]:
    base_m = ground_elevation_m + ceiling_agl_ft * _FT_TO_M
    tops_m = base_m + thickness_ft * _FT_TO_M
    return base_m, tops_m
