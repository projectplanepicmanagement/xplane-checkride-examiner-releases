"""Finds nearby airports for the practice-mode location picker.

There's no way to draw a clickable lat/lon-picker on X-Plane's own map from
a plugin (XPLMMap only supports drawing markers/labels, not reading clicks
back), so this is a distance-sorted *list* of nearby airports instead of a
visual map -- pick one by name rather than by tapping a point.

Only scans navaids XPLM reports as being within the loaded scenery region
(`NavAidInfo.reg == 1`), using `findFirstNavAidOfType`/`findLastNavAidOfType`
to bound the scan to the contiguous Nav_Airport range (the documented XPLM
pattern for enumerating one type) rather than walking the entire global nav
database. Runs once per button press (when the picker screen opens), not
per flight-loop tick.
"""
import math
from dataclasses import dataclass
from typing import List

from XPPython3 import xp

_NM_PER_DEG_LAT = 60.0
_MAX_SCAN = 50000


@dataclass
class NearbyAirport:
    label: str
    lat: float
    lon: float
    elevation_m: float
    distance_nm: float


def _distance_nm(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    dlat = (lat2 - lat1) * _NM_PER_DEG_LAT
    dlon = (lon2 - lon1) * _NM_PER_DEG_LAT * math.cos(math.radians((lat1 + lat2) / 2.0))
    return math.hypot(dlat, dlon)


def find_nearby_airports(limit: int = 12) -> List[NearbyAirport]:
    lat = xp.getDatad(xp.findDataRef("sim/flightmodel/position/latitude"))
    lon = xp.getDatad(xp.findDataRef("sim/flightmodel/position/longitude"))

    first = xp.findFirstNavAidOfType(xp.Nav_Airport)
    last = xp.findLastNavAidOfType(xp.Nav_Airport)
    results: List[NearbyAirport] = []
    if first is None or first < 0 or last is None or last < 0:
        return results

    ref = first
    for _ in range(_MAX_SCAN):
        info = xp.getNavAidInfo(ref)
        if info is not None and getattr(info, "reg", 0):
            results.append(NearbyAirport(
                label=info.navAidID or "Airport",
                lat=info.latitude,
                lon=info.longitude,
                elevation_m=info.height,
                distance_nm=_distance_nm(lat, lon, info.latitude, info.longitude),
            ))
        if ref == last:
            break
        nxt = xp.getNextNavAid(ref)
        if nxt is None or nxt < 0:
            break
        ref = nxt

    results.sort(key=lambda a: a.distance_nm)
    return results[:limit]
