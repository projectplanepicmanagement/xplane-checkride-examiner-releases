"""Sets X-Plane's regional weather from a handful of named presets (clear
skies, a typical en-route overcast, and a low-IFR approach layer) so IR
tasks can be practiced/checked in genuinely reduced visibility instead of
only being graded as if they were flown in it.

This is presentation/immersion only -- nothing in tasks/*.py reads weather
state, so applying a preset never changes what's graded (CDI dots,
altitude, airspeed, etc. are graded the same in any weather). The value is
being able to fly an actual instrument approach in actual cloud, the way a
real IR checkride is far more convincing in, without alt-tabbing out to
X-Plane's own weather menu mid-session.

Uses the writable `sim/weather/region/*` datarefs (X-Plane 12 DataRefs.txt,
checked on this machine). The older `sim/weather/*` datarefs without a
`/region/` or `/aircraft/` segment are all marked REPLACED and no longer
writable. `sim/weather/region/weather_source` itself (0=Preset, 1=Real
Weather, 2=Controlpad, 3=Plugin) is marked read-only ('n') from a plugin's
perspective -- X-Plane is documented to flip it to Plugin (3) automatically
the instant any `sim/weather/region/*` dataref is written, so this never
writes it directly. That auto-switch behavior is per X-Plane's own weather
dataref documentation but hasn't been confirmed against this exact build --
if a preset appears to have no effect, check XPPython3Log.txt / a
DataRefEditor read of weather_source to see whether it actually flipped.

`change_mode` is set to 3 (Static) on every apply -- otherwise X-Plane's own
weather-trend simulation (whatever preset or real-weather trend was already
running) can gradually drift the injected values away over the session.

`update_immediately` makes every regional dataref except clouds apply on
the next frame. Clouds are documented to still fade in over about a minute
even with that flag set, so `apply()` also fires the `sim/operation/
regen_weather` command right after writing the cloud arrays -- the
documented way to force an immediate cloud refresh instead of waiting.

Only cloud layer 0 (of the 3 the sim models) is written; layers 1-2 are
left alone, which is enough for a single ceiling -- there's no UI need yet
for a multi-layer sky. Cloud base/tops are computed from the *current*
ground elevation (same technique as reposition.py: geometric elevation
minus AGL) so a "ceiling 300ft AGL" preset means roughly that regardless of
local terrain, rather than an absolute MSL number the pilot would have to
adjust for the airport in use.

The preset data itself (WeatherPreset/PRESETS/PRESETS_BY_KEY) and the pure
AGL->MSL conversion live in weather_presets.py, not here -- this module is
the one that touches `xp`, and controller.py (imported by the offline test
suite, which has no XPPython3 available) needs the preset list without
pulling that in. Same xp/no-xp split as reposition.py vs. the pure task
logic it's paired with.
"""
from XPPython3 import xp

from .weather_presets import WeatherPreset, cloud_base_and_tops_m

# sim/weather/region/cloud_type: 0=Cirrus, 1=Stratus, 2=Cumulus, 3=Cumulo-nimbus
_CLOUD_TYPE_STRATUS = 1.0
_CLOUD_TYPE_CLEAR = 0.0


class WeatherController:
    def __init__(self):
        self._elevation = xp.findDataRef("sim/flightmodel/position/elevation")
        self._agl_m = xp.findDataRef("sim/flightmodel/position/y_agl")
        self._change_mode = xp.findDataRef("sim/weather/region/change_mode")
        self._update_immediately = xp.findDataRef("sim/weather/region/update_immediately")
        self._cloud_type = xp.findDataRef("sim/weather/region/cloud_type")
        self._cloud_coverage = xp.findDataRef("sim/weather/region/cloud_coverage_percent")
        self._cloud_base = xp.findDataRef("sim/weather/region/cloud_base_msl_m")
        self._cloud_tops = xp.findDataRef("sim/weather/region/cloud_tops_msl_m")
        self._visibility = xp.findDataRef("sim/weather/region/visibility_reported_sm")
        self._regen_weather_cmd = xp.findCommand("sim/operation/regen_weather")

    def apply(self, preset: WeatherPreset) -> None:
        ground_elevation_m = xp.getDatad(self._elevation) - xp.getDataf(self._agl_m)
        base_m, tops_m = cloud_base_and_tops_m(ground_elevation_m, preset.ceiling_agl_ft, preset.thickness_ft)

        xp.setDatai(self._change_mode, 3)  # Static -- see module docstring
        xp.setDatai(self._update_immediately, 1)

        xp.setDataf(self._visibility, preset.vis_sm)

        cloud_type = _CLOUD_TYPE_STRATUS if preset.cloud_coverage > 0.0 else _CLOUD_TYPE_CLEAR
        xp.setDatavf(self._cloud_type, [cloud_type], 0, 1)
        xp.setDatavf(self._cloud_coverage, [preset.cloud_coverage], 0, 1)
        xp.setDatavf(self._cloud_base, [base_m], 0, 1)
        xp.setDatavf(self._cloud_tops, [tops_m], 0, 1)

        xp.commandOnce(self._regen_weather_cmd)
