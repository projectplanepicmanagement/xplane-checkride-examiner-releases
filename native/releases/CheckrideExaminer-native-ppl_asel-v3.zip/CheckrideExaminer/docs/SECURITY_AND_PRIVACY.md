# Checkride Examiner — Security, Privacy and Technical Disclosure

- **Product:** Checkride Examiner (PPL / ASEL edition) for X-Plane 12 — by Upcheck Aviation
- **Version:** v3 (native plugin)
- **Document date:** 2026-09-28
- **Contact for security or privacy questions:** upcheckaviation@gmail.com

This document describes, in full, what the software does on a customer's computer: what it reads and writes, what it sends over the network and to whom, what it launches, how updates are protected, and — just as important — where its protections stop. It is written for the X-Plane.org store review and for customers who want to know exactly what they are installing. Nothing here is marketing; if a claim cannot be backed by the source code or a test, it is listed under *Limitations* instead.

## 1. Summary

| Question | Answer |
| --- | --- |
| What is it? | A virtual examiner for X-Plane 12: it calls out FAA ACS tasks one at a time and grades your flying against the ACS tolerances, with an in-sim window and a report page in your browser. |
| Does it need other software? | No. It is a native plugin (C++). It does not use Python or XPPython3 and bundles no third-party libraries. |
| Does it collect personal data? | No. No name, e-mail, hardware identifiers, flight data, telemetry or analytics ever leave the computer. |
| What does it send over the network? | Only three things, all triggered by the user: (1) license activation (a license key and a random install ID); (2) an update check (a plain download of a small public file) when the report page is opened; (3) the update package download when the user presses *Install update*. Section 4. |
| Does it update itself silently? | No. Updates are only checked when the user opens the report page, and only installed when the user presses *Install update* while X-Plane is closed. Every update is cryptographically signed and verified before anything is installed. Section 8. |
| Does it change the simulator? | Only when the user asks: *Practice Mode* airborne tasks reposition the aircraft (and start engine 1), and the *Weather* screen writes the regional weather. Otherwise it only reads. Section 3. |
| Is the code signed? | Not yet. There is no Apple Developer ID / notarization and no Windows Authenticode certificate, so macOS and Windows will show a warning on first run. SHA-256 hashes for verification are in section 2. Section 13. |
| Third-party audit? | None so far. What was done instead is listed in section 11. |

## 2. What is in the package

Everything is inside one folder, `CheckrideExaminer`, which the customer copies into `X-Plane 12/Resources/plugins/`.

| File | Purpose |
| --- | --- |
| `mac_x64/CheckrideExaminer.xpl` | The plugin for macOS (universal: Apple silicon and Intel). |
| `win_x64/CheckrideExaminer.xpl` | The plugin for Windows 10/11 (64-bit). |
| `companion/checkride-report` (macOS), `companion/checkride-report.exe` (Windows) | The companion app: shows the flight report in the browser and installs updates. It is optional — the plugin works without it. |
| `INSTALL.txt` | Installation instructions (English/Japanese). |
| `support/ce-diagnose.bat` | A plain-text batch file (Windows) that writes network diagnostics to the Desktop. Only runs if the customer double-clicks it; readable in any editor. |
| `docs/` | This document. |
| `files.txt` | List of the files this package installed. Used by the updater to remove files a later version no longer ships — and nothing else. |

SHA-256 of the binaries in this package (verify with `shasum -a 256 <file>` on macOS or `certutil -hashfile <file> SHA256` on Windows):

```
08ab211a2f472598c9d292d1f62d480dcb7c6bee4ada286861094eeac069b492  mac_x64/CheckrideExaminer.xpl
90e8920c772e03305a1d743ca6edba92ae488bdc28557ecb21266843c9ea95b5  win_x64/CheckrideExaminer.xpl
704c0e307d58cd523406328bff6c295ac69a601870bb7641199fe899bc252183  companion/checkride-report
d8850ea8dbf02274c52eab9e0449899c442aa4266313905499523aa037898a40  companion/checkride-report.exe
```

## 3. What the plugin does inside X-Plane

**Runs as** a normal X-Plane plugin (native code, with the same privileges as X-Plane). Like any plugin, it could in principle do anything X-Plane can do; this section and the source-level tests describe what it *does* do.

**Reads** (every frame, read-only), through the standard XPLM dataref API: position, altitude, airspeed, heading, attitude, vertical speed, stall warning, throttle, on-ground flag, ground speed, parking brake, engine RPM, oil pressure, NAV1 deflections, rotor speed, flaps, the aircraft's Vso/Vno, elevator input, and the file name of the loaded aircraft (e.g. `Cessna_172SP.acf`, used to store per-aircraft speed settings). It also enumerates nearby airports through the navigation API when the Practice Mode location picker is opened.

**Writes to the simulator — only after an explicit user action:**

- *Practice Mode, airborne task, "Start":* sets position (`local_x/y/z`), velocity (`local_vx/vy/vz`), attitude (`phi/theta/psi`), and starts engine 1 (`ENGN_thro[0]`, `mixture_ratio[0]`, `ignition_on[0]`, `fuel_pump_on[0]`, `prop_mode[0]`, `ENGN_running[0]`, `ENGN_tacrad[0]`, `POINT_tacrad[0]`). This is the standard "reposition into the air" technique.
- *Weather screen, clicking a preset:* sets `sim/weather/region/*` (change mode, visibility, cloud layer 0 type/coverage/base/tops) and fires `sim/operation/regen_weather`.

**Registers** the commands `checkride/examiner/skip_task`, `restart`, `ready`, `answer_a` … `answer_d`, `open_report`, and a menu *Plugins → Checkride Examiner*. It creates one floating window (hidden until the menu item is chosen). While a text field in that window has focus it takes the keyboard so that typing does not fly the aircraft; pasting (Ctrl/Cmd+V) reads the system clipboard, only then.

**Does not:** read or write any other plugin's data, hook other plugins, read files outside those listed in section 5, use the microphone/camera, or open any listening network socket (the companion's local server is a separate optional program, section 9).

## 4. Network activity — complete list

The plugin and the companion make **no other network requests** than these. There is no telemetry, analytics, advertising or crash reporting.

| # | Program | When | Destination | What is sent | What comes back |
| --- | --- | --- | --- | --- | --- |
| 1 | Plugin | Only when the customer presses **Activate** in *Change Key* (first activation, or entering a different key) | `https://checkride-examiner-activation.projectplanepicmanagement.workers.dev/activate` (a Cloudflare Worker operated by Upcheck Aviation) | The license key and a random install ID (a UUID-style random identifier generated on first use by the operating system's cryptographic random generator; not derived from any hardware or user information) | `{"ok": true}` or an error such as "already activated on another installation" |
| 2 | Companion | Each time the report page is opened, and when the customer presses *Check again* | `https://raw.githubusercontent.com/projectplanepicmanagement/xplane-checkride-examiner-releases/main/native/manifest.json` (public GitHub repository) | Nothing beyond a standard HTTPS GET (the host sees the IP address and the User-Agent `CheckrideExaminer/1 (native plugin)`, as any web host does) | A small JSON file: latest version number, release notes, package URL, SHA-256 and signature |
| 3 | Companion | Only when the customer presses **Install update** | The package URL from the signed manifest (a file in the same GitHub repository) | Standard HTTPS GET | The update zip |

After a successful activation the plugin is fully offline: no periodic license checks, no "phone home". If the activation server cannot be reached, activation **fails** (it never "fails open"), but an already-activated copy keeps working.

All requests are made by the operating system's own `curl` (present on Windows 10+, macOS and most Linux systems) so that the operating system's certificate store is used and no TLS library is bundled. `curl` is started directly with an argument list, without a shell. Downloads (#2, #3) are restricted to `http`/`https`, also after redirects; the activation request (#1) goes to one fixed `https` address and does not follow redirects.

## 5. Data stored on the customer's computer

| Location | Contents | Sent anywhere? |
| --- | --- | --- |
| `X-Plane 12/Output/preferences/Checkride Examiner License.json` | The license key and the random install ID | The key + ID are sent once, at activation (#1 above) |
| `X-Plane 12/Output/preferences/Checkride Examiner Aircraft Settings.json` | Per-aircraft speed numbers the pilot typed in (Vx, Vy, …), keyed by aircraft file name | No |
| macOS: `~/Library/Application Support/Checkride Examiner/`  Windows: `%APPDATA%\Checkride Examiner\`  Linux: `~/.local/share/checkride-examiner/` | `history.jsonl` (one line per graded task: time, mode, rating, aircraft file name, pilot name, pass/fail, notes, measured deviations), `profiles.json` (local pilot names), `report*.html` (generated report pages), `companion.log` (update-check errors), `backup/` (the last 3 previous plugin versions, kept for rollback) | **No.** Flight history and pilot names never leave the computer. |
| The system temporary folder | Short-lived files for a request or an update (deleted afterwards) | No |
| The `CheckrideExaminer` plugin folder | The program files (section 2) | No |

*Pilot profiles* are only a name typed on the computer, meant for shared simulator PCs. There are no accounts, passwords or sign-in, and therefore nothing to leak.

To remove everything: delete the plugin folder and the data folders above.

## 6. Privacy

- **Personal data collected: none.** The only identifiers involved are the license key (which the customer received from us) and a random install ID.
- **On our server (Cloudflare Workers KV)** we store, per license key: the SHA-256 *hash* of the key (never the key itself), the install ID, the time of first activation and of the last activation. We do not store IP addresses, names, e-mail addresses or anything else. As with any web service, the hosting provider (Cloudflare) handles connection metadata such as IP addresses under its own terms; we do not access or keep it.
- **On GitHub** the update check is an ordinary download of a public file; GitHub sees the IP address as it would for any download.
- **Flight data, pilot names, aircraft, results and reports stay on the computer.** They are not uploaded, and the plugin has no feature that uploads them.
- **Removal on request:** we can delete the activation record of a key on request (this also lets the customer move to another computer).

## 7. Licensing design — and its limits

- A license key is checked **offline** with a keyed checksum, then bound to one computer through the activation server (#1). One key = one computer; the same computer can re-activate at any time (reinstall, update). Moving to a new computer needs the old binding released by us.
- **Honest limit:** this is protection against casual sharing of a key, not against a determined attacker. The checksum secret is inside the program (as it must be for offline validation), so someone who reverse-engineers the binary could create keys or patch the check; and the device binding is enforced only at activation, so a copied license file would not be detected. We accept this trade-off because stronger schemes (continuous online checks, hardware fingerprinting) conflict with working offline and with respecting privacy.
- Keys can be restricted to specific ratings; the PPL/ASEL edition rejects everything else both in the build and in the key.

## 8. Update system

The plugin cannot replace its own loaded binary, so updates are done by the companion app. Design goals: no silent changes, nothing installed unless it was signed by us, and always a way back.

1. **User-initiated.** The check happens when the report page is opened; the install happens only when *Install update* is pressed. Nothing runs in the background.
2. **Signed.** The manifest carries, per platform, an **Ed25519 signature** over `CE-UPDATE-1 / version / platform / SHA-256 of the package`. The public key is compiled into the companion (`700a96e5141c2c970c99bbd8098e583c019c82643b50cbda751608fe4af6cbca`). The private key exists only on the developer's computer (not in the repository, the package, or any server). An unsigned or wrongly-signed manifest is rejected and nothing is downloaded.
3. **Hash-checked.** The downloaded zip must match the signed SHA-256, otherwise nothing is installed.
4. **No downgrades.** Only a version higher than the installed one is offered.
5. **Safe extraction.** The zip is unpacked into a private temporary folder; it is rejected if it contains symbolic links or any path that would resolve outside that folder, or if it does not contain the plugin for the current operating system.
6. **X-Plane must be closed.** Installation is refused while X-Plane is running.
7. **Backup and rollback.** The current version is copied to `backup/` (outside the plugins folder — X-Plane would otherwise load a second copy) before any file is replaced; if anything fails part-way, the backup is restored automatically. The last 3 backups are kept.
8. **Only what the package owns is removed.** Files a new version no longer ships are deleted based on `files.txt`, and only files listed there, only inside the plugin folder (a `..` or absolute path in the list is ignored).
9. **Pilot data, license and settings are never touched** (they are not in the plugin folder).
10. **Windows:** a running `checkride-report.exe` cannot overwrite itself, so its new version is staged as `.new` and swapped in the next time it starts.

Attack scenarios:

| Scenario | Result |
| --- | --- |
| The GitHub repository or the download host is compromised | The attacker cannot produce a valid signature without the private key → the update is rejected. |
| A network attacker (man in the middle) | Same; in addition TLS is used. |
| A valid old package is replayed (downgrade) | Refused: version must be higher. |
| A malicious zip (path traversal, symlinks, wrong layout) | Rejected before anything is installed. |
| A failed or interrupted install | Automatic restore from backup. |
| The signing key is stolen | The attacker could sign malicious updates. Mitigation: the key is kept offline on one machine. Rotating the key requires customers to reinstall the package once (the key is compiled in) — see *Limitations*. |

If a reviewer or customer does not want the update feature, deleting the `companion` folder removes it; the plugin (grading, in-sim window, history) works without it. Only the report page and update installer go away.

## 9. The companion's local web server

To show the report and the update button in the browser, the companion starts a small HTTP server for as long as the page is open:

- Bound to **`127.0.0.1` only** (never reachable from other computers), on a random free port.
- Every request needs a **random 128-bit token** (from the operating system's cryptographic generator) that is part of the page URL; requests without it are refused. A request whose `Host` header is not the loopback address is refused (protection against DNS-rebinding). No cross-origin (CORS) headers are ever sent, so other websites cannot read its responses.
- The server **exits by itself** 45 seconds after the last page ping (the page pings every 10 s), 3 minutes after starting if the page was never opened, or on request.
- It accepts only small, well-formed requests (headers and body are size-limited; the Content-Length must be plain digits), handles one request at a time, and can only do what the page needs: show the report, check for an update, install an update, ping, quit. It cannot read arbitrary files or run arbitrary commands.
- Release notes from the manifest are shown as plain text (never interpreted as HTML).

## 10. Other programs the software starts

| Program | When | Arguments |
| --- | --- | --- |
| `curl` | Sections 4 (#1–#3) | fixed options + the URL and temporary file paths |
| `unzip` (macOS/Linux) or `tar` (Windows 10+) | While installing an update | the downloaded zip and a private temporary folder |
| `pgrep` (macOS/Linux) / a process-list query (Windows API, no program) | Before installing an update, to detect X-Plane | fixed process name |
| `open` (macOS) / `xdg-open` (Linux) / the Windows shell's *open* verb | To open the report page in the default browser, and the companion from the plugin | the local report URL or the companion's own path |
| `pbpaste` (macOS) / `xclip` or `xsel` (Linux) | Only when pasting into a text field | none (fixed command). On Windows the clipboard API is used directly. |

Arguments are passed as an argument list; no command line is ever assembled from user input for a shell.

## 11. How the software was verified

- **Grading fidelity:** the grading logic is a native port of an earlier, already-released implementation. It was verified against it with recorded traces (8,203 recorded task events across all 43 tasks — 0 mismatches), 13,596 static checks, over 2 million fuzzed events, and ~170,000 compared user-interface calls (0 mismatches).
- **Memory safety:** the core, the updater, the local server and the parsers were run under **AddressSanitizer and UndefinedBehaviorSanitizer** (golden replay, updater end-to-end, hostile-traffic and parser fuzz tests): no findings.
- **Parser fuzzing:** 30,000 mutated update manifests, settings/license/profile files and URLs — no crashes, and no mutated manifest was ever accepted.
- **Signature code:** the Ed25519 verifier was written from RFC 8032 and checked against the RFC test vector and 48 OpenSSL-generated cases, including tampered signatures, messages and keys.
- **Updater end-to-end:** 41 scripted checks against a local mock release server — bad signature, bad checksum, package without the plugin, package with a symlink, X-Plane running, downgrade, success with backup, removal of dropped files, customer files kept, access control, idle exit.
- **Local server:** 47 hostile-traffic checks (malformed requests, oversized headers, bad Content-Length, path traversal, missing token, wrong Host, half-open connections). This testing found and fixed a real defect (a client disconnecting mid-request could terminate the process).
- **Plugin shell:** 91 scripted checks drive the real window, command, menu and dataref code through a simulated X-Plane API (clicks, keys, wheel, history file, repositioning, weather).

What was **not** done: an independent third-party security audit or penetration test; formal verification; testing on every Windows/macOS version and every add-on aircraft.

## 12. Third-party components

- **No third-party source code or libraries are bundled.** SHA-256, SHA-512, Ed25519 (RFC 8032), the JSON reader/writer, the HTTP server and the user interface are written by us.
- The X-Plane SDK (Laminar Research) headers and import libraries are used to build the plugin; they are not redistributed.
- The operating system's own tools listed in section 10 are used at run time.
- Linux is not built or tested in this release.

## 13. Code signing and operating-system warnings

The binaries are **not** signed with an Apple Developer ID (not notarized) or a Windows code-signing certificate. Consequences and mitigations:

- macOS may show "cannot be opened because the developer cannot be verified" for files downloaded through a browser. `INSTALL.txt` shows the one-line command (`xattr -dr com.apple.quarantine …`). The macOS binaries carry an ad-hoc signature (required by Apple silicon).
- Windows SmartScreen may warn about `checkride-report.exe` ("More info → Run anyway").
- Customers can compare the SHA-256 of any file with section 2 of this document.
- Signing and notarization are planned once sales justify the certificate costs.

## 14. Known limitations and risks

1. **License protection is not DRM** (section 7). A determined reverse-engineer can bypass it.
2. **Windows certificate revocation:** on Windows the software's `curl` calls skip the *revocation* lookup (certificate chain and host name are still verified). Windows' revocation check fails on many networks (antivirus, proxies, blocked CRL servers) and would otherwise make activation and updates unusable. For updates this is covered by the signature and hash checks; for activation the exchanged data is a license key and a random ID.
3. **The update signing key is a single point of trust,** and it is compiled into the program; rotating it requires a manual reinstall.
4. **Unsigned binaries** (section 13).
5. **The plugin runs with X-Plane's privileges,** like every X-Plane plugin. A person with write access to the plugin folder can already run code as the user; the updater does not change that.
6. **The report page's URL contains a per-run token** that is visible to local software and stays in browser history; it is useless once the server has exited (within about a minute after the page is closed).
7. **Practice Mode changes simulator state** (position, engine start) by design; it is only done after pressing *Start*.
8. The manifest and package URLs are checked for `http`/`https` only; integrity comes from the signature and hash, not from the transport.

## 15. Opting out, firewalling, uninstalling

- **Use it fully offline:** after the one-time activation nothing needs the network. Blocking the companion (or deleting the `companion` folder) removes the update check/report page; the plugin keeps working.
- **Firewall rules:** the plugin needs outbound HTTPS to `*.workers.dev` only for activation; the companion needs `raw.githubusercontent.com` only for updates. Nothing needs inbound access.
- **Uninstall:** delete `X-Plane 12/Resources/plugins/CheckrideExaminer` and, optionally, the data folders in section 5.

## 16. Reporting a vulnerability

Please e-mail **upcheckaviation@gmail.com** with a description and, if possible, steps to reproduce. We aim to acknowledge within 3 working days and to fix confirmed issues in the next release (or immediately for serious ones). Please give us reasonable time to fix before public disclosure.
