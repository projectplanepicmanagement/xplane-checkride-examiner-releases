@echo off
setlocal
set OUT=%USERPROFILE%\Desktop\ce-diagnose.txt
set URL=https://raw.githubusercontent.com/projectplanepicmanagement/xplane-checkride-examiner-releases/main/native/manifest.json
echo Checkride Examiner update diagnostics > "%OUT%"
echo. >> "%OUT%"
echo --- Windows version >> "%OUT%"
ver >> "%OUT%"
echo --- where curl >> "%OUT%"
where curl >> "%OUT%" 2>&1
echo --- curl --version >> "%OUT%"
curl --version >> "%OUT%" 2>&1
echo. >> "%OUT%"
echo --- 1. plain request >> "%OUT%"
curl -sS -L --max-time 15 -o "%TEMP%\ce-manifest.json" -w "HTTP %%{http_code}\n" "%URL%" >> "%OUT%" 2>&1
echo --- 2. same, skipping certificate revocation lookup >> "%OUT%"
curl -sS -L --ssl-no-revoke --max-time 15 -o "%TEMP%\ce-manifest2.json" -w "HTTP %%{http_code}\n" "%URL%" >> "%OUT%" 2>&1
echo --- 3. first bytes of the file that was downloaded >> "%OUT%"
powershell -NoProfile -Command "if (Test-Path $env:TEMP\ce-manifest2.json) { (Get-Content $env:TEMP\ce-manifest2.json -Raw).Substring(0,[Math]::Min(300,(Get-Content $env:TEMP\ce-manifest2.json -Raw).Length)) } else { 'no file' }" >> "%OUT%" 2>&1
echo. >> "%OUT%"
echo --- 4. companion log >> "%OUT%"
if exist "%APPDATA%\Checkride Examiner\companion.log" (type "%APPDATA%\Checkride Examiner\companion.log" >> "%OUT%") else (echo no companion.log >> "%OUT%")
echo --- 5. proxy settings >> "%OUT%"
netsh winhttp show proxy >> "%OUT%" 2>&1
echo.
echo Done. Please send the file  ce-diagnose.txt  (it is on your Desktop).
pause
